--
-- PostgreSQL database dump
--

\restrict hXW55k9h1Us6gj1SMQAbG4hKKnpVToty1R1yOL6DyYjbBiYhV6NEfHyxsqkO3KM

-- Dumped from database version 14.19 (Homebrew)
-- Dumped by pg_dump version 14.19 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ActivityType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ActivityType" AS ENUM (
    'USER_REGISTRATION',
    'USER_LOGIN',
    'USER_LOGOUT',
    'ROLE_UPDATE',
    'PERMISSION_UPDATE',
    'LEAD_CREATED',
    'LEAD_UPDATED',
    'LEAD_DELETED',
    'SYSTEM_BACKUP',
    'SYSTEM_MAINTENANCE',
    'SECURITY_ALERT',
    'DATABASE_MIGRATION',
    'API_CALL',
    'ERROR_LOG',
    'LEAD_ASSIGNED',
    'LEAD_STATUS_CHANGED',
    'LEAD_CONVERTED',
    'LEAD_FOLLOW_UP_CREATED',
    'LEAD_FOLLOW_UP_COMPLETED',
    'TASK_CREATED',
    'TASK_UPDATED',
    'TASK_COMPLETED',
    'COMMUNICATION_LOGGED',
    'CONTACT_CREATED',
    'DEAL_CREATED',
    'DEAL_UPDATED',
    'DEAL_WON',
    'DEAL_LOST'
);


ALTER TYPE public."ActivityType" OWNER TO postgres;

--
-- Name: CallStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CallStatus" AS ENUM (
    'INITIATED',
    'RINGING',
    'ANSWERED',
    'COMPLETED',
    'FAILED',
    'BUSY',
    'NO_ANSWER',
    'CANCELLED'
);


ALTER TYPE public."CallStatus" OWNER TO postgres;

--
-- Name: CallType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CallType" AS ENUM (
    'INBOUND',
    'OUTBOUND'
);


ALTER TYPE public."CallType" OWNER TO postgres;

--
-- Name: CommunicationType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CommunicationType" AS ENUM (
    'CALL',
    'EMAIL',
    'SMS',
    'MEETING',
    'NOTE'
);


ALTER TYPE public."CommunicationType" OWNER TO postgres;

--
-- Name: CompanyActivityType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CompanyActivityType" AS ENUM (
    'CALL',
    'EMAIL',
    'MEETING',
    'VISIT',
    'DEMO',
    'PRESENTATION',
    'FOLLOW_UP',
    'NOTE',
    'QUOTE_SENT',
    'CONTRACT_SENT',
    'PAYMENT_RECEIVED',
    'SUPPORT_TICKET',
    'TRAINING',
    'AUDIT',
    'REVIEW',
    'PARTNERSHIP',
    'OTHER'
);


ALTER TYPE public."CompanyActivityType" OWNER TO postgres;

--
-- Name: CompanySize; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CompanySize" AS ENUM (
    'STARTUP',
    'SMALL',
    'MEDIUM',
    'LARGE',
    'ENTERPRISE'
);


ALTER TYPE public."CompanySize" OWNER TO postgres;

--
-- Name: CompanyStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CompanyStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'PROSPECT',
    'CUSTOMER',
    'PARTNER',
    'COMPETITOR'
);


ALTER TYPE public."CompanyStatus" OWNER TO postgres;

--
-- Name: ContactActivityType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ContactActivityType" AS ENUM (
    'CALL',
    'EMAIL',
    'MEETING',
    'VISIT',
    'DEMO',
    'PRESENTATION',
    'FOLLOW_UP',
    'NOTE',
    'QUOTE_SENT',
    'CONTRACT_SENT',
    'PAYMENT_RECEIVED',
    'SUPPORT_TICKET',
    'TRAINING',
    'OTHER'
);


ALTER TYPE public."ContactActivityType" OWNER TO postgres;

--
-- Name: DealStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DealStatus" AS ENUM (
    'DRAFT',
    'PROPOSAL',
    'NEGOTIATION',
    'WON',
    'LOST'
);


ALTER TYPE public."DealStatus" OWNER TO postgres;

--
-- Name: FieldType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."FieldType" AS ENUM (
    'TEXT',
    'NUMBER',
    'DATE',
    'TIME',
    'DROPDOWN',
    'MULTI_SELECT',
    'CHECKBOX',
    'TOGGLE',
    'FILE'
);


ALTER TYPE public."FieldType" OWNER TO postgres;

--
-- Name: IntegrationAuthType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."IntegrationAuthType" AS ENUM (
    'API_KEY',
    'OAUTH',
    'TOKEN'
);


ALTER TYPE public."IntegrationAuthType" OWNER TO postgres;

--
-- Name: IntegrationLogStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."IntegrationLogStatus" AS ENUM (
    'PENDING',
    'SUCCESS',
    'FAILED',
    'PARTIAL'
);


ALTER TYPE public."IntegrationLogStatus" OWNER TO postgres;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'VIEWED',
    'PAID',
    'PARTIALLY_PAID',
    'OVERDUE',
    'CANCELLED',
    'REFUNDED'
);


ALTER TYPE public."InvoiceStatus" OWNER TO postgres;

--
-- Name: LeadImportStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LeadImportStatus" AS ENUM (
    'PROCESSING',
    'COMPLETED',
    'FAILED',
    'PARTIAL'
);


ALTER TYPE public."LeadImportStatus" OWNER TO postgres;

--
-- Name: LeadPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LeadPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."LeadPriority" OWNER TO postgres;

--
-- Name: LeadStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LeadStatus" AS ENUM (
    'NEW',
    'CONTACTED',
    'QUALIFIED',
    'PROPOSAL',
    'NEGOTIATION',
    'CLOSED',
    'LOST',
    'CONVERTED'
);


ALTER TYPE public."LeadStatus" OWNER TO postgres;

--
-- Name: LeadSyncStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LeadSyncStatus" AS ENUM (
    'SYNCED',
    'PENDING',
    'FAILED',
    'CONFLICT'
);


ALTER TYPE public."LeadSyncStatus" OWNER TO postgres;

--
-- Name: MessageStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."MessageStatus" AS ENUM (
    'PENDING',
    'SENT',
    'DELIVERED',
    'READ',
    'FAILED',
    'CANCELLED'
);


ALTER TYPE public."MessageStatus" OWNER TO postgres;

--
-- Name: ProductType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProductType" AS ENUM (
    'PHYSICAL',
    'DIGITAL',
    'SERVICE'
);


ALTER TYPE public."ProductType" OWNER TO postgres;

--
-- Name: QuotationStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QuotationStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'VIEWED',
    'ACCEPTED',
    'REJECTED',
    'EXPIRED',
    'CANCELLED'
);


ALTER TYPE public."QuotationStatus" OWNER TO postgres;

--
-- Name: RoleAccessScope; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."RoleAccessScope" AS ENUM (
    'OWN',
    'GLOBAL'
);


ALTER TYPE public."RoleAccessScope" OWNER TO postgres;

--
-- Name: TaskPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TaskPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."TaskPriority" OWNER TO postgres;

--
-- Name: TaskStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TaskStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."TaskStatus" OWNER TO postgres;

--
-- Name: TemplateType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TemplateType" AS ENUM (
    'EMAIL',
    'WHATSAPP',
    'SMS'
);


ALTER TYPE public."TemplateType" OWNER TO postgres;

--
-- Name: TriggerType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TriggerType" AS ENUM (
    'LEAD_CREATED',
    'LEAD_UPDATED',
    'LEAD_STATUS_CHANGED',
    'LEAD_ASSIGNED',
    'MANUAL'
);


ALTER TYPE public."TriggerType" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activities (
    id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    type public."ActivityType" NOT NULL,
    icon text DEFAULT 'FiUser'::text NOT NULL,
    "iconColor" text DEFAULT 'text-blue-600'::text NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" integer,
    "superAdminId" integer
);


ALTER TABLE public.activities OWNER TO postgres;

--
-- Name: activities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_id_seq OWNER TO postgres;

--
-- Name: activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;


--
-- Name: business_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.business_settings (
    id integer NOT NULL,
    "companyName" text NOT NULL,
    "companyEmail" text,
    "companyPhone" text,
    "companyAddress" text,
    "companyWebsite" text,
    "companyLogo" text,
    "timeZone" text DEFAULT 'UTC'::text NOT NULL,
    "dateFormat" text DEFAULT 'MM/DD/YYYY'::text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "passwordMinLength" integer DEFAULT 8 NOT NULL,
    "passwordRequireUpper" boolean DEFAULT true NOT NULL,
    "passwordRequireLower" boolean DEFAULT true NOT NULL,
    "passwordRequireNumber" boolean DEFAULT true NOT NULL,
    "passwordRequireSymbol" boolean DEFAULT false NOT NULL,
    "sessionTimeout" integer DEFAULT 24 NOT NULL,
    "maxLoginAttempts" integer DEFAULT 5 NOT NULL,
    "accountLockDuration" integer DEFAULT 30 NOT NULL,
    "twoFactorRequired" boolean DEFAULT false NOT NULL,
    "emailVerificationRequired" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "leadAutoAssignmentEnabled" boolean DEFAULT false NOT NULL,
    "leadFollowUpReminderDays" integer DEFAULT 3 NOT NULL,
    "cinNumber" text,
    description text,
    "employeeCount" text,
    "fiscalYearStart" text,
    "gstNumber" text,
    "indiamartApiKey" text,
    "indiamartApiSecret" text,
    "indiamartEnabled" boolean DEFAULT false NOT NULL,
    industry text,
    "metaAdsApiKey" text,
    "metaAdsApiSecret" text,
    "metaAdsEnabled" boolean DEFAULT false NOT NULL,
    "panNumber" text,
    "tradindiaApiKey" text,
    "tradindiaApiSecret" text,
    "tradindiaEnabled" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.business_settings OWNER TO postgres;

--
-- Name: business_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.business_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.business_settings_id_seq OWNER TO postgres;

--
-- Name: business_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.business_settings_id_seq OWNED BY public.business_settings.id;


--
-- Name: call_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.call_logs (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "userId" integer NOT NULL,
    "phoneNumber" text NOT NULL,
    "callType" public."CallType" DEFAULT 'OUTBOUND'::public."CallType" NOT NULL,
    "callStatus" public."CallStatus" DEFAULT 'INITIATED'::public."CallStatus" NOT NULL,
    duration integer,
    "startTime" timestamp(3) without time zone,
    "endTime" timestamp(3) without time zone,
    notes text,
    outcome text,
    "recordingUrl" text,
    "isAnswered" boolean DEFAULT false NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.call_logs OWNER TO postgres;

--
-- Name: call_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.call_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.call_logs_id_seq OWNER TO postgres;

--
-- Name: call_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.call_logs_id_seq OWNED BY public.call_logs.id;


--
-- Name: communication_automations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.communication_automations (
    id integer NOT NULL,
    name text NOT NULL,
    "triggerType" public."TriggerType" NOT NULL,
    "templateId" integer NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    conditions jsonb,
    delay integer,
    "companyId" integer,
    "createdBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.communication_automations OWNER TO postgres;

--
-- Name: communication_automations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.communication_automations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.communication_automations_id_seq OWNER TO postgres;

--
-- Name: communication_automations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.communication_automations_id_seq OWNED BY public.communication_automations.id;


--
-- Name: communication_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.communication_messages (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "userId" integer NOT NULL,
    "templateId" integer,
    type public."TemplateType" NOT NULL,
    recipient text NOT NULL,
    subject text,
    content text NOT NULL,
    status public."MessageStatus" DEFAULT 'PENDING'::public."MessageStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "readAt" timestamp(3) without time zone,
    "failedAt" timestamp(3) without time zone,
    "errorMessage" text,
    "externalId" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.communication_messages OWNER TO postgres;

--
-- Name: communication_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.communication_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.communication_messages_id_seq OWNER TO postgres;

--
-- Name: communication_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.communication_messages_id_seq OWNED BY public.communication_messages.id;


--
-- Name: communication_providers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.communication_providers (
    id integer NOT NULL,
    name text NOT NULL,
    type public."TemplateType" NOT NULL,
    config jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "companyId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.communication_providers OWNER TO postgres;

--
-- Name: communication_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.communication_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.communication_providers_id_seq OWNER TO postgres;

--
-- Name: communication_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.communication_providers_id_seq OWNED BY public.communication_providers.id;


--
-- Name: communication_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.communication_templates (
    id integer NOT NULL,
    name text NOT NULL,
    type public."TemplateType" NOT NULL,
    subject text,
    content text NOT NULL,
    variables jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "companyId" integer,
    "createdBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.communication_templates OWNER TO postgres;

--
-- Name: communication_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.communication_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.communication_templates_id_seq OWNER TO postgres;

--
-- Name: communication_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.communication_templates_id_seq OWNED BY public.communication_templates.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    domain text,
    "isActive" boolean DEFAULT true NOT NULL,
    slug text,
    "industryId" integer,
    address text,
    "alternatePhone" text,
    "annualRevenue" numeric(15,2),
    "assignedTo" integer,
    city text,
    "companySize" public."CompanySize" DEFAULT 'SMALL'::public."CompanySize",
    country text,
    currency text DEFAULT 'USD'::text,
    "deletedAt" timestamp(3) without time zone,
    description text,
    email text,
    "employeeCount" text,
    "facebookPage" text,
    "foundedYear" integer,
    "lastContactedAt" timestamp(3) without time zone,
    "leadScore" integer DEFAULT 0,
    "linkedinProfile" text,
    "nextFollowUpAt" timestamp(3) without time zone,
    notes text,
    "parentCompanyId" integer,
    phone text,
    state text,
    status public."CompanyStatus" DEFAULT 'ACTIVE'::public."CompanyStatus" NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    timezone text DEFAULT 'UTC'::text,
    "twitterHandle" text,
    website text,
    "zipCode" text
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_id_seq OWNER TO postgres;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: company_activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_activities (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer,
    type public."CompanyActivityType" NOT NULL,
    title text NOT NULL,
    description text,
    duration integer,
    outcome text,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "isCompleted" boolean DEFAULT false NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.company_activities OWNER TO postgres;

--
-- Name: company_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.company_activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_activities_id_seq OWNER TO postgres;

--
-- Name: company_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.company_activities_id_seq OWNED BY public.company_activities.id;


--
-- Name: company_communications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_communications (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    type public."CommunicationType" NOT NULL,
    subject text,
    content text NOT NULL,
    direction text DEFAULT 'outbound'::text NOT NULL,
    status public."MessageStatus" DEFAULT 'PENDING'::public."MessageStatus" NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "readAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.company_communications OWNER TO postgres;

--
-- Name: company_communications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.company_communications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_communications_id_seq OWNER TO postgres;

--
-- Name: company_communications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.company_communications_id_seq OWNED BY public.company_communications.id;


--
-- Name: company_followups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_followups (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    type public."CommunicationType" DEFAULT 'NOTE'::public."CommunicationType" NOT NULL,
    subject text NOT NULL,
    notes text,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "isCompleted" boolean DEFAULT false NOT NULL,
    "reminderSet" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.company_followups OWNER TO postgres;

--
-- Name: company_followups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.company_followups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_followups_id_seq OWNER TO postgres;

--
-- Name: company_followups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.company_followups_id_seq OWNED BY public.company_followups.id;


--
-- Name: contact_activities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_activities (
    id integer NOT NULL,
    "contactId" integer NOT NULL,
    "userId" integer,
    type public."ContactActivityType" NOT NULL,
    title text NOT NULL,
    description text,
    duration integer,
    outcome text,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "isCompleted" boolean DEFAULT false NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contact_activities OWNER TO postgres;

--
-- Name: contact_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contact_activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_activities_id_seq OWNER TO postgres;

--
-- Name: contact_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contact_activities_id_seq OWNED BY public.contact_activities.id;


--
-- Name: contact_communications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_communications (
    id integer NOT NULL,
    "contactId" integer NOT NULL,
    "userId" integer NOT NULL,
    type public."CommunicationType" NOT NULL,
    subject text,
    content text NOT NULL,
    direction text DEFAULT 'outbound'::text NOT NULL,
    status public."MessageStatus" DEFAULT 'PENDING'::public."MessageStatus" NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "readAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contact_communications OWNER TO postgres;

--
-- Name: contact_communications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contact_communications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_communications_id_seq OWNER TO postgres;

--
-- Name: contact_communications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contact_communications_id_seq OWNED BY public.contact_communications.id;


--
-- Name: contact_followups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_followups (
    id integer NOT NULL,
    "contactId" integer NOT NULL,
    "userId" integer NOT NULL,
    type public."CommunicationType" DEFAULT 'NOTE'::public."CommunicationType" NOT NULL,
    subject text NOT NULL,
    notes text,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "isCompleted" boolean DEFAULT false NOT NULL,
    "reminderSet" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.contact_followups OWNER TO postgres;

--
-- Name: contact_followups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contact_followups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contact_followups_id_seq OWNER TO postgres;

--
-- Name: contact_followups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contact_followups_id_seq OWNED BY public.contact_followups.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contacts (
    id integer NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text NOT NULL,
    phone text,
    company text,
    "position" text,
    address text,
    website text,
    notes text,
    "assignedTo" integer,
    "companyId" integer,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "alternatePhone" text,
    birthday timestamp(3) without time zone,
    "blacklistReason" text,
    city text,
    country text,
    department text,
    industry text,
    "isBlacklisted" boolean DEFAULT false NOT NULL,
    "lastContactedAt" timestamp(3) without time zone,
    "leadScore" integer DEFAULT 0,
    "linkedinProfile" text,
    "preferredContactMethod" text DEFAULT 'email'::text,
    "sourceLeadId" integer,
    state text,
    tags text[] DEFAULT ARRAY[]::text[],
    timezone text DEFAULT 'UTC'::text,
    "twitterHandle" text,
    "zipCode" text
);


ALTER TABLE public.contacts OWNER TO postgres;

--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacts_id_seq OWNER TO postgres;

--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: deal_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deal_products (
    id integer NOT NULL,
    "dealId" integer NOT NULL,
    name text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    price numeric(10,2) NOT NULL
);


ALTER TABLE public.deal_products OWNER TO postgres;

--
-- Name: deal_products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deal_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deal_products_id_seq OWNER TO postgres;

--
-- Name: deal_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.deal_products_id_seq OWNED BY public.deal_products.id;


--
-- Name: deals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deals (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    value numeric(65,30) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status public."DealStatus" DEFAULT 'DRAFT'::public."DealStatus" NOT NULL,
    probability integer DEFAULT 0 NOT NULL,
    "expectedCloseDate" timestamp(3) without time zone,
    "actualCloseDate" timestamp(3) without time zone,
    "assignedTo" integer,
    "contactId" integer,
    "leadId" integer,
    "companyId" integer,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.deals OWNER TO postgres;

--
-- Name: deals_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deals_id_seq OWNER TO postgres;

--
-- Name: deals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.deals_id_seq OWNED BY public.deals.id;


--
-- Name: files; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.files (
    id integer NOT NULL,
    name text NOT NULL,
    "fileName" text NOT NULL,
    "filePath" text NOT NULL,
    "fileSize" integer NOT NULL,
    "mimeType" text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" integer NOT NULL,
    "uploadedBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.files OWNER TO postgres;

--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.files_id_seq OWNER TO postgres;

--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- Name: industries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.industries (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.industries OWNER TO postgres;

--
-- Name: industries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.industries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.industries_id_seq OWNER TO postgres;

--
-- Name: industries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.industries_id_seq OWNED BY public.industries.id;


--
-- Name: industry_fields; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.industry_fields (
    id integer NOT NULL,
    "industryId" integer NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    type public."FieldType" DEFAULT 'TEXT'::public."FieldType" NOT NULL,
    "isRequired" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.industry_fields OWNER TO postgres;

--
-- Name: industry_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.industry_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.industry_fields_id_seq OWNER TO postgres;

--
-- Name: industry_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.industry_fields_id_seq OWNED BY public.industry_fields.id;


--
-- Name: integration_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integration_logs (
    id integer NOT NULL,
    "integrationId" integer NOT NULL,
    operation text NOT NULL,
    status public."IntegrationLogStatus" DEFAULT 'PENDING'::public."IntegrationLogStatus" NOT NULL,
    message text,
    data jsonb,
    "errorDetails" text,
    "recordsCount" integer DEFAULT 0,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.integration_logs OWNER TO postgres;

--
-- Name: integration_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.integration_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.integration_logs_id_seq OWNER TO postgres;

--
-- Name: integration_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.integration_logs_id_seq OWNED BY public.integration_logs.id;


--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_items (
    id integer NOT NULL,
    "invoiceId" integer NOT NULL,
    "productId" integer,
    name text NOT NULL,
    description text,
    quantity numeric(10,2) NOT NULL,
    unit text DEFAULT 'pcs'::text,
    "unitPrice" numeric(10,2) NOT NULL,
    "taxRate" numeric(5,2) DEFAULT 0 NOT NULL,
    "discountRate" numeric(5,2) DEFAULT 0 NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.invoice_items OWNER TO postgres;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoice_items_id_seq OWNER TO postgres;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoice_items_id_seq OWNED BY public.invoice_items.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    "invoiceNumber" text NOT NULL,
    title text NOT NULL,
    description text,
    status public."InvoiceStatus" DEFAULT 'DRAFT'::public."InvoiceStatus" NOT NULL,
    subtotal numeric(12,2) NOT NULL,
    "taxAmount" numeric(12,2) NOT NULL,
    "discountAmount" numeric(12,2) DEFAULT 0 NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL,
    "paidAmount" numeric(12,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "dueDate" timestamp(3) without time zone,
    notes text,
    terms text,
    "companyId" integer,
    "leadId" integer,
    "dealId" integer,
    "contactId" integer,
    "quotationId" integer,
    "createdBy" integer NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "viewedAt" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoices_id_seq OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: lead_assignment_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_assignment_rules (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lead_assignment_rules OWNER TO postgres;

--
-- Name: lead_assignment_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lead_assignment_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_assignment_rules_id_seq OWNER TO postgres;

--
-- Name: lead_assignment_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lead_assignment_rules_id_seq OWNED BY public.lead_assignment_rules.id;


--
-- Name: lead_communications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_communications (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "userId" integer NOT NULL,
    type public."CommunicationType" NOT NULL,
    subject text,
    content text NOT NULL,
    direction text DEFAULT 'outbound'::text NOT NULL,
    duration integer,
    outcome text,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lead_communications OWNER TO postgres;

--
-- Name: lead_communications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lead_communications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_communications_id_seq OWNER TO postgres;

--
-- Name: lead_communications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lead_communications_id_seq OWNED BY public.lead_communications.id;


--
-- Name: lead_followups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_followups (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "userId" integer NOT NULL,
    type public."CommunicationType" DEFAULT 'NOTE'::public."CommunicationType" NOT NULL,
    subject text NOT NULL,
    notes text,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "isCompleted" boolean DEFAULT false NOT NULL,
    "reminderSet" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lead_followups OWNER TO postgres;

--
-- Name: lead_followups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lead_followups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_followups_id_seq OWNER TO postgres;

--
-- Name: lead_followups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lead_followups_id_seq OWNED BY public.lead_followups.id;


--
-- Name: lead_import_batches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_import_batches (
    id integer NOT NULL,
    "fileName" text NOT NULL,
    "totalRows" integer NOT NULL,
    "successRows" integer DEFAULT 0 NOT NULL,
    "failedRows" integer DEFAULT 0 NOT NULL,
    status public."LeadImportStatus" DEFAULT 'PROCESSING'::public."LeadImportStatus" NOT NULL,
    "errorDetails" jsonb,
    "createdBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lead_import_batches OWNER TO postgres;

--
-- Name: lead_import_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lead_import_batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_import_batches_id_seq OWNER TO postgres;

--
-- Name: lead_import_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lead_import_batches_id_seq OWNED BY public.lead_import_batches.id;


--
-- Name: lead_import_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_import_records (
    id integer NOT NULL,
    "batchId" integer NOT NULL,
    "rowIndex" integer NOT NULL,
    "leadId" integer,
    status public."LeadImportStatus" DEFAULT 'PROCESSING'::public."LeadImportStatus" NOT NULL,
    errors jsonb,
    "rawData" jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lead_import_records OWNER TO postgres;

--
-- Name: lead_import_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lead_import_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_import_records_id_seq OWNER TO postgres;

--
-- Name: lead_import_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lead_import_records_id_seq OWNED BY public.lead_import_records.id;


--
-- Name: lead_integration_sync; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_integration_sync (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "integrationId" integer NOT NULL,
    "externalId" text NOT NULL,
    "externalData" jsonb,
    "syncStatus" public."LeadSyncStatus" DEFAULT 'SYNCED'::public."LeadSyncStatus" NOT NULL,
    "lastSyncAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lead_integration_sync OWNER TO postgres;

--
-- Name: lead_integration_sync_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lead_integration_sync_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_integration_sync_id_seq OWNER TO postgres;

--
-- Name: lead_integration_sync_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lead_integration_sync_id_seq OWNED BY public.lead_integration_sync.id;


--
-- Name: lead_sources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_sources (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "companyId" integer
);


ALTER TABLE public.lead_sources OWNER TO postgres;

--
-- Name: lead_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lead_sources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_sources_id_seq OWNER TO postgres;

--
-- Name: lead_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lead_sources_id_seq OWNED BY public.lead_sources.id;


--
-- Name: lead_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_tags (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "tagId" integer NOT NULL
);


ALTER TABLE public.lead_tags OWNER TO postgres;

--
-- Name: lead_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lead_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_tags_id_seq OWNER TO postgres;

--
-- Name: lead_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lead_tags_id_seq OWNED BY public.lead_tags.id;


--
-- Name: leads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leads (
    id integer NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text NOT NULL,
    phone text,
    company text,
    "position" text,
    status public."LeadStatus" DEFAULT 'NEW'::public."LeadStatus" NOT NULL,
    notes text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "sourceId" integer,
    "assignedTo" integer,
    "companyId" integer,
    "deletedAt" timestamp(3) without time zone,
    budget numeric(10,2),
    "convertedToContactId" integer,
    "lastContactedAt" timestamp(3) without time zone,
    "nextFollowUpAt" timestamp(3) without time zone,
    priority public."LeadPriority" DEFAULT 'MEDIUM'::public."LeadPriority" NOT NULL,
    industry text,
    website text,
    "companySize" integer,
    "annualRevenue" numeric(15,2),
    "leadScore" integer,
    address text,
    country text,
    state text,
    city text,
    "zipCode" text,
    "linkedinProfile" text,
    timezone text,
    "preferredContactMethod" text DEFAULT 'email'::text,
    currency text DEFAULT 'USD'::text
);


ALTER TABLE public.leads OWNER TO postgres;

--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.leads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.leads_id_seq OWNER TO postgres;

--
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.leads_id_seq OWNED BY public.leads.id;


--
-- Name: login_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_sessions (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token text NOT NULL,
    "deviceInfo" text,
    "ipAddress" text,
    "userAgent" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastUsedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.login_sessions OWNER TO postgres;

--
-- Name: login_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.login_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.login_sessions_id_seq OWNER TO postgres;

--
-- Name: login_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.login_sessions_id_seq OWNED BY public.login_sessions.id;


--
-- Name: password_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_history (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.password_history OWNER TO postgres;

--
-- Name: password_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.password_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.password_history_id_seq OWNER TO postgres;

--
-- Name: password_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.password_history_id_seq OWNED BY public.password_history.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    "invoiceId" integer NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "paymentMethod" text NOT NULL,
    "paymentDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "referenceNumber" text,
    notes text,
    "createdBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    description text,
    module text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    sku text,
    type public."ProductType" DEFAULT 'PHYSICAL'::public."ProductType" NOT NULL,
    category text,
    price numeric(10,2) NOT NULL,
    cost numeric(10,2),
    currency text DEFAULT 'USD'::text NOT NULL,
    unit text DEFAULT 'pcs'::text,
    "taxRate" numeric(5,2),
    "isActive" boolean DEFAULT true NOT NULL,
    "stockQuantity" integer DEFAULT 0,
    "minStockLevel" integer DEFAULT 0,
    "maxStockLevel" integer DEFAULT 0,
    image text,
    "companyId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: proposal_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proposal_templates (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    content text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "headerHtml" text,
    "footerHtml" text,
    styles jsonb,
    variables jsonb,
    "previewImage" text,
    category text DEFAULT 'business'::text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.proposal_templates OWNER TO postgres;

--
-- Name: proposal_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.proposal_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proposal_templates_id_seq OWNER TO postgres;

--
-- Name: proposal_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.proposal_templates_id_seq OWNED BY public.proposal_templates.id;


--
-- Name: quotation_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotation_items (
    id integer NOT NULL,
    "quotationId" integer NOT NULL,
    "productId" integer,
    name text NOT NULL,
    description text,
    quantity numeric(10,2) NOT NULL,
    unit text DEFAULT 'pcs'::text,
    "unitPrice" numeric(10,2) NOT NULL,
    "taxRate" numeric(5,2) DEFAULT 0 NOT NULL,
    "discountRate" numeric(5,2) DEFAULT 0 NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.quotation_items OWNER TO postgres;

--
-- Name: quotation_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotation_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quotation_items_id_seq OWNER TO postgres;

--
-- Name: quotation_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotation_items_id_seq OWNED BY public.quotation_items.id;


--
-- Name: quotation_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotation_templates (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "headerContent" text,
    "footerContent" text,
    "termsAndConditions" text,
    "validityDays" integer DEFAULT 30 NOT NULL,
    "showTax" boolean DEFAULT true NOT NULL,
    "showDiscount" boolean DEFAULT true NOT NULL,
    "logoPosition" text DEFAULT 'left'::text NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    styles jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.quotation_templates OWNER TO postgres;

--
-- Name: quotation_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotation_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quotation_templates_id_seq OWNER TO postgres;

--
-- Name: quotation_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotation_templates_id_seq OWNED BY public.quotation_templates.id;


--
-- Name: quotations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotations (
    id integer NOT NULL,
    "quotationNumber" text NOT NULL,
    title text NOT NULL,
    description text,
    status public."QuotationStatus" DEFAULT 'DRAFT'::public."QuotationStatus" NOT NULL,
    subtotal numeric(12,2) NOT NULL,
    "taxAmount" numeric(12,2) NOT NULL,
    "discountAmount" numeric(12,2) DEFAULT 0 NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "validUntil" timestamp(3) without time zone,
    notes text,
    terms text,
    "companyId" integer,
    "leadId" integer,
    "dealId" integer,
    "contactId" integer,
    "createdBy" integer NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "viewedAt" timestamp(3) without time zone,
    "acceptedAt" timestamp(3) without time zone,
    "rejectedAt" timestamp(3) without time zone,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.quotations OWNER TO postgres;

--
-- Name: quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.quotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quotations_id_seq OWNER TO postgres;

--
-- Name: quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.quotations_id_seq OWNED BY public.quotations.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refresh_tokens (
    id integer NOT NULL,
    token text NOT NULL,
    "userId" integer NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "isRevoked" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO postgres;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.refresh_tokens_id_seq OWNER TO postgres;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    id integer NOT NULL,
    "roleId" integer NOT NULL,
    "permissionId" integer NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_permissions_id_seq OWNER TO postgres;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "accessScope" public."RoleAccessScope" DEFAULT 'OWN'::public."RoleAccessScope" NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: super_admin_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.super_admin_permissions (
    id integer NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    description text,
    module text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.super_admin_permissions OWNER TO postgres;

--
-- Name: super_admin_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.super_admin_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.super_admin_permissions_id_seq OWNER TO postgres;

--
-- Name: super_admin_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.super_admin_permissions_id_seq OWNED BY public.super_admin_permissions.id;


--
-- Name: super_admin_role_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.super_admin_role_assignments (
    id integer NOT NULL,
    "superAdminId" integer NOT NULL,
    "roleId" integer NOT NULL
);


ALTER TABLE public.super_admin_role_assignments OWNER TO postgres;

--
-- Name: super_admin_role_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.super_admin_role_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.super_admin_role_assignments_id_seq OWNER TO postgres;

--
-- Name: super_admin_role_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.super_admin_role_assignments_id_seq OWNED BY public.super_admin_role_assignments.id;


--
-- Name: super_admin_role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.super_admin_role_permissions (
    id integer NOT NULL,
    "roleId" integer NOT NULL,
    "permissionId" integer NOT NULL
);


ALTER TABLE public.super_admin_role_permissions OWNER TO postgres;

--
-- Name: super_admin_role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.super_admin_role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.super_admin_role_permissions_id_seq OWNER TO postgres;

--
-- Name: super_admin_role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.super_admin_role_permissions_id_seq OWNED BY public.super_admin_role_permissions.id;


--
-- Name: super_admin_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.super_admin_roles (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.super_admin_roles OWNER TO postgres;

--
-- Name: super_admin_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.super_admin_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.super_admin_roles_id_seq OWNER TO postgres;

--
-- Name: super_admin_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.super_admin_roles_id_seq OWNED BY public.super_admin_roles.id;


--
-- Name: super_admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.super_admins (
    id integer NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "profilePicture" text
);


ALTER TABLE public.super_admins OWNER TO postgres;

--
-- Name: super_admins_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.super_admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.super_admins_id_seq OWNER TO postgres;

--
-- Name: super_admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.super_admins_id_seq OWNED BY public.super_admins.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    name text NOT NULL,
    color text DEFAULT '#3B82F6'::text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "companyId" integer
);


ALTER TABLE public.tags OWNER TO postgres;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_id_seq OWNER TO postgres;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    status public."TaskStatus" DEFAULT 'PENDING'::public."TaskStatus" NOT NULL,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "assignedTo" integer,
    "createdBy" integer NOT NULL,
    "leadId" integer,
    "dealId" integer,
    "contactId" integer,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_seq OWNER TO postgres;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: third_party_integrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.third_party_integrations (
    id integer NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "apiEndpoint" text NOT NULL,
    "authType" public."IntegrationAuthType" DEFAULT 'API_KEY'::public."IntegrationAuthType" NOT NULL,
    config jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.third_party_integrations OWNER TO postgres;

--
-- Name: third_party_integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.third_party_integrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.third_party_integrations_id_seq OWNER TO postgres;

--
-- Name: third_party_integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.third_party_integrations_id_seq OWNED BY public.third_party_integrations.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "roleId" integer NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_roles_id_seq OWNER TO postgres;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "profilePicture" text,
    "companyId" integer,
    "deletedAt" timestamp(3) without time zone,
    "accountLockedUntil" timestamp(3) without time zone,
    "emailVerificationToken" text,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "emailVerifiedAt" timestamp(3) without time zone,
    "failedLoginAttempts" integer DEFAULT 0 NOT NULL,
    "passwordResetExpires" timestamp(3) without time zone,
    "passwordResetToken" text,
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "twoFactorSecret" text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);


--
-- Name: business_settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_settings ALTER COLUMN id SET DEFAULT nextval('public.business_settings_id_seq'::regclass);


--
-- Name: call_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.call_logs ALTER COLUMN id SET DEFAULT nextval('public.call_logs_id_seq'::regclass);


--
-- Name: communication_automations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_automations ALTER COLUMN id SET DEFAULT nextval('public.communication_automations_id_seq'::regclass);


--
-- Name: communication_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_messages ALTER COLUMN id SET DEFAULT nextval('public.communication_messages_id_seq'::regclass);


--
-- Name: communication_providers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_providers ALTER COLUMN id SET DEFAULT nextval('public.communication_providers_id_seq'::regclass);


--
-- Name: communication_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_templates ALTER COLUMN id SET DEFAULT nextval('public.communication_templates_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: company_activities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_activities ALTER COLUMN id SET DEFAULT nextval('public.company_activities_id_seq'::regclass);


--
-- Name: company_communications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_communications ALTER COLUMN id SET DEFAULT nextval('public.company_communications_id_seq'::regclass);


--
-- Name: company_followups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_followups ALTER COLUMN id SET DEFAULT nextval('public.company_followups_id_seq'::regclass);


--
-- Name: contact_activities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_activities ALTER COLUMN id SET DEFAULT nextval('public.contact_activities_id_seq'::regclass);


--
-- Name: contact_communications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_communications ALTER COLUMN id SET DEFAULT nextval('public.contact_communications_id_seq'::regclass);


--
-- Name: contact_followups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_followups ALTER COLUMN id SET DEFAULT nextval('public.contact_followups_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: deal_products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deal_products ALTER COLUMN id SET DEFAULT nextval('public.deal_products_id_seq'::regclass);


--
-- Name: deals id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deals ALTER COLUMN id SET DEFAULT nextval('public.deals_id_seq'::regclass);


--
-- Name: files id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- Name: industries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industries ALTER COLUMN id SET DEFAULT nextval('public.industries_id_seq'::regclass);


--
-- Name: industry_fields id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industry_fields ALTER COLUMN id SET DEFAULT nextval('public.industry_fields_id_seq'::regclass);


--
-- Name: integration_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_logs ALTER COLUMN id SET DEFAULT nextval('public.integration_logs_id_seq'::regclass);


--
-- Name: invoice_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_items_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: lead_assignment_rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_assignment_rules ALTER COLUMN id SET DEFAULT nextval('public.lead_assignment_rules_id_seq'::regclass);


--
-- Name: lead_communications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_communications ALTER COLUMN id SET DEFAULT nextval('public.lead_communications_id_seq'::regclass);


--
-- Name: lead_followups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_followups ALTER COLUMN id SET DEFAULT nextval('public.lead_followups_id_seq'::regclass);


--
-- Name: lead_import_batches id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_import_batches ALTER COLUMN id SET DEFAULT nextval('public.lead_import_batches_id_seq'::regclass);


--
-- Name: lead_import_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_import_records ALTER COLUMN id SET DEFAULT nextval('public.lead_import_records_id_seq'::regclass);


--
-- Name: lead_integration_sync id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_integration_sync ALTER COLUMN id SET DEFAULT nextval('public.lead_integration_sync_id_seq'::regclass);


--
-- Name: lead_sources id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_sources ALTER COLUMN id SET DEFAULT nextval('public.lead_sources_id_seq'::regclass);


--
-- Name: lead_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_tags ALTER COLUMN id SET DEFAULT nextval('public.lead_tags_id_seq'::regclass);


--
-- Name: leads id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads ALTER COLUMN id SET DEFAULT nextval('public.leads_id_seq'::regclass);


--
-- Name: login_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_sessions ALTER COLUMN id SET DEFAULT nextval('public.login_sessions_id_seq'::regclass);


--
-- Name: password_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_history ALTER COLUMN id SET DEFAULT nextval('public.password_history_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: proposal_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proposal_templates ALTER COLUMN id SET DEFAULT nextval('public.proposal_templates_id_seq'::regclass);


--
-- Name: quotation_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_items ALTER COLUMN id SET DEFAULT nextval('public.quotation_items_id_seq'::regclass);


--
-- Name: quotation_templates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_templates ALTER COLUMN id SET DEFAULT nextval('public.quotation_templates_id_seq'::regclass);


--
-- Name: quotations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotations ALTER COLUMN id SET DEFAULT nextval('public.quotations_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: super_admin_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_permissions ALTER COLUMN id SET DEFAULT nextval('public.super_admin_permissions_id_seq'::regclass);


--
-- Name: super_admin_role_assignments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_role_assignments ALTER COLUMN id SET DEFAULT nextval('public.super_admin_role_assignments_id_seq'::regclass);


--
-- Name: super_admin_role_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_role_permissions ALTER COLUMN id SET DEFAULT nextval('public.super_admin_role_permissions_id_seq'::regclass);


--
-- Name: super_admin_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_roles ALTER COLUMN id SET DEFAULT nextval('public.super_admin_roles_id_seq'::regclass);


--
-- Name: super_admins id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admins ALTER COLUMN id SET DEFAULT nextval('public.super_admins_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: third_party_integrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.third_party_integrations ALTER COLUMN id SET DEFAULT nextval('public.third_party_integrations_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activities (id, title, description, type, icon, "iconColor", tags, metadata, "createdAt", "updatedAt", "userId", "superAdminId") FROM stdin;
1	User Login	Admin User logged in	USER_LOGIN	FiLogIn	text-green-600	{User,Login}	{"email": "admin@crm.com", "userId": 1}	2025-10-19 14:13:25.444	2025-10-19 14:13:25.444	1	\N
2	New Lead Created	Lead mohit SHrivastava (mohit@test.com) was created	LEAD_CREATED	FiPlus	text-green-600	{Lead,Creation}	{"email": "mohit@test.com", "leadId": 1}	2025-10-19 14:17:44.64	2025-10-19 14:17:44.64	1	\N
3	User Login	Admin User logged in	USER_LOGIN	FiLogIn	text-green-600	{User,Login}	{"email": "admin@crm.com", "userId": 1}	2025-10-19 14:26:16.544	2025-10-19 14:26:16.544	1	\N
4	User Login	Admin User logged in	USER_LOGIN	FiLogIn	text-green-600	{User,Login}	{"email": "admin@crm.com", "userId": 1}	2025-10-19 14:47:07.478	2025-10-19 14:47:07.478	1	\N
5	User Login	Admin User logged in	USER_LOGIN	FiLogIn	text-green-600	{User,Login}	{"email": "admin@crm.com", "userId": 1}	2025-10-19 14:51:32.204	2025-10-19 14:51:32.204	1	\N
6	User Login	Admin User logged in	USER_LOGIN	FiLogIn	text-green-600	{User,Login}	{"email": "admin@crm.com", "userId": 1}	2025-10-19 14:53:07.801	2025-10-19 14:53:07.801	1	\N
7	User Login	Admin User logged in	USER_LOGIN	FiLogIn	text-green-600	{User,Login}	{"email": "admin@crm.com", "userId": 1}	2025-10-19 14:53:29.67	2025-10-19 14:53:29.67	1	\N
8	User Login	Admin User logged in	USER_LOGIN	FiLogIn	text-green-600	{User,Login}	{"email": "admin@crm.com", "userId": 1}	2025-10-19 15:01:44.797	2025-10-19 15:01:44.797	1	\N
9	User Login	Admin User logged in	USER_LOGIN	FiLogIn	text-green-600	{User,Login}	{"email": "admin@crm.com", "userId": 1}	2025-10-19 15:19:19.072	2025-10-19 15:19:19.072	1	\N
10	User Login	Admin User logged in	USER_LOGIN	FiLogIn	text-green-600	{User,Login}	{"email": "admin@crm.com", "userId": 1}	2025-10-19 17:32:47.38	2025-10-19 17:32:47.38	1	\N
11	User Login	Admin User logged in	USER_LOGIN	FiLogIn	text-green-600	{User,Login}	{"email": "admin@crm.com", "userId": 1}	2025-10-19 17:53:58.917	2025-10-19 17:53:58.917	1	\N
12	User Login	Admin User logged in	USER_LOGIN	FiLogIn	text-green-600	{User,Login}	{"email": "admin@crm.com", "userId": 1}	2025-10-19 18:12:37.554	2025-10-19 18:12:37.554	1	\N
13	Lead Updated	Lead mohit SHrivastava (mohit@test.com) was updated	LEAD_UPDATED	FiEdit	text-blue-600	{Lead,Update}	{"email": "mohit@test.com", "leadId": 1}	2025-10-19 18:39:07.999	2025-10-19 18:39:07.999	1	\N
14	Task created	Task "ewww" created and assigned.	TASK_CREATED	CheckCircle	text-orange-600	{}	{"dealId": null, "leadId": null, "taskId": 1, "dueDate": "2025-11-03T00:00:00.000Z", "priority": "MEDIUM", "contactId": null, "assignedTo": 1}	2025-11-03 10:49:33.106	2025-11-03 10:49:33.106	1	\N
15	Task created	Task "ok" created and assigned.	TASK_CREATED	CheckCircle	text-orange-600	{}	{"dealId": null, "leadId": null, "taskId": 2, "dueDate": "2025-11-03T00:00:00.000Z", "priority": "LOW", "contactId": null, "assignedTo": 1}	2025-11-03 12:35:32.841	2025-11-03 12:35:32.841	1	\N
16	Task created	Task "ok" created and assigned.	TASK_CREATED	CheckCircle	text-orange-600	{}	{"dealId": null, "leadId": 3, "taskId": 3, "dueDate": null, "priority": "MEDIUM", "contactId": null, "assignedTo": 1}	2025-11-03 12:38:11.86	2025-11-03 12:38:11.86	1	\N
\.


--
-- Data for Name: business_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.business_settings (id, "companyName", "companyEmail", "companyPhone", "companyAddress", "companyWebsite", "companyLogo", "timeZone", "dateFormat", currency, "passwordMinLength", "passwordRequireUpper", "passwordRequireLower", "passwordRequireNumber", "passwordRequireSymbol", "sessionTimeout", "maxLoginAttempts", "accountLockDuration", "twoFactorRequired", "emailVerificationRequired", "createdAt", "updatedAt", "leadAutoAssignmentEnabled", "leadFollowUpReminderDays", "cinNumber", description, "employeeCount", "fiscalYearStart", "gstNumber", "indiamartApiKey", "indiamartApiSecret", "indiamartEnabled", industry, "metaAdsApiKey", "metaAdsApiSecret", "metaAdsEnabled", "panNumber", "tradindiaApiKey", "tradindiaApiSecret", "tradindiaEnabled") FROM stdin;
1	We- connect	admin@weconnect-crm.com	+1-234-567-8900	123 Business Street, City, State 12345	https://weconnect-crm.com	\N	UTC	MM/DD/YYYY	USD	8	t	t	t	t	24	5	30	f	f	2025-10-19 13:45:41.885	2025-11-03 12:29:52.781	f	3			11-50			\N	\N	f	Technology	\N	\N	f		\N	\N	f
\.


--
-- Data for Name: call_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.call_logs (id, "leadId", "userId", "phoneNumber", "callType", "callStatus", duration, "startTime", "endTime", notes, outcome, "recordingUrl", "isAnswered", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: communication_automations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.communication_automations (id, name, "triggerType", "templateId", "isActive", conditions, delay, "companyId", "createdBy", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: communication_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.communication_messages (id, "leadId", "userId", "templateId", type, recipient, subject, content, status, "sentAt", "deliveredAt", "readAt", "failedAt", "errorMessage", "externalId", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: communication_providers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.communication_providers (id, name, type, config, "isActive", "isDefault", "companyId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: communication_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.communication_templates (id, name, type, subject, content, variables, "isActive", "isDefault", "companyId", "createdBy", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, name, "createdAt", "updatedAt", domain, "isActive", slug, "industryId", address, "alternatePhone", "annualRevenue", "assignedTo", city, "companySize", country, currency, "deletedAt", description, email, "employeeCount", "facebookPage", "foundedYear", "lastContactedAt", "leadScore", "linkedinProfile", "nextFollowUpAt", notes, "parentCompanyId", phone, state, status, tags, timezone, "twitterHandle", website, "zipCode") FROM stdin;
1	bellway	2025-11-03 10:46:42.739	2025-11-03 10:46:42.738	http .com	t	bellway	\N	\N	\N	\N	\N	\N	SMALL	\N	USD	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	ACTIVE	{}	UTC	\N	\N	\N
2	Bellway Infotech 	2025-11-03 11:10:06.547	2025-11-03 11:10:06.546	\N	t	bellway-infotech-	\N	\N	\N	\N	\N	\N	SMALL	\N	USD	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	ACTIVE	{}	UTC	\N	\N	\N
\.


--
-- Data for Name: company_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_activities (id, "companyId", "userId", type, title, description, duration, outcome, "scheduledAt", "completedAt", "isCompleted", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: company_communications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_communications (id, "companyId", "userId", type, subject, content, direction, status, "scheduledAt", "sentAt", "deliveredAt", "readAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: company_followups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_followups (id, "companyId", "userId", type, subject, notes, priority, "scheduledAt", "completedAt", "isCompleted", "reminderSet", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: contact_activities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_activities (id, "contactId", "userId", type, title, description, duration, outcome, "scheduledAt", "completedAt", "isCompleted", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: contact_communications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_communications (id, "contactId", "userId", type, subject, content, direction, status, "scheduledAt", "sentAt", "deliveredAt", "readAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: contact_followups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_followups (id, "contactId", "userId", type, subject, notes, priority, "scheduledAt", "completedAt", "isCompleted", "reminderSet", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contacts (id, "firstName", "lastName", email, phone, company, "position", address, website, notes, "assignedTo", "companyId", "isActive", "createdAt", "updatedAt", "deletedAt", "alternatePhone", birthday, "blacklistReason", city, country, department, industry, "isBlacklisted", "lastContactedAt", "leadScore", "linkedinProfile", "preferredContactMethod", "sourceLeadId", state, tags, timezone, "twitterHandle", "zipCode") FROM stdin;
1	Aakriti	Shrivastava	aakriti@mail.com	09893166409	bellway	AME	Gravity mall 5th floor (Mechanical nagar front of NueGo lounge)	http .com	sds	1	\N	t	2025-11-03 10:46:42.728	2025-11-03 10:46:42.728	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0	\N	email	\N	\N	{}	UTC	\N	\N
2	mohit	SHrivastava	mohit@test.com	+919098466409	Bellway Infotech 	CEO 	\N	\N	He is looking for CRM 	1	\N	t	2025-11-03 11:10:06.536	2025-11-03 11:10:06.536	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0	\N	email	\N	\N	{}	UTC	\N	\N
3	sourabh	soni	sourabh@gmail.com	91316020123	bellway	ASM	Gravity mall 5th floor (Mechanical nagar front of NueGo lounge)	http://localhost:5173/leads/new		\N	\N	t	2025-11-03 12:14:46.404	2025-11-03 12:14:46.404	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0	\N	email	\N	\N	{}	UTC	\N	\N
\.


--
-- Data for Name: deal_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deal_products (id, "dealId", name, quantity, price) FROM stdin;
\.


--
-- Data for Name: deals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deals (id, title, description, value, currency, status, probability, "expectedCloseDate", "actualCloseDate", "assignedTo", "contactId", "leadId", "companyId", "isActive", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	Deal with Aakriti Shrivastava	Deal opportunity from lead conversion	2000.000000000000000000000000000000	USD	DRAFT	50	\N	\N	1	1	2	1	t	2025-11-03 10:46:42.745	2025-11-03 10:46:42.745	\N
2	Deal with sourabh soni	Deal opportunity from lead conversion	0.000000000000000000000000000000	USD	DRAFT	50	\N	\N	\N	3	3	1	t	2025-11-03 12:14:46.41	2025-11-03 12:14:46.41	\N
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.files (id, name, "fileName", "filePath", "fileSize", "mimeType", "entityType", "entityId", "uploadedBy", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	favicon.ico	file-1762168301902-448402630.ico	/uploads/file-1762168301902-448402630.ico	15086	image/vnd.microsoft.icon	lead	2	1	2025-11-03 11:11:41.911	2025-11-03 11:11:41.911	\N
\.


--
-- Data for Name: industries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.industries (id, name, slug, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: industry_fields; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.industry_fields (id, "industryId", name, key, type, "isRequired", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: integration_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integration_logs (id, "integrationId", operation, status, message, data, "errorDetails", "recordsCount", "createdAt") FROM stdin;
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_items (id, "invoiceId", "productId", name, description, quantity, unit, "unitPrice", "taxRate", "discountRate", subtotal, "totalAmount", "sortOrder", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, "invoiceNumber", title, description, status, subtotal, "taxAmount", "discountAmount", "totalAmount", "paidAmount", currency, "dueDate", notes, terms, "companyId", "leadId", "dealId", "contactId", "quotationId", "createdBy", "sentAt", "viewedAt", "paidAt", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: lead_assignment_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_assignment_rules (id, name, description, "isActive", conditions, actions, priority, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lead_communications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_communications (id, "leadId", "userId", type, subject, content, direction, duration, outcome, "scheduledAt", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lead_followups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_followups (id, "leadId", "userId", type, subject, notes, "scheduledAt", "completedAt", "isCompleted", "reminderSet", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lead_import_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_import_batches (id, "fileName", "totalRows", "successRows", "failedRows", status, "errorDetails", "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lead_import_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_import_records (id, "batchId", "rowIndex", "leadId", status, errors, "rawData", "createdAt") FROM stdin;
\.


--
-- Data for Name: lead_integration_sync; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_integration_sync (id, "leadId", "integrationId", "externalId", "externalData", "syncStatus", "lastSyncAt", "errorMessage", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lead_sources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_sources (id, name, description, "isActive", "createdAt", "updatedAt", "companyId") FROM stdin;
1	Website	Lead came from company website	t	2025-10-19 13:45:41.867	2025-10-19 18:21:50.179	\N
2	LinkedIn	Lead came from LinkedIn	t	2025-10-19 13:45:41.869	2025-10-19 18:21:50.18	\N
3	Referral	Lead came from customer referral	t	2025-10-19 13:45:41.869	2025-10-19 18:21:50.181	\N
4	Cold Call	Lead came from cold calling	t	2025-10-19 13:45:41.87	2025-10-19 18:21:50.181	\N
5	Email	Lead came from email campaign	t	2025-10-19 13:45:41.87	2025-10-19 18:21:50.182	\N
6	Social Media	Lead came from social media	t	2025-10-19 13:45:41.871	2025-10-19 18:21:50.182	\N
7	Trade Show	Lead came from trade show	t	2025-10-19 13:45:41.871	2025-10-19 18:21:50.183	\N
8	Other	Lead came from other sources	t	2025-10-19 13:45:41.872	2025-10-19 18:21:50.183	\N
\.


--
-- Data for Name: lead_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_tags (id, "leadId", "tagId") FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leads (id, "firstName", "lastName", email, phone, company, "position", status, notes, "isActive", "createdAt", "updatedAt", "sourceId", "assignedTo", "companyId", "deletedAt", budget, "convertedToContactId", "lastContactedAt", "nextFollowUpAt", priority, industry, website, "companySize", "annualRevenue", "leadScore", address, country, state, city, "zipCode", "linkedinProfile", timezone, "preferredContactMethod", currency) FROM stdin;
2	Aakriti	Shrivastava	aakriti@mail.com	09893166409	bellway	AME	CONVERTED	sds	t	2025-11-03 10:46:12.733	2025-11-03 10:46:42.75	4	1	\N	\N	2000.00	1	\N	2025-11-03 10:46:00	MEDIUM	IT	http .com	3	10000.00	0	Gravity mall 5th floor (Mechanical nagar front of NueGo lounge)	India	Madhya Pradesh	Indore	452001	http://localhost:5173/leads/new		email	USD
1	mohit	SHrivastava	mohit@test.com	+919098466409	Bellway Infotech 	CEO 	CONVERTED	He is looking for CRM 	t	2025-10-19 14:17:44.616	2025-11-03 11:10:06.55	\N	1	\N	\N	\N	2	\N	\N	MEDIUM	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	email	USD
3	sourabh	soni	sourabh@gmail.com	91316020123	bellway	ASM	CONVERTED		t	2025-11-03 12:13:55.257	2025-11-03 12:14:46.414	\N	\N	\N	\N	\N	3	\N	\N	MEDIUM	it	http://localhost:5173/leads/new	30	20000.00	\N	Gravity mall 5th floor (Mechanical nagar front of NueGo lounge)	India	Madhya Pradesh	Indore	452001	http://localhost:5173/leads/new	24	email	USD
4	Aakriti	Shrivastav	aakriti@mail.com	9131612123	bellway	ASE	NEW		t	2025-11-03 12:16:28.893	2025-11-03 12:16:28.893	\N	\N	\N	\N	\N	\N	\N	\N	MEDIUM	IT	http://localhost:5173/leads/new	50	200000.00	\N	Gravity mall 5th floor (Mechanical nagar front of NueGo lounge)	India	Madhya Pradesh	Indore	452001	http://localhost:5173/leads/new	24	email	USD
\.


--
-- Data for Name: login_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_sessions (id, "userId", token, "deviceInfo", "ipAddress", "userAgent", "isActive", "expiresAt", "createdAt", "lastUsedAt") FROM stdin;
1	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JtLmNvbSIsImRldmljZUlkIjoiZGV2aWNlXzB2ODVta3ZybHh0Ym1neHNlM3BwIiwiaXAiOiIxMjcuMC4wLjEiLCJ1c2VyQWdlbnQiOiJNb3ppbGxhLzUuMCAoWDExOyBMaW51eCBhYXJjaDY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTQxLjAuMC4wIFNhZmFyaS81MzcuMzYgQ3JLZXkvMS41NC4yNTAzMjAiLCJyb2xlcyI6W3siaWQiOjEsIm5hbWUiOiJBZG1pbiIsInBlcm1pc3Npb25zIjpbInVzZXIucmVhZCIsInVzZXIuY3JlYXRlIiwidXNlci51cGRhdGUiLCJ1c2VyLmRlbGV0ZSIsInJvbGUucmVhZCIsInJvbGUuY3JlYXRlIiwicm9sZS51cGRhdGUiLCJyb2xlLmRlbGV0ZSIsInBlcm1pc3Npb24ucmVhZCIsImRhc2hib2FyZC5yZWFkIiwic2V0dGluZ3MucmVhZCIsInNldHRpbmdzLnVwZGF0ZSIsImxlYWQucmVhZCIsImxlYWQuY3JlYXRlIiwibGVhZC51cGRhdGUiLCJsZWFkLmRlbGV0ZSIsImFjdGl2aXR5LnJlYWQiLCJhY3Rpdml0eS5jcmVhdGUiLCJkZWxldGVkLnJlYWQiLCJ0YXNrLnJlYWQiLCJ0YXNrLmNyZWF0ZSIsInRhc2sudXBkYXRlIiwidGFzay5kZWxldGUiLCJjb250YWN0LnJlYWQiLCJjb250YWN0LmNyZWF0ZSIsImNvbnRhY3QudXBkYXRlIiwiY29udGFjdC5kZWxldGUiLCJkZWFsLnJlYWQiLCJkZWFsLmNyZWF0ZSIsImRlYWwudXBkYXRlIiwiZGVhbC5kZWxldGUiXX1dLCJpYXQiOjE3NjA4ODMyMDUsImV4cCI6MTc2MDk2OTYwNX0.EInLPryXasBOqlYvVQQbHnZEm1UlGMu6AwVI_zkwNbc	Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 CrKey/1.54.250320	127.0.0.1	Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 CrKey/1.54.250320	t	2025-10-20 14:13:25.44	2025-10-19 14:13:25.441	2025-10-19 14:13:25.441
2	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JtLmNvbSIsImRldmljZUlkIjoiZGV2aWNlX2lpemxscWJjcWttZ3hxZnV0ZyIsImlwIjoiMTI3LjAuMC4xIiwidXNlckFnZW50IjoiTW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTBfMTVfNykgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzE0MS4wLjAuMCBTYWZhcmkvNTM3LjM2Iiwicm9sZXMiOlt7ImlkIjoxLCJuYW1lIjoiQWRtaW4iLCJwZXJtaXNzaW9ucyI6WyJ1c2VyLnJlYWQiLCJ1c2VyLmNyZWF0ZSIsInVzZXIudXBkYXRlIiwidXNlci5kZWxldGUiLCJyb2xlLnJlYWQiLCJyb2xlLmNyZWF0ZSIsInJvbGUudXBkYXRlIiwicm9sZS5kZWxldGUiLCJwZXJtaXNzaW9uLnJlYWQiLCJkYXNoYm9hcmQucmVhZCIsInNldHRpbmdzLnJlYWQiLCJzZXR0aW5ncy51cGRhdGUiLCJsZWFkLnJlYWQiLCJsZWFkLmNyZWF0ZSIsImxlYWQudXBkYXRlIiwibGVhZC5kZWxldGUiLCJhY3Rpdml0eS5yZWFkIiwiYWN0aXZpdHkuY3JlYXRlIiwiZGVsZXRlZC5yZWFkIiwidGFzay5yZWFkIiwidGFzay5jcmVhdGUiLCJ0YXNrLnVwZGF0ZSIsInRhc2suZGVsZXRlIiwiY29udGFjdC5yZWFkIiwiY29udGFjdC5jcmVhdGUiLCJjb250YWN0LnVwZGF0ZSIsImNvbnRhY3QuZGVsZXRlIiwiZGVhbC5yZWFkIiwiZGVhbC5jcmVhdGUiLCJkZWFsLnVwZGF0ZSIsImRlYWwuZGVsZXRlIl19XSwiaWF0IjoxNzYwODgzOTc2LCJleHAiOjE3NjA5NzAzNzZ9.XTo2JaOfZBlHC-oWHmFNR5cIKYrL7b2PhLQsSB9xn3c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-10-20 14:26:16.541	2025-10-19 14:26:16.542	2025-10-19 14:26:16.542
3	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JtLmNvbSIsImRldmljZUlkIjoiZGV2aWNlX3ExMXhncGl6bnhrbWd4dGxkbTgiLCJpcCI6IjEyNy4wLjAuMSIsInVzZXJBZ2VudCI6Ik1vemlsbGEvNS4wIChYMTE7IExpbnV4IGFhcmNoNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xNDEuMC4wLjAgU2FmYXJpLzUzNy4zNiBDcktleS8xLjU0LjI1MDMyMCIsInJvbGVzIjpbeyJpZCI6MSwibmFtZSI6IkFkbWluIiwicGVybWlzc2lvbnMiOlsidXNlci5yZWFkIiwidXNlci5jcmVhdGUiLCJ1c2VyLnVwZGF0ZSIsInVzZXIuZGVsZXRlIiwicm9sZS5yZWFkIiwicm9sZS5jcmVhdGUiLCJyb2xlLnVwZGF0ZSIsInJvbGUuZGVsZXRlIiwicGVybWlzc2lvbi5yZWFkIiwiZGFzaGJvYXJkLnJlYWQiLCJzZXR0aW5ncy5yZWFkIiwic2V0dGluZ3MudXBkYXRlIiwibGVhZC5yZWFkIiwibGVhZC5jcmVhdGUiLCJsZWFkLnVwZGF0ZSIsImxlYWQuZGVsZXRlIiwiYWN0aXZpdHkucmVhZCIsImFjdGl2aXR5LmNyZWF0ZSIsImRlbGV0ZWQucmVhZCIsInRhc2sucmVhZCIsInRhc2suY3JlYXRlIiwidGFzay51cGRhdGUiLCJ0YXNrLmRlbGV0ZSIsImNvbnRhY3QucmVhZCIsImNvbnRhY3QuY3JlYXRlIiwiY29udGFjdC51cGRhdGUiLCJjb250YWN0LmRlbGV0ZSIsImRlYWwucmVhZCIsImRlYWwuY3JlYXRlIiwiZGVhbC51cGRhdGUiLCJkZWFsLmRlbGV0ZSJdfV0sImlhdCI6MTc2MDg4NTIyNywiZXhwIjoxNzYwOTcxNjI3fQ.lq-C-eNBdkDBgG6qDq5sTM1Cn93wcrebdoV8sV-7uOs	Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 CrKey/1.54.250320	127.0.0.1	Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 CrKey/1.54.250320	t	2025-10-20 14:47:07.476	2025-10-19 14:47:07.477	2025-10-19 14:47:07.477
4	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JtLmNvbSIsImRldmljZUlkIjoiZGV2aWNlX2E5eDJrOGg1cDVtZ3h0cjRhOCIsImlwIjoiMTI3LjAuMC4xIiwidXNlckFnZW50IjoiTW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTBfMTVfNykgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzE0MS4wLjAuMCBTYWZhcmkvNTM3LjM2Iiwicm9sZXMiOlt7ImlkIjoxLCJuYW1lIjoiQWRtaW4iLCJwZXJtaXNzaW9ucyI6WyJ1c2VyLnJlYWQiLCJ1c2VyLmNyZWF0ZSIsInVzZXIudXBkYXRlIiwidXNlci5kZWxldGUiLCJyb2xlLnJlYWQiLCJyb2xlLmNyZWF0ZSIsInJvbGUudXBkYXRlIiwicm9sZS5kZWxldGUiLCJwZXJtaXNzaW9uLnJlYWQiLCJkYXNoYm9hcmQucmVhZCIsInNldHRpbmdzLnJlYWQiLCJzZXR0aW5ncy51cGRhdGUiLCJsZWFkLnJlYWQiLCJsZWFkLmNyZWF0ZSIsImxlYWQudXBkYXRlIiwibGVhZC5kZWxldGUiLCJhY3Rpdml0eS5yZWFkIiwiYWN0aXZpdHkuY3JlYXRlIiwiZGVsZXRlZC5yZWFkIiwidGFzay5yZWFkIiwidGFzay5jcmVhdGUiLCJ0YXNrLnVwZGF0ZSIsInRhc2suZGVsZXRlIiwiY29udGFjdC5yZWFkIiwiY29udGFjdC5jcmVhdGUiLCJjb250YWN0LnVwZGF0ZSIsImNvbnRhY3QuZGVsZXRlIiwiZGVhbC5yZWFkIiwiZGVhbC5jcmVhdGUiLCJkZWFsLnVwZGF0ZSIsImRlYWwuZGVsZXRlIl19XSwiaWF0IjoxNzYwODg1NDkyLCJleHAiOjE3NjA5NzE4OTJ9.umq1uwyKw-mhC_ZMvqgQGiMhV9SBSsCMsDA5s8lyBUQ	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-10-20 14:51:32.201	2025-10-19 14:51:32.202	2025-10-19 14:51:32.202
5	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JtLmNvbSIsImRldmljZUlkIjoiZGV2aWNlX3JnYnNmcW1icmFtZ3Z6Y2o1cSIsImlwIjoiMTI3LjAuMC4xIiwidXNlckFnZW50IjoiTW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTBfMTVfNykgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzE0MS4wLjAuMCBTYWZhcmkvNTM3LjM2Iiwicm9sZXMiOlt7ImlkIjoxLCJuYW1lIjoiQWRtaW4iLCJwZXJtaXNzaW9ucyI6WyJ1c2VyLnJlYWQiLCJ1c2VyLmNyZWF0ZSIsInVzZXIudXBkYXRlIiwidXNlci5kZWxldGUiLCJyb2xlLnJlYWQiLCJyb2xlLmNyZWF0ZSIsInJvbGUudXBkYXRlIiwicm9sZS5kZWxldGUiLCJwZXJtaXNzaW9uLnJlYWQiLCJkYXNoYm9hcmQucmVhZCIsInNldHRpbmdzLnJlYWQiLCJzZXR0aW5ncy51cGRhdGUiLCJsZWFkLnJlYWQiLCJsZWFkLmNyZWF0ZSIsImxlYWQudXBkYXRlIiwibGVhZC5kZWxldGUiLCJhY3Rpdml0eS5yZWFkIiwiYWN0aXZpdHkuY3JlYXRlIiwiZGVsZXRlZC5yZWFkIiwidGFzay5yZWFkIiwidGFzay5jcmVhdGUiLCJ0YXNrLnVwZGF0ZSIsInRhc2suZGVsZXRlIiwiY29udGFjdC5yZWFkIiwiY29udGFjdC5jcmVhdGUiLCJjb250YWN0LnVwZGF0ZSIsImNvbnRhY3QuZGVsZXRlIiwiZGVhbC5yZWFkIiwiZGVhbC5jcmVhdGUiLCJkZWFsLnVwZGF0ZSIsImRlYWwuZGVsZXRlIl19XSwiaWF0IjoxNzYwODg1NTg3LCJleHAiOjE3NjA5NzE5ODd9.4y-ZCfHXbolkDU9Qv6sVf69UeLIAzH1XF5FaYEpBg_c	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-10-20 14:53:07.798	2025-10-19 14:53:07.799	2025-10-19 14:53:07.799
6	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JtLmNvbSIsImRldmljZUlkIjoiZGV2aWNlX2VhN3A0a3VnaWlwbWd4cWhjaWMiLCJpcCI6IjEyNy4wLjAuMSIsInVzZXJBZ2VudCI6Ik1vemlsbGEvNS4wIChNYWNpbnRvc2g7IEludGVsIE1hYyBPUyBYIDEwXzE1XzcpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xNDEuMC4wLjAgU2FmYXJpLzUzNy4zNiIsInJvbGVzIjpbeyJpZCI6MSwibmFtZSI6IkFkbWluIiwicGVybWlzc2lvbnMiOlsidXNlci5yZWFkIiwidXNlci5jcmVhdGUiLCJ1c2VyLnVwZGF0ZSIsInVzZXIuZGVsZXRlIiwicm9sZS5yZWFkIiwicm9sZS5jcmVhdGUiLCJyb2xlLnVwZGF0ZSIsInJvbGUuZGVsZXRlIiwicGVybWlzc2lvbi5yZWFkIiwiZGFzaGJvYXJkLnJlYWQiLCJzZXR0aW5ncy5yZWFkIiwic2V0dGluZ3MudXBkYXRlIiwibGVhZC5yZWFkIiwibGVhZC5jcmVhdGUiLCJsZWFkLnVwZGF0ZSIsImxlYWQuZGVsZXRlIiwiYWN0aXZpdHkucmVhZCIsImFjdGl2aXR5LmNyZWF0ZSIsImRlbGV0ZWQucmVhZCIsInRhc2sucmVhZCIsInRhc2suY3JlYXRlIiwidGFzay51cGRhdGUiLCJ0YXNrLmRlbGV0ZSIsImNvbnRhY3QucmVhZCIsImNvbnRhY3QuY3JlYXRlIiwiY29udGFjdC51cGRhdGUiLCJjb250YWN0LmRlbGV0ZSIsImRlYWwucmVhZCIsImRlYWwuY3JlYXRlIiwiZGVhbC51cGRhdGUiLCJkZWFsLmRlbGV0ZSJdfV0sImlhdCI6MTc2MDg4NTYwOSwiZXhwIjoxNzYwOTcyMDA5fQ.a_9GUgafitmF6_LVIR2TM5m2982I1GSU-DHR3hnS6WI	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-10-20 14:53:29.667	2025-10-19 14:53:29.668	2025-10-19 14:53:29.668
7	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JtLmNvbSIsImRldmljZUlkIjoiZGV2aWNlX2lpemxscWJjcWttZ3hxZnV0ZyIsImlwIjoiMTI3LjAuMC4xIiwidXNlckFnZW50IjoiTW96aWxsYS81LjAgKE1hY2ludG9zaDsgSW50ZWwgTWFjIE9TIFggMTBfMTVfNykgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzE0MS4wLjAuMCBTYWZhcmkvNTM3LjM2Iiwicm9sZXMiOlt7ImlkIjoxLCJuYW1lIjoiQWRtaW4iLCJwZXJtaXNzaW9ucyI6WyJ1c2VyLnJlYWQiLCJ1c2VyLmNyZWF0ZSIsInVzZXIudXBkYXRlIiwidXNlci5kZWxldGUiLCJyb2xlLnJlYWQiLCJyb2xlLmNyZWF0ZSIsInJvbGUudXBkYXRlIiwicm9sZS5kZWxldGUiLCJwZXJtaXNzaW9uLnJlYWQiLCJkYXNoYm9hcmQucmVhZCIsInNldHRpbmdzLnJlYWQiLCJzZXR0aW5ncy51cGRhdGUiLCJsZWFkLnJlYWQiLCJsZWFkLmNyZWF0ZSIsImxlYWQudXBkYXRlIiwibGVhZC5kZWxldGUiLCJhY3Rpdml0eS5yZWFkIiwiYWN0aXZpdHkuY3JlYXRlIiwiZGVsZXRlZC5yZWFkIiwidGFzay5yZWFkIiwidGFzay5jcmVhdGUiLCJ0YXNrLnVwZGF0ZSIsInRhc2suZGVsZXRlIiwiY29udGFjdC5yZWFkIiwiY29udGFjdC5jcmVhdGUiLCJjb250YWN0LnVwZGF0ZSIsImNvbnRhY3QuZGVsZXRlIiwiZGVhbC5yZWFkIiwiZGVhbC5jcmVhdGUiLCJkZWFsLnVwZGF0ZSIsImRlYWwuZGVsZXRlIl19XSwiaWF0IjoxNzYwODg2MTA0LCJleHAiOjE3NjA5NzI1MDR9.Sqt3tMS04xjzRuJ0Ek2fWMCHcEZKNQxbWL0vjPZ7iIg	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-10-20 15:01:44.786	2025-10-19 15:01:44.787	2025-10-19 15:01:44.787
8	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JtLmNvbSIsImRldmljZUlkIjoiZGV2aWNlX3VsYzdmdDRiNzU5bWd4cXNuZnIiLCJpcCI6IjEyNy4wLjAuMSIsInVzZXJBZ2VudCI6Ik1vemlsbGEvNS4wIChNYWNpbnRvc2g7IEludGVsIE1hYyBPUyBYIDEwXzE1XzcpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xNDEuMC4wLjAgU2FmYXJpLzUzNy4zNiIsInJvbGVzIjpbeyJpZCI6MSwibmFtZSI6IkFkbWluIiwicGVybWlzc2lvbnMiOlsidXNlci5yZWFkIiwidXNlci5jcmVhdGUiLCJ1c2VyLnVwZGF0ZSIsInVzZXIuZGVsZXRlIiwicm9sZS5yZWFkIiwicm9sZS5jcmVhdGUiLCJyb2xlLnVwZGF0ZSIsInJvbGUuZGVsZXRlIiwicGVybWlzc2lvbi5yZWFkIiwiZGFzaGJvYXJkLnJlYWQiLCJzZXR0aW5ncy5yZWFkIiwic2V0dGluZ3MudXBkYXRlIiwibGVhZC5yZWFkIiwibGVhZC5jcmVhdGUiLCJsZWFkLnVwZGF0ZSIsImxlYWQuZGVsZXRlIiwiYWN0aXZpdHkucmVhZCIsImFjdGl2aXR5LmNyZWF0ZSIsImRlbGV0ZWQucmVhZCIsInRhc2sucmVhZCIsInRhc2suY3JlYXRlIiwidGFzay51cGRhdGUiLCJ0YXNrLmRlbGV0ZSIsImNvbnRhY3QucmVhZCIsImNvbnRhY3QuY3JlYXRlIiwiY29udGFjdC51cGRhdGUiLCJjb250YWN0LmRlbGV0ZSIsImRlYWwucmVhZCIsImRlYWwuY3JlYXRlIiwiZGVhbC51cGRhdGUiLCJkZWFsLmRlbGV0ZSJdfV0sImlhdCI6MTc2MDg4NzE1OSwiZXhwIjoxNzYwOTczNTU5fQ.y9aMlvZQ3UTsFGTp4noDvlZKkOjSw1F3p6VatBZBo4M	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-10-20 15:19:19.063	2025-10-19 15:19:19.064	2025-10-19 15:19:19.064
9	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JtLmNvbSIsImRldmljZUlkIjoiZGV2aWNlX3VtcjIyOXdjZmpvbWd4ejVmMmYiLCJpcCI6IjEyNy4wLjAuMSIsInVzZXJBZ2VudCI6Ik1vemlsbGEvNS4wIChNYWNpbnRvc2g7IEludGVsIE1hYyBPUyBYIDEwXzE1XzcpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xNDEuMC4wLjAgU2FmYXJpLzUzNy4zNiIsInJvbGVzIjpbeyJpZCI6MSwibmFtZSI6IkFkbWluIiwicGVybWlzc2lvbnMiOlsidXNlci5yZWFkIiwidXNlci5jcmVhdGUiLCJ1c2VyLnVwZGF0ZSIsInVzZXIuZGVsZXRlIiwicm9sZS5yZWFkIiwicm9sZS5jcmVhdGUiLCJyb2xlLnVwZGF0ZSIsInJvbGUuZGVsZXRlIiwicGVybWlzc2lvbi5yZWFkIiwiZGFzaGJvYXJkLnJlYWQiLCJzZXR0aW5ncy5yZWFkIiwic2V0dGluZ3MudXBkYXRlIiwibGVhZC5yZWFkIiwibGVhZC5jcmVhdGUiLCJsZWFkLnVwZGF0ZSIsImxlYWQuZGVsZXRlIiwiYWN0aXZpdHkucmVhZCIsImFjdGl2aXR5LmNyZWF0ZSIsImRlbGV0ZWQucmVhZCIsInRhc2sucmVhZCIsInRhc2suY3JlYXRlIiwidGFzay51cGRhdGUiLCJ0YXNrLmRlbGV0ZSIsImNvbnRhY3QucmVhZCIsImNvbnRhY3QuY3JlYXRlIiwiY29udGFjdC51cGRhdGUiLCJjb250YWN0LmRlbGV0ZSIsImRlYWwucmVhZCIsImRlYWwuY3JlYXRlIiwiZGVhbC51cGRhdGUiLCJkZWFsLmRlbGV0ZSJdfV0sImlhdCI6MTc2MDg5NTE2NywiZXhwIjoxNzYwOTgxNTY3fQ.ME3slYp6XiZzL_9vEh4ZbGZdy5ZuyO-KHLVPxsxOvm8	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-10-20 17:32:47.37	2025-10-19 17:32:47.371	2025-10-19 17:32:47.371
10	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JtLmNvbSIsImRldmljZUlkIjoiZGV2aWNlXzMzMHZxOXVmc25jbWd5MDlxd2MiLCJpcCI6IjEyNy4wLjAuMSIsInVzZXJBZ2VudCI6Ik1vemlsbGEvNS4wIChNYWNpbnRvc2g7IEludGVsIE1hYyBPUyBYIDEwXzE1XzcpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xNDEuMC4wLjAgU2FmYXJpLzUzNy4zNiIsInJvbGVzIjpbeyJpZCI6MSwibmFtZSI6IkFkbWluIiwicGVybWlzc2lvbnMiOlsidXNlci5yZWFkIiwidXNlci5jcmVhdGUiLCJ1c2VyLnVwZGF0ZSIsInVzZXIuZGVsZXRlIiwicm9sZS5yZWFkIiwicm9sZS5jcmVhdGUiLCJyb2xlLnVwZGF0ZSIsInJvbGUuZGVsZXRlIiwicGVybWlzc2lvbi5yZWFkIiwiZGFzaGJvYXJkLnJlYWQiLCJzZXR0aW5ncy5yZWFkIiwic2V0dGluZ3MudXBkYXRlIiwibGVhZC5yZWFkIiwibGVhZC5jcmVhdGUiLCJsZWFkLnVwZGF0ZSIsImxlYWQuZGVsZXRlIiwiYWN0aXZpdHkucmVhZCIsImFjdGl2aXR5LmNyZWF0ZSIsImRlbGV0ZWQucmVhZCIsInRhc2sucmVhZCIsInRhc2suY3JlYXRlIiwidGFzay51cGRhdGUiLCJ0YXNrLmRlbGV0ZSIsImNvbnRhY3QucmVhZCIsImNvbnRhY3QuY3JlYXRlIiwiY29udGFjdC51cGRhdGUiLCJjb250YWN0LmRlbGV0ZSIsImRlYWwucmVhZCIsImRlYWwuY3JlYXRlIiwiZGVhbC51cGRhdGUiLCJkZWFsLmRlbGV0ZSJdfV0sImlhdCI6MTc2MDg5NjQzOCwiZXhwIjoxNzYwOTgyODM4fQ.O-6WXVi7HReYyh1gRu6s7O7qtqSMXw7av3pN7lbvEKw	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-10-20 17:53:58.914	2025-10-19 17:53:58.915	2025-10-19 17:53:58.915
11	1	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoiYWRtaW5AY3JtLmNvbSIsImRldmljZUlkIjoiZGV2aWNlX3VtcjIyOXdjZmpvbWd4ejVmMmYiLCJpcCI6IjEyNy4wLjAuMSIsInVzZXJBZ2VudCI6Ik1vemlsbGEvNS4wIChNYWNpbnRvc2g7IEludGVsIE1hYyBPUyBYIDEwXzE1XzcpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8xNDEuMC4wLjAgU2FmYXJpLzUzNy4zNiIsInJvbGVzIjpbeyJpZCI6MSwibmFtZSI6IkFkbWluIiwicGVybWlzc2lvbnMiOlsidXNlci5yZWFkIiwidXNlci5jcmVhdGUiLCJ1c2VyLnVwZGF0ZSIsInVzZXIuZGVsZXRlIiwicm9sZS5yZWFkIiwicm9sZS5jcmVhdGUiLCJyb2xlLnVwZGF0ZSIsInJvbGUuZGVsZXRlIiwicGVybWlzc2lvbi5yZWFkIiwiZGFzaGJvYXJkLnJlYWQiLCJzZXR0aW5ncy5yZWFkIiwic2V0dGluZ3MudXBkYXRlIiwibGVhZC5yZWFkIiwibGVhZC5jcmVhdGUiLCJsZWFkLnVwZGF0ZSIsImxlYWQuZGVsZXRlIiwiYWN0aXZpdHkucmVhZCIsImFjdGl2aXR5LmNyZWF0ZSIsImRlbGV0ZWQucmVhZCIsInRhc2sucmVhZCIsInRhc2suY3JlYXRlIiwidGFzay51cGRhdGUiLCJ0YXNrLmRlbGV0ZSIsImNvbnRhY3QucmVhZCIsImNvbnRhY3QuY3JlYXRlIiwiY29udGFjdC51cGRhdGUiLCJjb250YWN0LmRlbGV0ZSIsImRlYWwucmVhZCIsImRlYWwuY3JlYXRlIiwiZGVhbC51cGRhdGUiLCJkZWFsLmRlbGV0ZSJdfV0sImlhdCI6MTc2MDg5NzU1NywiZXhwIjoxNzYwOTgzOTU3fQ.8YMFNMr-yN4aJ3JS4r1Rkvg-LOg_fKLyvtvP-iScUkg	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-10-20 18:12:37.545	2025-10-19 18:12:37.546	2025-10-19 18:12:37.546
\.


--
-- Data for Name: password_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_history (id, "userId", password, "createdAt") FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, "invoiceId", amount, currency, "paymentMethod", "paymentDate", "referenceNumber", notes, "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, name, key, description, module, "createdAt", "updatedAt") FROM stdin;
20	View Tasks	task.read	Can view task list	Tasks	2025-10-19 13:45:41.542	2025-10-19 18:21:49.874
21	Create Tasks	task.create	Can create new tasks	Tasks	2025-10-19 13:45:41.543	2025-10-19 18:21:49.874
22	Update Tasks	task.update	Can update task information	Tasks	2025-10-19 13:45:41.543	2025-10-19 18:21:49.875
23	Delete Tasks	task.delete	Can delete tasks	Tasks	2025-10-19 13:45:41.544	2025-10-19 18:21:49.875
24	View Contacts	contact.read	Can view contact list	Contacts	2025-10-19 13:45:41.544	2025-10-19 18:21:49.876
25	Create Contacts	contact.create	Can create new contacts	Contacts	2025-10-19 13:45:41.545	2025-10-19 18:21:49.876
26	Update Contacts	contact.update	Can update contact information	Contacts	2025-10-19 13:45:41.545	2025-10-19 18:21:49.877
27	Delete Contacts	contact.delete	Can delete contacts	Contacts	2025-10-19 13:45:41.546	2025-10-19 18:21:49.877
1	View Users	user.read	Can view user list	Users	2025-10-19 13:45:41.523	2025-10-19 18:21:49.853
2	Create Users	user.create	Can create new users	Users	2025-10-19 13:45:41.53	2025-10-19 18:21:49.863
3	Update Users	user.update	Can update user information	Users	2025-10-19 13:45:41.531	2025-10-19 18:21:49.864
4	Delete Users	user.delete	Can delete users	Users	2025-10-19 13:45:41.532	2025-10-19 18:21:49.864
5	View Roles	role.read	Can view role list	Roles	2025-10-19 13:45:41.533	2025-10-19 18:21:49.865
6	Create Roles	role.create	Can create new roles	Roles	2025-10-19 13:45:41.534	2025-10-19 18:21:49.866
7	Update Roles	role.update	Can update role information	Roles	2025-10-19 13:45:41.534	2025-10-19 18:21:49.866
8	Delete Roles	role.delete	Can delete roles	Roles	2025-10-19 13:45:41.535	2025-10-19 18:21:49.867
9	View Permissions	permission.read	Can view permission list	Permissions	2025-10-19 13:45:41.536	2025-10-19 18:21:49.867
10	View Dashboard	dashboard.read	Can access dashboard	Dashboard	2025-10-19 13:45:41.537	2025-10-19 18:21:49.868
11	View Settings	settings.read	Can view application settings	Settings	2025-10-19 13:45:41.537	2025-10-19 18:21:49.869
12	Update Settings	settings.update	Can update application settings	Settings	2025-10-19 13:45:41.538	2025-10-19 18:21:49.869
13	View Leads	lead.read	Can view lead list	Leads	2025-10-19 13:45:41.538	2025-10-19 18:21:49.87
14	Create Leads	lead.create	Can create new leads	Leads	2025-10-19 13:45:41.539	2025-10-19 18:21:49.87
15	Update Leads	lead.update	Can update lead information	Leads	2025-10-19 13:45:41.539	2025-10-19 18:21:49.871
16	Delete Leads	lead.delete	Can delete leads	Leads	2025-10-19 13:45:41.54	2025-10-19 18:21:49.872
17	View Activities	activity.read	Can view activity logs	Activities	2025-10-19 13:45:41.541	2025-10-19 18:21:49.872
18	Create Activities	activity.create	Can create activity logs	Activities	2025-10-19 13:45:41.541	2025-10-19 18:21:49.873
28	View Deals	deal.read	Can view deal list	Deals	2025-10-19 13:45:41.546	2025-10-19 18:21:49.878
29	Create Deals	deal.create	Can create new deals	Deals	2025-10-19 13:45:41.547	2025-10-19 18:21:49.878
30	Update Deals	deal.update	Can update deal information	Deals	2025-10-19 13:45:41.547	2025-10-19 18:21:49.879
31	Delete Deals	deal.delete	Can delete deals	Deals	2025-10-19 13:45:41.548	2025-10-19 18:21:49.879
19	View Deleted Data	deleted.read	Can view deleted users, leads and roles	Activities	2025-10-19 13:45:41.542	2025-10-19 18:21:49.873
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, description, sku, type, category, price, cost, currency, unit, "taxRate", "isActive", "stockQuantity", "minStockLevel", "maxStockLevel", image, "companyId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: proposal_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proposal_templates (id, name, description, content, "isActive", "isDefault", "headerHtml", "footerHtml", styles, variables, "previewImage", category, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: quotation_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotation_items (id, "quotationId", "productId", name, description, quantity, unit, "unitPrice", "taxRate", "discountRate", subtotal, "totalAmount", "sortOrder", "createdAt", "updatedAt") FROM stdin;
1	1	\N			1.00	Unit	0.00	0.00	0.00	0.00	0.00	0	2025-11-03 10:58:34.896	2025-11-03 10:58:34.896
2	2	\N			1.00	Unit	0.00	0.00	0.00	0.00	0.00	0	2025-11-03 12:29:15.739	2025-11-03 12:29:15.739
\.


--
-- Data for Name: quotation_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotation_templates (id, name, description, "headerContent", "footerContent", "termsAndConditions", "validityDays", "showTax", "showDiscount", "logoPosition", "isDefault", "isActive", styles, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotations (id, "quotationNumber", title, description, status, subtotal, "taxAmount", "discountAmount", "totalAmount", currency, "validUntil", notes, terms, "companyId", "leadId", "dealId", "contactId", "createdBy", "sentAt", "viewedAt", "acceptedAt", "rejectedAt", "expiresAt", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	Q-000001	Deal with Aakriti Shrivastava	\N	SENT	0.00	0.00	0.00	0.00	USD	\N	\N		\N	\N	1	1	1	\N	\N	\N	\N	\N	2025-11-03 10:58:34.896	2025-11-03 10:58:34.924	\N
2	Q-000002	Deal with Aakriti Shrivastava	\N	SENT	0.00	0.00	0.00	0.00	USD	\N	\N		\N	\N	1	1	1	\N	\N	\N	\N	\N	2025-11-03 12:29:15.739	2025-11-03 12:29:15.759	\N
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_tokens (id, token, "userId", "expiresAt", "isRevoked", "createdAt") FROM stdin;
1	30df6fb77085931d714d3301f6f9dfc692b3a221d0ce397562b60716cb5088813739f71374294acfd7c89d5515e04dc9a31273afb1fe6b1b0afb4613c522e3ce	1	2025-10-26 14:13:25.434	f	2025-10-19 14:13:25.435
2	a91e46c8325f6ddbcdaf2aaa6f57aa1a15bfa0e973fd5d2be93fa412e1fdac00dfdb7fd638303df7097cf36bdfe829ed682356aaba8e4c429b7668e91685f38f	1	2025-10-26 14:26:16.535	f	2025-10-19 14:26:16.536
3	9c56dd31db765a20457675dac04db8208d195595fdb085ec1b11b0608c8450cfa3d2c5f23355c21dd7014a9ad6be7361557fba06b8c2421acfefccbd23f44ca0	1	2025-10-26 14:47:07.471	f	2025-10-19 14:47:07.472
4	af902b234a18ded4f16dd899465dddff8992be9066521824b1ad337c10473128159f2a9c29635b7babba0dd6a70c092612d3de1837c063d212b7aa9a513dcec3	1	2025-10-26 14:51:32.196	f	2025-10-19 14:51:32.197
5	7dc0266def7e60f33b3f24c9e1df20504fcf0f300602703466033575c8193fc55501d2206a16eb5445370b97d3d7695981d2b065707ecf663ea4df4af2a091f9	1	2025-10-26 14:53:07.795	f	2025-10-19 14:53:07.795
6	5f8f1170cdf4b5ec2e77b8e2b23e6e8cbfce6da47b06ac188ad5f5224645500562d5b598d11fd79b60262e9044bf2cdf5006bf880b6562d424759941322f60af	1	2025-10-26 14:53:29.666	f	2025-10-19 14:53:29.666
7	6878573e294e02d6a7e2807b18924664defc1282e0d955f6ade45844b10782eccf36b4b713fc102a29f6460999a1e2335abbe9e027f04d6fecff90d64a6bbd9b	1	2025-10-26 15:01:44.783	f	2025-10-19 15:01:44.784
8	e562268a9f123356452a974ab560b049855a3100b72432c0b46403e307b98f81990e1d486027c8c031652da2ae40e24ef1de6b767a32f188efbe05889329230e	1	2025-10-26 15:19:19.06	f	2025-10-19 15:19:19.061
9	67bcf5192fa0feedd0fe5cf53fce8a3194262d79602d61a9d77c5429d89d3393cbeafba086328fedc39ab1dd4af368f6a923500b29d8bae5d83fdc75e6ed12c8	1	2025-10-26 17:32:47.364	f	2025-10-19 17:32:47.364
10	3638cf0aa372064e77b2060a37fc4a649b72f5e94f0b12fc66ba1fb216bf52ba66f061c5ce76660c546d472a0c4a2f14dca9410ab6e3ddaa8636bae62b29f33a	1	2025-10-26 17:53:58.909	f	2025-10-19 17:53:58.909
11	487f8f3fa07f19e66d08e30fde05439998518be865a2d7c7d60368e464542fb6a0c88c577b14e553064a2a346035873e55f2eb64addc07e3c7e789a7058f1a6a	1	2025-10-26 18:12:37.541	f	2025-10-19 18:12:37.542
12	$2a$10$xB8sMiofz4aq5PxDCJR2E.uNHsd.g2j1tgLsQr49luCISWmSgbMhG	1	2025-11-10 10:44:05.545	f	2025-11-03 10:44:05.546
13	$2a$10$9Edtf84gJ7YnrmqUtQOBf.QaCKKwS5GNkv4ndaAK5MYlXSpQTJETm	1	2025-11-10 11:46:09.717	f	2025-11-03 11:46:09.718
14	$2a$10$1UG1y2jFCp1qDC/P2lFHb.c9yY4EroGtZxdgqGnFrUctVpwTUv5UG	1	2025-11-11 05:10:40.228	f	2025-11-04 05:10:40.23
15	$2a$10$2w0HtEX1o3HJx1MREPBay.L73l7yLnBMPn5W5.YWKLtpSDT7YbCHi	1	2025-11-11 06:11:02.931	f	2025-11-04 06:11:02.933
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permissions (id, "roleId", "permissionId") FROM stdin;
1	1	1
2	1	2
3	1	3
4	1	4
5	1	5
6	1	6
7	1	7
8	1	8
9	1	9
10	1	10
11	1	11
12	1	12
13	1	13
14	1	14
15	1	15
16	1	16
17	1	17
18	1	18
19	1	19
20	1	20
21	1	21
22	1	22
23	1	23
24	1	24
25	1	25
26	1	26
27	1	27
28	1	28
29	1	29
30	1	30
31	1	31
32	2	1
33	2	10
34	2	13
35	2	14
36	2	15
37	2	17
38	2	20
39	2	21
40	2	22
41	2	24
42	2	28
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, description, "isActive", "createdAt", "updatedAt", "deletedAt", "accessScope") FROM stdin;
1	Admin	System administrator with full access	t	2025-10-19 13:45:41.548	2025-10-19 18:21:49.88	\N	OWN
2	User	Regular user with limited access	t	2025-10-19 13:45:41.55	2025-10-19 18:21:49.881	\N	OWN
\.


--
-- Data for Name: super_admin_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.super_admin_permissions (id, name, key, description, module, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: super_admin_role_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.super_admin_role_assignments (id, "superAdminId", "roleId") FROM stdin;
\.


--
-- Data for Name: super_admin_role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.super_admin_role_permissions (id, "roleId", "permissionId") FROM stdin;
\.


--
-- Data for Name: super_admin_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.super_admin_roles (id, name, description, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: super_admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.super_admins (id, email, password, "firstName", "lastName", "isActive", "lastLogin", "createdAt", "updatedAt", "profilePicture") FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tags (id, name, color, description, "isActive", "createdAt", "updatedAt", "companyId") FROM stdin;
1	Hot Lead	#EF4444	High priority lead	t	2025-10-19 13:45:41.872	2025-10-19 18:21:50.183	\N
2	Warm Lead	#F59E0B	Medium priority lead	t	2025-10-19 13:45:41.874	2025-10-19 18:21:50.185	\N
3	Cold Lead	#6B7280	Low priority lead	t	2025-10-19 13:45:41.875	2025-10-19 18:21:50.185	\N
4	VIP	#8B5CF6	Very important person	t	2025-10-19 13:45:41.875	2025-10-19 18:21:50.186	\N
5	Follow Up	#10B981	Needs follow up	t	2025-10-19 13:45:41.876	2025-10-19 18:21:50.186	\N
6	Qualified	#3B82F6	Qualified lead	t	2025-10-19 13:45:41.876	2025-10-19 18:21:50.187	\N
7	Proposal Sent	#06B6D4	Proposal has been sent	t	2025-10-19 13:45:41.877	2025-10-19 18:21:50.187	\N
8	Negotiation	#F97316	In negotiation phase	t	2025-10-19 13:45:41.877	2025-10-19 18:21:50.188	\N
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (id, title, description, status, priority, "dueDate", "completedAt", "assignedTo", "createdBy", "leadId", "dealId", "contactId", "isActive", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	ewww	ok	PENDING	MEDIUM	2025-11-03 00:00:00	\N	1	1	\N	\N	\N	f	2025-11-03 10:49:33.092	2025-11-03 11:54:10.179	2025-11-03 11:54:10.178
2	ok	testing	PENDING	LOW	2025-11-03 00:00:00	\N	1	1	\N	\N	\N	t	2025-11-03 12:35:32.825	2025-11-03 12:35:32.825	\N
3	ok	rrrrr	PENDING	MEDIUM	\N	\N	1	1	3	\N	\N	t	2025-11-03 12:38:11.85	2025-11-03 12:38:11.85	\N
\.


--
-- Data for Name: third_party_integrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.third_party_integrations (id, name, "displayName", description, "isActive", "apiEndpoint", "authType", config, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (id, "userId", "roleId") FROM stdin;
1	1	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, "firstName", "lastName", "isActive", "lastLogin", "createdAt", "updatedAt", "profilePicture", "companyId", "deletedAt", "accountLockedUntil", "emailVerificationToken", "emailVerified", "emailVerifiedAt", "failedLoginAttempts", "passwordResetExpires", "passwordResetToken", "twoFactorEnabled", "twoFactorSecret") FROM stdin;
1	admin@crm.com	$2a$12$cnzmRPuDMKwj84g.QweMuuWyxPJRd/E2aAAs9W2KgqTmDjIlf/3gy	Admin	User	t	2025-10-19 18:12:37.534	2025-10-19 13:45:41.86	2025-10-19 18:21:50.172	\N	\N	\N	\N	\N	t	2025-10-19 18:21:50.171	0	\N	\N	f	\N
\.


--
-- Name: activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activities_id_seq', 16, true);


--
-- Name: business_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.business_settings_id_seq', 1, true);


--
-- Name: call_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.call_logs_id_seq', 1, false);


--
-- Name: communication_automations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.communication_automations_id_seq', 1, false);


--
-- Name: communication_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.communication_messages_id_seq', 1, false);


--
-- Name: communication_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.communication_providers_id_seq', 1, false);


--
-- Name: communication_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.communication_templates_id_seq', 1, false);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.companies_id_seq', 2, true);


--
-- Name: company_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.company_activities_id_seq', 1, false);


--
-- Name: company_communications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.company_communications_id_seq', 1, false);


--
-- Name: company_followups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.company_followups_id_seq', 1, false);


--
-- Name: contact_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_activities_id_seq', 1, false);


--
-- Name: contact_communications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_communications_id_seq', 1, false);


--
-- Name: contact_followups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_followups_id_seq', 1, false);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contacts_id_seq', 3, true);


--
-- Name: deal_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deal_products_id_seq', 1, false);


--
-- Name: deals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deals_id_seq', 3, true);


--
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.files_id_seq', 1, true);


--
-- Name: industries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.industries_id_seq', 1, false);


--
-- Name: industry_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.industry_fields_id_seq', 1, false);


--
-- Name: integration_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.integration_logs_id_seq', 1, false);


--
-- Name: invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoice_items_id_seq', 1, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- Name: lead_assignment_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lead_assignment_rules_id_seq', 1, false);


--
-- Name: lead_communications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lead_communications_id_seq', 1, false);


--
-- Name: lead_followups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lead_followups_id_seq', 1, false);


--
-- Name: lead_import_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lead_import_batches_id_seq', 1, false);


--
-- Name: lead_import_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lead_import_records_id_seq', 1, false);


--
-- Name: lead_integration_sync_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lead_integration_sync_id_seq', 1, false);


--
-- Name: lead_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lead_sources_id_seq', 96, true);


--
-- Name: lead_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lead_tags_id_seq', 1, true);


--
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.leads_id_seq', 4, true);


--
-- Name: login_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.login_sessions_id_seq', 11, true);


--
-- Name: password_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.password_history_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 372, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: proposal_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proposal_templates_id_seq', 1, false);


--
-- Name: quotation_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotation_items_id_seq', 2, true);


--
-- Name: quotation_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotation_templates_id_seq', 1, false);


--
-- Name: quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quotations_id_seq', 2, true);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 15, true);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 42, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 24, true);


--
-- Name: super_admin_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.super_admin_permissions_id_seq', 1, false);


--
-- Name: super_admin_role_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.super_admin_role_assignments_id_seq', 1, false);


--
-- Name: super_admin_role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.super_admin_role_permissions_id_seq', 1, false);


--
-- Name: super_admin_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.super_admin_roles_id_seq', 1, false);


--
-- Name: super_admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.super_admins_id_seq', 1, false);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tags_id_seq', 96, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_id_seq', 3, true);


--
-- Name: third_party_integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.third_party_integrations_id_seq', 1, false);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 12, true);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: business_settings business_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_settings
    ADD CONSTRAINT business_settings_pkey PRIMARY KEY (id);


--
-- Name: call_logs call_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.call_logs
    ADD CONSTRAINT call_logs_pkey PRIMARY KEY (id);


--
-- Name: communication_automations communication_automations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_automations
    ADD CONSTRAINT communication_automations_pkey PRIMARY KEY (id);


--
-- Name: communication_messages communication_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT communication_messages_pkey PRIMARY KEY (id);


--
-- Name: communication_providers communication_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_providers
    ADD CONSTRAINT communication_providers_pkey PRIMARY KEY (id);


--
-- Name: communication_templates communication_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT communication_templates_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_activities company_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_activities
    ADD CONSTRAINT company_activities_pkey PRIMARY KEY (id);


--
-- Name: company_communications company_communications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_communications
    ADD CONSTRAINT company_communications_pkey PRIMARY KEY (id);


--
-- Name: company_followups company_followups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_followups
    ADD CONSTRAINT company_followups_pkey PRIMARY KEY (id);


--
-- Name: contact_activities contact_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_activities
    ADD CONSTRAINT contact_activities_pkey PRIMARY KEY (id);


--
-- Name: contact_communications contact_communications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_communications
    ADD CONSTRAINT contact_communications_pkey PRIMARY KEY (id);


--
-- Name: contact_followups contact_followups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_followups
    ADD CONSTRAINT contact_followups_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: deal_products deal_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deal_products
    ADD CONSTRAINT deal_products_pkey PRIMARY KEY (id);


--
-- Name: deals deals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_pkey PRIMARY KEY (id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: industries industries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industries
    ADD CONSTRAINT industries_pkey PRIMARY KEY (id);


--
-- Name: industry_fields industry_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industry_fields
    ADD CONSTRAINT industry_fields_pkey PRIMARY KEY (id);


--
-- Name: integration_logs integration_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: lead_assignment_rules lead_assignment_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_assignment_rules
    ADD CONSTRAINT lead_assignment_rules_pkey PRIMARY KEY (id);


--
-- Name: lead_communications lead_communications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_communications
    ADD CONSTRAINT lead_communications_pkey PRIMARY KEY (id);


--
-- Name: lead_followups lead_followups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_followups
    ADD CONSTRAINT lead_followups_pkey PRIMARY KEY (id);


--
-- Name: lead_import_batches lead_import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_import_batches
    ADD CONSTRAINT lead_import_batches_pkey PRIMARY KEY (id);


--
-- Name: lead_import_records lead_import_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_import_records
    ADD CONSTRAINT lead_import_records_pkey PRIMARY KEY (id);


--
-- Name: lead_integration_sync lead_integration_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_integration_sync
    ADD CONSTRAINT lead_integration_sync_pkey PRIMARY KEY (id);


--
-- Name: lead_sources lead_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_sources
    ADD CONSTRAINT lead_sources_pkey PRIMARY KEY (id);


--
-- Name: lead_tags lead_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_tags
    ADD CONSTRAINT lead_tags_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: login_sessions login_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_sessions
    ADD CONSTRAINT login_sessions_pkey PRIMARY KEY (id);


--
-- Name: password_history password_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_history
    ADD CONSTRAINT password_history_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: proposal_templates proposal_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proposal_templates
    ADD CONSTRAINT proposal_templates_pkey PRIMARY KEY (id);


--
-- Name: quotation_items quotation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_pkey PRIMARY KEY (id);


--
-- Name: quotation_templates quotation_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_templates
    ADD CONSTRAINT quotation_templates_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: super_admin_permissions super_admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_permissions
    ADD CONSTRAINT super_admin_permissions_pkey PRIMARY KEY (id);


--
-- Name: super_admin_role_assignments super_admin_role_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_role_assignments
    ADD CONSTRAINT super_admin_role_assignments_pkey PRIMARY KEY (id);


--
-- Name: super_admin_role_permissions super_admin_role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_role_permissions
    ADD CONSTRAINT super_admin_role_permissions_pkey PRIMARY KEY (id);


--
-- Name: super_admin_roles super_admin_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_roles
    ADD CONSTRAINT super_admin_roles_pkey PRIMARY KEY (id);


--
-- Name: super_admins super_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admins
    ADD CONSTRAINT super_admins_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: third_party_integrations third_party_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.third_party_integrations
    ADD CONSTRAINT third_party_integrations_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: companies_domain_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX companies_domain_key ON public.companies USING btree (domain);


--
-- Name: companies_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX companies_name_key ON public.companies USING btree (name);


--
-- Name: companies_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX companies_slug_key ON public.companies USING btree (slug);


--
-- Name: contacts_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX contacts_email_key ON public.contacts USING btree (email);


--
-- Name: contacts_sourceLeadId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "contacts_sourceLeadId_key" ON public.contacts USING btree ("sourceLeadId");


--
-- Name: industries_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX industries_name_key ON public.industries USING btree (name);


--
-- Name: industries_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX industries_slug_key ON public.industries USING btree (slug);


--
-- Name: industry_fields_industryId_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "industry_fields_industryId_key_key" ON public.industry_fields USING btree ("industryId", key);


--
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: lead_integration_sync_externalId_integrationId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "lead_integration_sync_externalId_integrationId_key" ON public.lead_integration_sync USING btree ("externalId", "integrationId");


--
-- Name: lead_integration_sync_leadId_integrationId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "lead_integration_sync_leadId_integrationId_key" ON public.lead_integration_sync USING btree ("leadId", "integrationId");


--
-- Name: lead_sources_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX lead_sources_name_key ON public.lead_sources USING btree (name);


--
-- Name: lead_tags_leadId_tagId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "lead_tags_leadId_tagId_key" ON public.lead_tags USING btree ("leadId", "tagId");


--
-- Name: leads_convertedToContactId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "leads_convertedToContactId_key" ON public.leads USING btree ("convertedToContactId");


--
-- Name: login_sessions_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX login_sessions_token_key ON public.login_sessions USING btree (token);


--
-- Name: permissions_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX permissions_key_key ON public.permissions USING btree (key);


--
-- Name: products_sku_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX products_sku_key ON public.products USING btree (sku);


--
-- Name: quotations_quotationNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "quotations_quotationNumber_key" ON public.quotations USING btree ("quotationNumber");


--
-- Name: refresh_tokens_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX refresh_tokens_token_key ON public.refresh_tokens USING btree (token);


--
-- Name: role_permissions_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "role_permissions_roleId_permissionId_key" ON public.role_permissions USING btree ("roleId", "permissionId");


--
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- Name: super_admin_permissions_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX super_admin_permissions_key_key ON public.super_admin_permissions USING btree (key);


--
-- Name: super_admin_role_assignments_superAdminId_roleId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "super_admin_role_assignments_superAdminId_roleId_key" ON public.super_admin_role_assignments USING btree ("superAdminId", "roleId");


--
-- Name: super_admin_role_permissions_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "super_admin_role_permissions_roleId_permissionId_key" ON public.super_admin_role_permissions USING btree ("roleId", "permissionId");


--
-- Name: super_admin_roles_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX super_admin_roles_name_key ON public.super_admin_roles USING btree (name);


--
-- Name: super_admins_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX super_admins_email_key ON public.super_admins USING btree (email);


--
-- Name: tags_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX tags_name_key ON public.tags USING btree (name);


--
-- Name: third_party_integrations_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX third_party_integrations_name_key ON public.third_party_integrations USING btree (name);


--
-- Name: user_roles_userId_roleId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_roles_userId_roleId_key" ON public.user_roles USING btree ("userId", "roleId");


--
-- Name: users_emailVerificationToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_emailVerificationToken_key" ON public.users USING btree ("emailVerificationToken");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_passwordResetToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "users_passwordResetToken_key" ON public.users USING btree ("passwordResetToken");


--
-- Name: activities activities_superAdminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT "activities_superAdminId_fkey" FOREIGN KEY ("superAdminId") REFERENCES public.super_admins(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: activities activities_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT "activities_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: call_logs call_logs_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.call_logs
    ADD CONSTRAINT "call_logs_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: call_logs call_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.call_logs
    ADD CONSTRAINT "call_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: communication_automations communication_automations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_automations
    ADD CONSTRAINT "communication_automations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: communication_automations communication_automations_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_automations
    ADD CONSTRAINT "communication_automations_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: communication_automations communication_automations_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_automations
    ADD CONSTRAINT "communication_automations_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public.communication_templates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: communication_messages communication_messages_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT "communication_messages_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: communication_messages communication_messages_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT "communication_messages_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public.communication_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: communication_messages communication_messages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT "communication_messages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: communication_providers communication_providers_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_providers
    ADD CONSTRAINT "communication_providers_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: communication_templates communication_templates_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT "communication_templates_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: communication_templates communication_templates_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT "communication_templates_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: companies companies_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT "companies_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: companies companies_industryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT "companies_industryId_fkey" FOREIGN KEY ("industryId") REFERENCES public.industries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: companies companies_parentCompanyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT "companies_parentCompanyId_fkey" FOREIGN KEY ("parentCompanyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: company_activities company_activities_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_activities
    ADD CONSTRAINT "company_activities_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_activities company_activities_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_activities
    ADD CONSTRAINT "company_activities_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: company_communications company_communications_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_communications
    ADD CONSTRAINT "company_communications_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_communications company_communications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_communications
    ADD CONSTRAINT "company_communications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: company_followups company_followups_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_followups
    ADD CONSTRAINT "company_followups_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_followups company_followups_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_followups
    ADD CONSTRAINT "company_followups_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: contact_activities contact_activities_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_activities
    ADD CONSTRAINT "contact_activities_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contact_activities contact_activities_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_activities
    ADD CONSTRAINT "contact_activities_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contact_communications contact_communications_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_communications
    ADD CONSTRAINT "contact_communications_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contact_communications contact_communications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_communications
    ADD CONSTRAINT "contact_communications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: contact_followups contact_followups_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_followups
    ADD CONSTRAINT "contact_followups_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: contact_followups contact_followups_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_followups
    ADD CONSTRAINT "contact_followups_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: contacts contacts_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT "contacts_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contacts contacts_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT "contacts_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contacts contacts_sourceLeadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT "contacts_sourceLeadId_fkey" FOREIGN KEY ("sourceLeadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: deal_products deal_products_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deal_products
    ADD CONSTRAINT "deal_products_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deals deals_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: deals deals_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: deals deals_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: deals deals_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: files files_uploadedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT "files_uploadedBy_fkey" FOREIGN KEY ("uploadedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: industry_fields industry_fields_industryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.industry_fields
    ADD CONSTRAINT "industry_fields_industryId_fkey" FOREIGN KEY ("industryId") REFERENCES public.industries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: integration_logs integration_logs_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT "integration_logs_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public.third_party_integrations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoice_items invoice_items_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT "invoice_items_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoice_items invoice_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT "invoice_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_quotationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_quotationId_fkey" FOREIGN KEY ("quotationId") REFERENCES public.quotations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lead_communications lead_communications_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_communications
    ADD CONSTRAINT "lead_communications_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_communications lead_communications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_communications
    ADD CONSTRAINT "lead_communications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lead_followups lead_followups_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_followups
    ADD CONSTRAINT "lead_followups_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_followups lead_followups_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_followups
    ADD CONSTRAINT "lead_followups_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lead_import_batches lead_import_batches_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_import_batches
    ADD CONSTRAINT "lead_import_batches_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lead_import_records lead_import_records_batchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_import_records
    ADD CONSTRAINT "lead_import_records_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES public.lead_import_batches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_import_records lead_import_records_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_import_records
    ADD CONSTRAINT "lead_import_records_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lead_integration_sync lead_integration_sync_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_integration_sync
    ADD CONSTRAINT "lead_integration_sync_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public.third_party_integrations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lead_integration_sync lead_integration_sync_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_integration_sync
    ADD CONSTRAINT "lead_integration_sync_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_sources lead_sources_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_sources
    ADD CONSTRAINT "lead_sources_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lead_tags lead_tags_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_tags
    ADD CONSTRAINT "lead_tags_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_tags lead_tags_tagId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_tags
    ADD CONSTRAINT "lead_tags_tagId_fkey" FOREIGN KEY ("tagId") REFERENCES public.tags(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leads leads_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT "leads_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: leads leads_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT "leads_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: leads leads_sourceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT "leads_sourceId_fkey" FOREIGN KEY ("sourceId") REFERENCES public.lead_sources(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: login_sessions login_sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_sessions
    ADD CONSTRAINT "login_sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: password_history password_history_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_history
    ADD CONSTRAINT "password_history_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quotation_items quotation_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT "quotation_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: quotation_items quotation_items_quotationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT "quotation_items_quotationId_fkey" FOREIGN KEY ("quotationId") REFERENCES public.quotations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quotations quotations_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: quotations quotations_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: quotations quotations_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: quotations quotations_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: refresh_tokens refresh_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "refresh_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: super_admin_role_assignments super_admin_role_assignments_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_role_assignments
    ADD CONSTRAINT "super_admin_role_assignments_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.super_admin_roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: super_admin_role_assignments super_admin_role_assignments_superAdminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_role_assignments
    ADD CONSTRAINT "super_admin_role_assignments_superAdminId_fkey" FOREIGN KEY ("superAdminId") REFERENCES public.super_admins(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: super_admin_role_permissions super_admin_role_permissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_role_permissions
    ADD CONSTRAINT "super_admin_role_permissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public.super_admin_permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: super_admin_role_permissions super_admin_role_permissions_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.super_admin_role_permissions
    ADD CONSTRAINT "super_admin_role_permissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.super_admin_roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tags tags_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT "tags_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tasks tasks_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict hXW55k9h1Us6gj1SMQAbG4hKKnpVToty1R1yOL6DyYjbBiYhV6NEfHyxsqkO3KM

