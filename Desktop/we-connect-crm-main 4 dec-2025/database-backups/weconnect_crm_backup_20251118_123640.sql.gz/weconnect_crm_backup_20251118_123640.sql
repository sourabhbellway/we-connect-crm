--
-- PostgreSQL database dump
--

\restrict 6boYnMTAD9quYwDovDkmUZMhI6Wk8COUQiLE0adpwPZo9TVUJJOTvW4UlBi6pvB

-- Dumped from database version 14.19 (Homebrew)
-- Dumped by pg_dump version 14.19 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ActivityType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."ActivityType" AS ENUM (
    'USER_REGISTRATION',
    'USER_LOGIN',
    'USER_LOGOUT',
    'ROLE_UPDATE',
    'PERMISSION_UPDATE',
    'LEAD_CREATED',
    'LEAD_UPDATED',
    'LEAD_DELETED',
    'SYSTEM_BACKUP',
    'SYSTEM_MAINTENANCE',
    'SECURITY_ALERT',
    'DATABASE_MIGRATION',
    'API_CALL',
    'ERROR_LOG',
    'LEAD_ASSIGNED',
    'LEAD_STATUS_CHANGED',
    'LEAD_CONVERTED',
    'LEAD_FOLLOW_UP_CREATED',
    'LEAD_FOLLOW_UP_COMPLETED',
    'TASK_CREATED',
    'TASK_UPDATED',
    'TASK_COMPLETED',
    'COMMUNICATION_LOGGED',
    'CONTACT_CREATED',
    'DEAL_CREATED',
    'DEAL_UPDATED',
    'DEAL_WON',
    'DEAL_LOST',
    'FILE_UPLOADED',
    'FILE_DELETED',
    'QUOTATION_CREATED',
    'QUOTATION_UPDATED',
    'QUOTATION_SENT',
    'INVOICE_CREATED',
    'INVOICE_UPDATED',
    'INVOICE_SENT',
    'NOTE_ADDED',
    'NOTE_UPDATED'
);


ALTER TYPE public."ActivityType" OWNER TO weconnect_user;

--
-- Name: BudgetPeriod; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."BudgetPeriod" AS ENUM (
    'MONTHLY',
    'QUARTERLY',
    'HALF_YEARLY',
    'ANNUAL',
    'CUSTOM'
);


ALTER TYPE public."BudgetPeriod" OWNER TO weconnect_user;

--
-- Name: BudgetType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."BudgetType" AS ENUM (
    'MONTHLY',
    'QUARTERLY',
    'ANNUAL',
    'PROJECT',
    'DEPARTMENT',
    'CAMPAIGN'
);


ALTER TYPE public."BudgetType" OWNER TO weconnect_user;

--
-- Name: CallStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."CallStatus" AS ENUM (
    'INITIATED',
    'RINGING',
    'ANSWERED',
    'COMPLETED',
    'FAILED',
    'BUSY',
    'NO_ANSWER',
    'CANCELLED'
);


ALTER TYPE public."CallStatus" OWNER TO weconnect_user;

--
-- Name: CallType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."CallType" AS ENUM (
    'INBOUND',
    'OUTBOUND'
);


ALTER TYPE public."CallType" OWNER TO weconnect_user;

--
-- Name: CommunicationType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."CommunicationType" AS ENUM (
    'CALL',
    'EMAIL',
    'SMS',
    'MEETING',
    'NOTE'
);


ALTER TYPE public."CommunicationType" OWNER TO weconnect_user;

--
-- Name: CompanyActivityType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."CompanyActivityType" AS ENUM (
    'CALL',
    'EMAIL',
    'MEETING',
    'VISIT',
    'DEMO',
    'PRESENTATION',
    'FOLLOW_UP',
    'NOTE',
    'QUOTE_SENT',
    'CONTRACT_SENT',
    'PAYMENT_RECEIVED',
    'SUPPORT_TICKET',
    'TRAINING',
    'AUDIT',
    'REVIEW',
    'PARTNERSHIP',
    'OTHER'
);


ALTER TYPE public."CompanyActivityType" OWNER TO weconnect_user;

--
-- Name: CompanySize; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."CompanySize" AS ENUM (
    'STARTUP',
    'SMALL',
    'MEDIUM',
    'LARGE',
    'ENTERPRISE'
);


ALTER TYPE public."CompanySize" OWNER TO weconnect_user;

--
-- Name: CompanyStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."CompanyStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'PROSPECT',
    'CUSTOMER',
    'PARTNER',
    'COMPETITOR'
);


ALTER TYPE public."CompanyStatus" OWNER TO weconnect_user;

--
-- Name: DealStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."DealStatus" AS ENUM (
    'DRAFT',
    'PROPOSAL',
    'NEGOTIATION',
    'WON',
    'LOST'
);


ALTER TYPE public."DealStatus" OWNER TO weconnect_user;

--
-- Name: ExpenseStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."ExpenseStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'REIMBURSED'
);


ALTER TYPE public."ExpenseStatus" OWNER TO weconnect_user;

--
-- Name: ExpenseType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."ExpenseType" AS ENUM (
    'TRAVEL',
    'MEALS',
    'ACCOMMODATION',
    'OFFICE_SUPPLIES',
    'UTILITIES',
    'MARKETING',
    'ENTERTAINMENT',
    'TRAINING',
    'EQUIPMENT',
    'SOFTWARE',
    'CONSULTING',
    'MISCELLANEOUS',
    'OTHER'
);


ALTER TYPE public."ExpenseType" OWNER TO weconnect_user;

--
-- Name: FieldType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."FieldType" AS ENUM (
    'TEXT',
    'NUMBER',
    'DATE',
    'TIME',
    'DROPDOWN',
    'MULTI_SELECT',
    'CHECKBOX',
    'TOGGLE',
    'FILE'
);


ALTER TYPE public."FieldType" OWNER TO weconnect_user;

--
-- Name: IntegrationAuthType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."IntegrationAuthType" AS ENUM (
    'API_KEY',
    'OAUTH',
    'TOKEN'
);


ALTER TYPE public."IntegrationAuthType" OWNER TO weconnect_user;

--
-- Name: IntegrationLogStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."IntegrationLogStatus" AS ENUM (
    'PENDING',
    'SUCCESS',
    'FAILED',
    'PARTIAL'
);


ALTER TYPE public."IntegrationLogStatus" OWNER TO weconnect_user;

--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'VIEWED',
    'PAID',
    'PARTIALLY_PAID',
    'OVERDUE',
    'CANCELLED',
    'REFUNDED'
);


ALTER TYPE public."InvoiceStatus" OWNER TO weconnect_user;

--
-- Name: LeadImportStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."LeadImportStatus" AS ENUM (
    'PROCESSING',
    'COMPLETED',
    'FAILED',
    'PARTIAL'
);


ALTER TYPE public."LeadImportStatus" OWNER TO weconnect_user;

--
-- Name: LeadPriority; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."LeadPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."LeadPriority" OWNER TO weconnect_user;

--
-- Name: LeadStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."LeadStatus" AS ENUM (
    'NEW',
    'CONTACTED',
    'QUALIFIED',
    'PROPOSAL',
    'NEGOTIATION',
    'CLOSED',
    'LOST',
    'CONVERTED'
);


ALTER TYPE public."LeadStatus" OWNER TO weconnect_user;

--
-- Name: LeadSyncStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."LeadSyncStatus" AS ENUM (
    'SYNCED',
    'PENDING',
    'FAILED',
    'CONFLICT'
);


ALTER TYPE public."LeadSyncStatus" OWNER TO weconnect_user;

--
-- Name: MessageStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."MessageStatus" AS ENUM (
    'PENDING',
    'SENT',
    'DELIVERED',
    'READ',
    'FAILED',
    'CANCELLED'
);


ALTER TYPE public."MessageStatus" OWNER TO weconnect_user;

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."NotificationType" AS ENUM (
    'LEAD_CREATED',
    'LEAD_UPDATED',
    'LEAD_ASSIGNED',
    'LEAD_STATUS_CHANGED',
    'CLIENT_REPLY',
    'PAYMENT_ADDED',
    'PAYMENT_UPDATED',
    'TASK_ASSIGNED',
    'TASK_DUE',
    'MEETING_SCHEDULED',
    'FOLLOW_UP_DUE',
    'DEAL_CREATED',
    'DEAL_WON',
    'DEAL_LOST',
    'QUOTATION_SENT',
    'QUOTATION_ACCEPTED',
    'INVOICE_SENT',
    'INVOICE_PAID',
    'SYSTEM'
);


ALTER TYPE public."NotificationType" OWNER TO weconnect_user;

--
-- Name: ProductType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."ProductType" AS ENUM (
    'PHYSICAL',
    'DIGITAL',
    'SERVICE'
);


ALTER TYPE public."ProductType" OWNER TO weconnect_user;

--
-- Name: QuotationStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."QuotationStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'VIEWED',
    'ACCEPTED',
    'REJECTED',
    'EXPIRED',
    'CANCELLED'
);


ALTER TYPE public."QuotationStatus" OWNER TO weconnect_user;

--
-- Name: RoleAccessScope; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."RoleAccessScope" AS ENUM (
    'OWN',
    'GLOBAL'
);


ALTER TYPE public."RoleAccessScope" OWNER TO weconnect_user;

--
-- Name: TaskPriority; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."TaskPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."TaskPriority" OWNER TO weconnect_user;

--
-- Name: TaskStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."TaskStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."TaskStatus" OWNER TO weconnect_user;

--
-- Name: TemplateType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."TemplateType" AS ENUM (
    'EMAIL',
    'WHATSAPP',
    'SMS'
);


ALTER TYPE public."TemplateType" OWNER TO weconnect_user;

--
-- Name: TriggerType; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."TriggerType" AS ENUM (
    'LEAD_CREATED',
    'LEAD_UPDATED',
    'LEAD_STATUS_CHANGED',
    'LEAD_ASSIGNED',
    'MANUAL'
);


ALTER TYPE public."TriggerType" OWNER TO weconnect_user;

--
-- Name: WorkflowExecutionStatus; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."WorkflowExecutionStatus" AS ENUM (
    'PENDING',
    'RUNNING',
    'SUCCESS',
    'FAILED',
    'SKIPPED'
);


ALTER TYPE public."WorkflowExecutionStatus" OWNER TO weconnect_user;

--
-- Name: WorkflowTrigger; Type: TYPE; Schema: public; Owner: weconnect_user
--

CREATE TYPE public."WorkflowTrigger" AS ENUM (
    'LEAD_CREATED',
    'LEAD_UPDATED',
    'LEAD_STATUS_CHANGED',
    'LEAD_ASSIGNED',
    'DEAL_CREATED',
    'DEAL_UPDATED',
    'DEAL_STAGE_CHANGED',
    'TASK_CREATED',
    'TASK_COMPLETED'
);


ALTER TYPE public."WorkflowTrigger" OWNER TO weconnect_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO weconnect_user;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.activities (
    id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    type public."ActivityType" NOT NULL,
    icon text DEFAULT 'FiUser'::text NOT NULL,
    "iconColor" text DEFAULT 'text-blue-600'::text NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" integer,
    "superAdminId" integer,
    "leadId" integer
);


ALTER TABLE public.activities OWNER TO weconnect_user;

--
-- Name: activities_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_id_seq OWNER TO weconnect_user;

--
-- Name: activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.budgets (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "budgetType" public."BudgetType" NOT NULL,
    amount numeric(12,2) NOT NULL,
    spent numeric(12,2) DEFAULT 0 NOT NULL,
    period public."BudgetPeriod" NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "expenseType" public."ExpenseType",
    "projectId" integer,
    "departmentId" integer,
    currency text DEFAULT 'USD'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "alertThreshold" integer DEFAULT 80 NOT NULL,
    "createdBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.budgets OWNER TO weconnect_user;

--
-- Name: budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.budgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.budgets_id_seq OWNER TO weconnect_user;

--
-- Name: budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.budgets_id_seq OWNED BY public.budgets.id;


--
-- Name: business_settings; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.business_settings (
    id integer NOT NULL,
    "companyName" text NOT NULL,
    "companyEmail" text,
    "companyPhone" text,
    "companyAddress" text,
    "companyWebsite" text,
    "companyLogo" text,
    "timeZone" text DEFAULT 'UTC'::text NOT NULL,
    "dateFormat" text DEFAULT 'MM/DD/YYYY'::text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "passwordMinLength" integer DEFAULT 8 NOT NULL,
    "passwordRequireUpper" boolean DEFAULT true NOT NULL,
    "passwordRequireLower" boolean DEFAULT true NOT NULL,
    "passwordRequireNumber" boolean DEFAULT true NOT NULL,
    "passwordRequireSymbol" boolean DEFAULT false NOT NULL,
    "sessionTimeout" integer DEFAULT 24 NOT NULL,
    "maxLoginAttempts" integer DEFAULT 5 NOT NULL,
    "accountLockDuration" integer DEFAULT 30 NOT NULL,
    "twoFactorRequired" boolean DEFAULT false NOT NULL,
    "emailVerificationRequired" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "leadAutoAssignmentEnabled" boolean DEFAULT false NOT NULL,
    "leadFollowUpReminderDays" integer DEFAULT 3 NOT NULL,
    "metaAdsApiKey" text,
    "metaAdsApiSecret" text,
    "metaAdsEnabled" boolean DEFAULT false NOT NULL,
    "indiamartApiKey" text,
    "indiamartApiSecret" text,
    "indiamartEnabled" boolean DEFAULT false NOT NULL,
    "tradindiaApiKey" text,
    "tradindiaApiSecret" text,
    "tradindiaEnabled" boolean DEFAULT false NOT NULL,
    "gstNumber" text,
    "panNumber" text,
    "cinNumber" text,
    "fiscalYearStart" text,
    industry text,
    "employeeCount" text,
    description text
);


ALTER TABLE public.business_settings OWNER TO weconnect_user;

--
-- Name: business_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.business_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.business_settings_id_seq OWNER TO weconnect_user;

--
-- Name: business_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.business_settings_id_seq OWNED BY public.business_settings.id;


--
-- Name: call_logs; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.call_logs (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "userId" integer NOT NULL,
    "phoneNumber" text NOT NULL,
    "callType" public."CallType" DEFAULT 'OUTBOUND'::public."CallType" NOT NULL,
    "callStatus" public."CallStatus" DEFAULT 'INITIATED'::public."CallStatus" NOT NULL,
    duration integer,
    "startTime" timestamp(3) without time zone,
    "endTime" timestamp(3) without time zone,
    notes text,
    outcome text,
    "recordingUrl" text,
    "isAnswered" boolean DEFAULT false NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.call_logs OWNER TO weconnect_user;

--
-- Name: call_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.call_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.call_logs_id_seq OWNER TO weconnect_user;

--
-- Name: call_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.call_logs_id_seq OWNED BY public.call_logs.id;


--
-- Name: communication_automations; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.communication_automations (
    id integer NOT NULL,
    name text NOT NULL,
    "triggerType" public."TriggerType" NOT NULL,
    "templateId" integer NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    conditions jsonb,
    delay integer,
    "companyId" integer,
    "createdBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.communication_automations OWNER TO weconnect_user;

--
-- Name: communication_automations_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.communication_automations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.communication_automations_id_seq OWNER TO weconnect_user;

--
-- Name: communication_automations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.communication_automations_id_seq OWNED BY public.communication_automations.id;


--
-- Name: communication_messages; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.communication_messages (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "userId" integer NOT NULL,
    "templateId" integer,
    type public."TemplateType" NOT NULL,
    recipient text NOT NULL,
    subject text,
    content text NOT NULL,
    status public."MessageStatus" DEFAULT 'PENDING'::public."MessageStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "readAt" timestamp(3) without time zone,
    "failedAt" timestamp(3) without time zone,
    "errorMessage" text,
    "externalId" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.communication_messages OWNER TO weconnect_user;

--
-- Name: communication_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.communication_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.communication_messages_id_seq OWNER TO weconnect_user;

--
-- Name: communication_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.communication_messages_id_seq OWNED BY public.communication_messages.id;


--
-- Name: communication_providers; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.communication_providers (
    id integer NOT NULL,
    name text NOT NULL,
    type public."TemplateType" NOT NULL,
    config jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "companyId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.communication_providers OWNER TO weconnect_user;

--
-- Name: communication_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.communication_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.communication_providers_id_seq OWNER TO weconnect_user;

--
-- Name: communication_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.communication_providers_id_seq OWNED BY public.communication_providers.id;


--
-- Name: communication_templates; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.communication_templates (
    id integer NOT NULL,
    name text NOT NULL,
    type public."TemplateType" NOT NULL,
    subject text,
    content text NOT NULL,
    variables jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "companyId" integer,
    "createdBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.communication_templates OWNER TO weconnect_user;

--
-- Name: communication_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.communication_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.communication_templates_id_seq OWNER TO weconnect_user;

--
-- Name: communication_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.communication_templates_id_seq OWNED BY public.communication_templates.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    domain text,
    "isActive" boolean DEFAULT true NOT NULL,
    slug text,
    "industryId" integer,
    address text,
    "alternatePhone" text,
    "annualRevenue" numeric(15,2),
    "assignedTo" integer,
    city text,
    "companySize" public."CompanySize" DEFAULT 'SMALL'::public."CompanySize",
    country text,
    currency text DEFAULT 'USD'::text,
    "deletedAt" timestamp(3) without time zone,
    description text,
    email text,
    "employeeCount" text,
    "facebookPage" text,
    "foundedYear" integer,
    "lastContactedAt" timestamp(3) without time zone,
    "leadScore" integer DEFAULT 0,
    "linkedinProfile" text,
    "nextFollowUpAt" timestamp(3) without time zone,
    notes text,
    "parentCompanyId" integer,
    phone text,
    state text,
    status public."CompanyStatus" DEFAULT 'ACTIVE'::public."CompanyStatus" NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    timezone text DEFAULT 'UTC'::text,
    "twitterHandle" text,
    website text,
    "zipCode" text
);


ALTER TABLE public.companies OWNER TO weconnect_user;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_id_seq OWNER TO weconnect_user;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: company_activities; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.company_activities (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer,
    type public."CompanyActivityType" NOT NULL,
    title text NOT NULL,
    description text,
    duration integer,
    outcome text,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "isCompleted" boolean DEFAULT false NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.company_activities OWNER TO weconnect_user;

--
-- Name: company_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.company_activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_activities_id_seq OWNER TO weconnect_user;

--
-- Name: company_activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.company_activities_id_seq OWNED BY public.company_activities.id;


--
-- Name: company_communications; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.company_communications (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    type public."CommunicationType" NOT NULL,
    subject text,
    content text NOT NULL,
    direction text DEFAULT 'outbound'::text NOT NULL,
    status public."MessageStatus" DEFAULT 'PENDING'::public."MessageStatus" NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "readAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.company_communications OWNER TO weconnect_user;

--
-- Name: company_communications_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.company_communications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_communications_id_seq OWNER TO weconnect_user;

--
-- Name: company_communications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.company_communications_id_seq OWNED BY public.company_communications.id;


--
-- Name: company_followups; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.company_followups (
    id integer NOT NULL,
    "companyId" integer NOT NULL,
    "userId" integer NOT NULL,
    type public."CommunicationType" DEFAULT 'NOTE'::public."CommunicationType" NOT NULL,
    subject text NOT NULL,
    notes text,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "isCompleted" boolean DEFAULT false NOT NULL,
    "reminderSet" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.company_followups OWNER TO weconnect_user;

--
-- Name: company_followups_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.company_followups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_followups_id_seq OWNER TO weconnect_user;

--
-- Name: company_followups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.company_followups_id_seq OWNED BY public.company_followups.id;


--
-- Name: deal_products; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.deal_products (
    id integer NOT NULL,
    "dealId" integer NOT NULL,
    name text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    price numeric(10,2) NOT NULL
);


ALTER TABLE public.deal_products OWNER TO weconnect_user;

--
-- Name: deal_products_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.deal_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deal_products_id_seq OWNER TO weconnect_user;

--
-- Name: deal_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.deal_products_id_seq OWNED BY public.deal_products.id;


--
-- Name: deals; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.deals (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    value numeric(65,30) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status public."DealStatus" DEFAULT 'DRAFT'::public."DealStatus" NOT NULL,
    probability integer DEFAULT 0 NOT NULL,
    "expectedCloseDate" timestamp(3) without time zone,
    "actualCloseDate" timestamp(3) without time zone,
    "assignedTo" integer,
    "leadId" integer,
    "companyId" integer,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.deals OWNER TO weconnect_user;

--
-- Name: deals_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.deals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deals_id_seq OWNER TO weconnect_user;

--
-- Name: deals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.deals_id_seq OWNED BY public.deals.id;


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.expenses (
    id integer NOT NULL,
    "expenseDate" timestamp(3) without time zone NOT NULL,
    amount numeric(12,2) NOT NULL,
    type public."ExpenseType" NOT NULL,
    category text NOT NULL,
    description text,
    remarks text,
    "receiptUrl" text,
    status public."ExpenseStatus" DEFAULT 'PENDING'::public."ExpenseStatus" NOT NULL,
    "submittedBy" integer NOT NULL,
    "approvedBy" integer,
    "rejectedBy" integer,
    "approvalRemarks" text,
    "projectId" integer,
    "dealId" integer,
    "leadId" integer,
    currency text DEFAULT 'USD'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "approvedAt" timestamp(3) without time zone
);


ALTER TABLE public.expenses OWNER TO weconnect_user;

--
-- Name: expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.expenses_id_seq OWNER TO weconnect_user;

--
-- Name: expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.expenses_id_seq OWNED BY public.expenses.id;


--
-- Name: files; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.files (
    id integer NOT NULL,
    name text NOT NULL,
    "fileName" text NOT NULL,
    "filePath" text NOT NULL,
    "fileSize" integer NOT NULL,
    "mimeType" text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" integer NOT NULL,
    "uploadedBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.files OWNER TO weconnect_user;

--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.files_id_seq OWNER TO weconnect_user;

--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- Name: industries; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.industries (
    id integer NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.industries OWNER TO weconnect_user;

--
-- Name: industries_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.industries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.industries_id_seq OWNER TO weconnect_user;

--
-- Name: industries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.industries_id_seq OWNED BY public.industries.id;


--
-- Name: industry_fields; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.industry_fields (
    id integer NOT NULL,
    "industryId" integer NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    type public."FieldType" DEFAULT 'TEXT'::public."FieldType" NOT NULL,
    "isRequired" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.industry_fields OWNER TO weconnect_user;

--
-- Name: industry_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.industry_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.industry_fields_id_seq OWNER TO weconnect_user;

--
-- Name: industry_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.industry_fields_id_seq OWNED BY public.industry_fields.id;


--
-- Name: integration_logs; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.integration_logs (
    id integer NOT NULL,
    "integrationId" integer NOT NULL,
    operation text NOT NULL,
    status public."IntegrationLogStatus" DEFAULT 'PENDING'::public."IntegrationLogStatus" NOT NULL,
    message text,
    data jsonb,
    "errorDetails" text,
    "recordsCount" integer DEFAULT 0,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.integration_logs OWNER TO weconnect_user;

--
-- Name: integration_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.integration_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.integration_logs_id_seq OWNER TO weconnect_user;

--
-- Name: integration_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.integration_logs_id_seq OWNED BY public.integration_logs.id;


--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.invoice_items (
    id integer NOT NULL,
    "invoiceId" integer NOT NULL,
    "productId" integer,
    name text NOT NULL,
    description text,
    quantity numeric(10,2) NOT NULL,
    unit text DEFAULT 'pcs'::text,
    "unitPrice" numeric(10,2) NOT NULL,
    "taxRate" numeric(5,2) DEFAULT 0 NOT NULL,
    "discountRate" numeric(5,2) DEFAULT 0 NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.invoice_items OWNER TO weconnect_user;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoice_items_id_seq OWNER TO weconnect_user;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.invoice_items_id_seq OWNED BY public.invoice_items.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    "invoiceNumber" text NOT NULL,
    title text NOT NULL,
    description text,
    status public."InvoiceStatus" DEFAULT 'DRAFT'::public."InvoiceStatus" NOT NULL,
    subtotal numeric(12,2) NOT NULL,
    "taxAmount" numeric(12,2) NOT NULL,
    "discountAmount" numeric(12,2) DEFAULT 0 NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL,
    "paidAmount" numeric(12,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "dueDate" timestamp(3) without time zone,
    notes text,
    terms text,
    "companyId" integer,
    "leadId" integer,
    "dealId" integer,
    "quotationId" integer,
    "createdBy" integer NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "viewedAt" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.invoices OWNER TO weconnect_user;

--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoices_id_seq OWNER TO weconnect_user;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: lead_assignment_rules; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.lead_assignment_rules (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lead_assignment_rules OWNER TO weconnect_user;

--
-- Name: lead_assignment_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.lead_assignment_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_assignment_rules_id_seq OWNER TO weconnect_user;

--
-- Name: lead_assignment_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.lead_assignment_rules_id_seq OWNED BY public.lead_assignment_rules.id;


--
-- Name: lead_communications; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.lead_communications (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "userId" integer NOT NULL,
    type public."CommunicationType" NOT NULL,
    subject text,
    content text NOT NULL,
    direction text DEFAULT 'outbound'::text NOT NULL,
    duration integer,
    outcome text,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lead_communications OWNER TO weconnect_user;

--
-- Name: lead_communications_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.lead_communications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_communications_id_seq OWNER TO weconnect_user;

--
-- Name: lead_communications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.lead_communications_id_seq OWNED BY public.lead_communications.id;


--
-- Name: lead_followups; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.lead_followups (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "userId" integer NOT NULL,
    type public."CommunicationType" DEFAULT 'NOTE'::public."CommunicationType" NOT NULL,
    subject text NOT NULL,
    notes text,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "isCompleted" boolean DEFAULT false NOT NULL,
    "reminderSet" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lead_followups OWNER TO weconnect_user;

--
-- Name: lead_followups_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.lead_followups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_followups_id_seq OWNER TO weconnect_user;

--
-- Name: lead_followups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.lead_followups_id_seq OWNED BY public.lead_followups.id;


--
-- Name: lead_import_batches; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.lead_import_batches (
    id integer NOT NULL,
    "fileName" text NOT NULL,
    "totalRows" integer NOT NULL,
    "successRows" integer DEFAULT 0 NOT NULL,
    "failedRows" integer DEFAULT 0 NOT NULL,
    status public."LeadImportStatus" DEFAULT 'PROCESSING'::public."LeadImportStatus" NOT NULL,
    "errorDetails" jsonb,
    "createdBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lead_import_batches OWNER TO weconnect_user;

--
-- Name: lead_import_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.lead_import_batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_import_batches_id_seq OWNER TO weconnect_user;

--
-- Name: lead_import_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.lead_import_batches_id_seq OWNED BY public.lead_import_batches.id;


--
-- Name: lead_import_records; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.lead_import_records (
    id integer NOT NULL,
    "batchId" integer NOT NULL,
    "rowIndex" integer NOT NULL,
    "leadId" integer,
    status public."LeadImportStatus" DEFAULT 'PROCESSING'::public."LeadImportStatus" NOT NULL,
    errors jsonb,
    "rawData" jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lead_import_records OWNER TO weconnect_user;

--
-- Name: lead_import_records_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.lead_import_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_import_records_id_seq OWNER TO weconnect_user;

--
-- Name: lead_import_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.lead_import_records_id_seq OWNED BY public.lead_import_records.id;


--
-- Name: lead_integration_sync; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.lead_integration_sync (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "integrationId" integer NOT NULL,
    "externalId" text NOT NULL,
    "externalData" jsonb,
    "syncStatus" public."LeadSyncStatus" DEFAULT 'SYNCED'::public."LeadSyncStatus" NOT NULL,
    "lastSyncAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.lead_integration_sync OWNER TO weconnect_user;

--
-- Name: lead_integration_sync_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.lead_integration_sync_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_integration_sync_id_seq OWNER TO weconnect_user;

--
-- Name: lead_integration_sync_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.lead_integration_sync_id_seq OWNED BY public.lead_integration_sync.id;


--
-- Name: lead_sources; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.lead_sources (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "companyId" integer,
    color text DEFAULT '#6B7280'::text NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.lead_sources OWNER TO weconnect_user;

--
-- Name: lead_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.lead_sources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_sources_id_seq OWNER TO weconnect_user;

--
-- Name: lead_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.lead_sources_id_seq OWNED BY public.lead_sources.id;


--
-- Name: lead_tags; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.lead_tags (
    id integer NOT NULL,
    "leadId" integer NOT NULL,
    "tagId" integer NOT NULL
);


ALTER TABLE public.lead_tags OWNER TO weconnect_user;

--
-- Name: lead_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.lead_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lead_tags_id_seq OWNER TO weconnect_user;

--
-- Name: lead_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.lead_tags_id_seq OWNED BY public.lead_tags.id;


--
-- Name: leads; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.leads (
    id integer NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text NOT NULL,
    phone text,
    company text,
    "position" text,
    status public."LeadStatus" DEFAULT 'NEW'::public."LeadStatus" NOT NULL,
    notes text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "sourceId" integer,
    "assignedTo" integer,
    "companyId" integer,
    "deletedAt" timestamp(3) without time zone,
    budget numeric(10,2),
    currency text DEFAULT 'USD'::text,
    "lastContactedAt" timestamp(3) without time zone,
    "nextFollowUpAt" timestamp(3) without time zone,
    priority public."LeadPriority" DEFAULT 'MEDIUM'::public."LeadPriority" NOT NULL,
    industry text,
    website text,
    "companySize" integer,
    "annualRevenue" numeric(15,2),
    "leadScore" integer,
    address text,
    country text,
    state text,
    city text,
    "zipCode" text,
    "linkedinProfile" text,
    timezone text,
    "preferredContactMethod" text DEFAULT 'email'::text,
    "convertedToDealId" integer,
    "previousStatus" public."LeadStatus"
);


ALTER TABLE public.leads OWNER TO weconnect_user;

--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.leads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.leads_id_seq OWNER TO weconnect_user;

--
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.leads_id_seq OWNED BY public.leads.id;


--
-- Name: login_sessions; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.login_sessions (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token text NOT NULL,
    "deviceInfo" text,
    "ipAddress" text,
    "userAgent" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastUsedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.login_sessions OWNER TO weconnect_user;

--
-- Name: login_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.login_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.login_sessions_id_seq OWNER TO weconnect_user;

--
-- Name: login_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.login_sessions_id_seq OWNED BY public.login_sessions.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.notes (
    id integer NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "isPinned" boolean DEFAULT false NOT NULL,
    "leadId" integer NOT NULL,
    "createdBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.notes OWNER TO weconnect_user;

--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notes_id_seq OWNER TO weconnect_user;

--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.notes_id_seq OWNED BY public.notes.id;


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.notification_preferences (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "inAppEnabled" boolean DEFAULT true NOT NULL,
    "emailEnabled" boolean DEFAULT false NOT NULL,
    "soundEnabled" boolean DEFAULT true NOT NULL,
    preferences jsonb DEFAULT '{"taskDue": true, "clientReply": true, "followUpDue": true, "leadCreated": true, "leadUpdated": true, "leadAssigned": true, "paymentAdded": true, "taskAssigned": true, "paymentUpdated": true, "meetingScheduled": true}'::jsonb NOT NULL,
    "doNotDisturbStart" integer,
    "doNotDisturbEnd" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.notification_preferences OWNER TO weconnect_user;

--
-- Name: notification_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.notification_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_preferences_id_seq OWNER TO weconnect_user;

--
-- Name: notification_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.notification_preferences_id_seq OWNED BY public.notification_preferences.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    type public."NotificationType" NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    link text,
    read boolean DEFAULT false NOT NULL,
    "readAt" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.notifications OWNER TO weconnect_user;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO weconnect_user;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: password_history; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.password_history (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.password_history OWNER TO weconnect_user;

--
-- Name: password_history_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.password_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.password_history_id_seq OWNER TO weconnect_user;

--
-- Name: password_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.password_history_id_seq OWNED BY public.password_history.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    "invoiceId" integer NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "paymentMethod" text NOT NULL,
    "paymentDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "referenceNumber" text,
    notes text,
    "createdBy" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO weconnect_user;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO weconnect_user;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    description text,
    module text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.permissions OWNER TO weconnect_user;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO weconnect_user;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    sku text,
    type public."ProductType" DEFAULT 'PHYSICAL'::public."ProductType" NOT NULL,
    category text,
    price numeric(10,2) NOT NULL,
    cost numeric(10,2),
    currency text DEFAULT 'USD'::text NOT NULL,
    unit text DEFAULT 'pcs'::text,
    "taxRate" numeric(5,2),
    "isActive" boolean DEFAULT true NOT NULL,
    "stockQuantity" integer DEFAULT 0,
    "minStockLevel" integer DEFAULT 0,
    "maxStockLevel" integer DEFAULT 0,
    image text,
    "companyId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.products OWNER TO weconnect_user;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO weconnect_user;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: proposal_templates; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.proposal_templates (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    content text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "headerHtml" text,
    "footerHtml" text,
    styles jsonb,
    variables jsonb,
    "previewImage" text,
    category text DEFAULT 'business'::text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.proposal_templates OWNER TO weconnect_user;

--
-- Name: proposal_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.proposal_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proposal_templates_id_seq OWNER TO weconnect_user;

--
-- Name: proposal_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.proposal_templates_id_seq OWNED BY public.proposal_templates.id;


--
-- Name: quotation_items; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.quotation_items (
    id integer NOT NULL,
    "quotationId" integer NOT NULL,
    "productId" integer,
    name text NOT NULL,
    description text,
    quantity numeric(10,2) NOT NULL,
    unit text DEFAULT 'pcs'::text,
    "unitPrice" numeric(10,2) NOT NULL,
    "taxRate" numeric(5,2) DEFAULT 0 NOT NULL,
    "discountRate" numeric(5,2) DEFAULT 0 NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.quotation_items OWNER TO weconnect_user;

--
-- Name: quotation_items_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.quotation_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quotation_items_id_seq OWNER TO weconnect_user;

--
-- Name: quotation_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.quotation_items_id_seq OWNED BY public.quotation_items.id;


--
-- Name: quotation_templates; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.quotation_templates (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "headerContent" text,
    "footerContent" text,
    "termsAndConditions" text,
    "validityDays" integer DEFAULT 30 NOT NULL,
    "showTax" boolean DEFAULT true NOT NULL,
    "showDiscount" boolean DEFAULT true NOT NULL,
    "logoPosition" text DEFAULT 'left'::text NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    styles jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.quotation_templates OWNER TO weconnect_user;

--
-- Name: quotation_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.quotation_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quotation_templates_id_seq OWNER TO weconnect_user;

--
-- Name: quotation_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.quotation_templates_id_seq OWNED BY public.quotation_templates.id;


--
-- Name: quotations; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.quotations (
    id integer NOT NULL,
    "quotationNumber" text NOT NULL,
    title text NOT NULL,
    description text,
    status public."QuotationStatus" DEFAULT 'DRAFT'::public."QuotationStatus" NOT NULL,
    subtotal numeric(12,2) NOT NULL,
    "taxAmount" numeric(12,2) NOT NULL,
    "discountAmount" numeric(12,2) DEFAULT 0 NOT NULL,
    "totalAmount" numeric(12,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "validUntil" timestamp(3) without time zone,
    notes text,
    terms text,
    "companyId" integer,
    "leadId" integer,
    "dealId" integer,
    "createdBy" integer NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "viewedAt" timestamp(3) without time zone,
    "acceptedAt" timestamp(3) without time zone,
    "rejectedAt" timestamp(3) without time zone,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.quotations OWNER TO weconnect_user;

--
-- Name: quotations_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.quotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quotations_id_seq OWNER TO weconnect_user;

--
-- Name: quotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.quotations_id_seq OWNED BY public.quotations.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.refresh_tokens (
    id integer NOT NULL,
    token text NOT NULL,
    "userId" integer NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "isRevoked" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO weconnect_user;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.refresh_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.refresh_tokens_id_seq OWNER TO weconnect_user;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.refresh_tokens_id_seq OWNED BY public.refresh_tokens.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.role_permissions (
    id integer NOT NULL,
    "roleId" integer NOT NULL,
    "permissionId" integer NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO weconnect_user;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_permissions_id_seq OWNER TO weconnect_user;

--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "accessScope" public."RoleAccessScope" DEFAULT 'OWN'::public."RoleAccessScope" NOT NULL
);


ALTER TABLE public.roles OWNER TO weconnect_user;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO weconnect_user;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: super_admin_permissions; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.super_admin_permissions (
    id integer NOT NULL,
    name text NOT NULL,
    key text NOT NULL,
    description text,
    module text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.super_admin_permissions OWNER TO weconnect_user;

--
-- Name: super_admin_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.super_admin_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.super_admin_permissions_id_seq OWNER TO weconnect_user;

--
-- Name: super_admin_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.super_admin_permissions_id_seq OWNED BY public.super_admin_permissions.id;


--
-- Name: super_admin_role_assignments; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.super_admin_role_assignments (
    id integer NOT NULL,
    "superAdminId" integer NOT NULL,
    "roleId" integer NOT NULL
);


ALTER TABLE public.super_admin_role_assignments OWNER TO weconnect_user;

--
-- Name: super_admin_role_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.super_admin_role_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.super_admin_role_assignments_id_seq OWNER TO weconnect_user;

--
-- Name: super_admin_role_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.super_admin_role_assignments_id_seq OWNED BY public.super_admin_role_assignments.id;


--
-- Name: super_admin_role_permissions; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.super_admin_role_permissions (
    id integer NOT NULL,
    "roleId" integer NOT NULL,
    "permissionId" integer NOT NULL
);


ALTER TABLE public.super_admin_role_permissions OWNER TO weconnect_user;

--
-- Name: super_admin_role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.super_admin_role_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.super_admin_role_permissions_id_seq OWNER TO weconnect_user;

--
-- Name: super_admin_role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.super_admin_role_permissions_id_seq OWNED BY public.super_admin_role_permissions.id;


--
-- Name: super_admin_roles; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.super_admin_roles (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.super_admin_roles OWNER TO weconnect_user;

--
-- Name: super_admin_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.super_admin_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.super_admin_roles_id_seq OWNER TO weconnect_user;

--
-- Name: super_admin_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.super_admin_roles_id_seq OWNED BY public.super_admin_roles.id;


--
-- Name: super_admins; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.super_admins (
    id integer NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "profilePicture" text
);


ALTER TABLE public.super_admins OWNER TO weconnect_user;

--
-- Name: super_admins_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.super_admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.super_admins_id_seq OWNER TO weconnect_user;

--
-- Name: super_admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.super_admins_id_seq OWNED BY public.super_admins.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    name text NOT NULL,
    color text DEFAULT '#3B82F6'::text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "companyId" integer
);


ALTER TABLE public.tags OWNER TO weconnect_user;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_id_seq OWNER TO weconnect_user;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    status public."TaskStatus" DEFAULT 'PENDING'::public."TaskStatus" NOT NULL,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "assignedTo" integer,
    "createdBy" integer NOT NULL,
    "leadId" integer,
    "dealId" integer,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.tasks OWNER TO weconnect_user;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_seq OWNER TO weconnect_user;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: third_party_integrations; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.third_party_integrations (
    id integer NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "apiEndpoint" text NOT NULL,
    "authType" public."IntegrationAuthType" DEFAULT 'API_KEY'::public."IntegrationAuthType" NOT NULL,
    config jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.third_party_integrations OWNER TO weconnect_user;

--
-- Name: third_party_integrations_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.third_party_integrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.third_party_integrations_id_seq OWNER TO weconnect_user;

--
-- Name: third_party_integrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.third_party_integrations_id_seq OWNED BY public.third_party_integrations.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "roleId" integer NOT NULL
);


ALTER TABLE public.user_roles OWNER TO weconnect_user;

--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_roles_id_seq OWNER TO weconnect_user;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "profilePicture" text,
    "companyId" integer,
    "deletedAt" timestamp(3) without time zone,
    "accountLockedUntil" timestamp(3) without time zone,
    "emailVerificationToken" text,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "emailVerifiedAt" timestamp(3) without time zone,
    "failedLoginAttempts" integer DEFAULT 0 NOT NULL,
    "passwordResetExpires" timestamp(3) without time zone,
    "passwordResetToken" text,
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "twoFactorSecret" text,
    "dateOfBirth" timestamp(3) without time zone,
    "managerId" integer,
    "mustChangePassword" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO weconnect_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO weconnect_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: workflow_executions; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.workflow_executions (
    id integer NOT NULL,
    "workflowId" integer NOT NULL,
    "triggerData" jsonb NOT NULL,
    status public."WorkflowExecutionStatus" NOT NULL,
    result jsonb,
    error text,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    duration integer
);


ALTER TABLE public.workflow_executions OWNER TO weconnect_user;

--
-- Name: workflow_executions_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.workflow_executions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.workflow_executions_id_seq OWNER TO weconnect_user;

--
-- Name: workflow_executions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.workflow_executions_id_seq OWNED BY public.workflow_executions.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: weconnect_user
--

CREATE TABLE public.workflows (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    trigger public."WorkflowTrigger" NOT NULL,
    "triggerData" jsonb,
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    "createdBy" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.workflows OWNER TO weconnect_user;

--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: weconnect_user
--

CREATE SEQUENCE public.workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.workflows_id_seq OWNER TO weconnect_user;

--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: weconnect_user
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: activities id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.activities ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);


--
-- Name: budgets id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.budgets ALTER COLUMN id SET DEFAULT nextval('public.budgets_id_seq'::regclass);


--
-- Name: business_settings id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.business_settings ALTER COLUMN id SET DEFAULT nextval('public.business_settings_id_seq'::regclass);


--
-- Name: call_logs id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.call_logs ALTER COLUMN id SET DEFAULT nextval('public.call_logs_id_seq'::regclass);


--
-- Name: communication_automations id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_automations ALTER COLUMN id SET DEFAULT nextval('public.communication_automations_id_seq'::regclass);


--
-- Name: communication_messages id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_messages ALTER COLUMN id SET DEFAULT nextval('public.communication_messages_id_seq'::regclass);


--
-- Name: communication_providers id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_providers ALTER COLUMN id SET DEFAULT nextval('public.communication_providers_id_seq'::regclass);


--
-- Name: communication_templates id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_templates ALTER COLUMN id SET DEFAULT nextval('public.communication_templates_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: company_activities id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_activities ALTER COLUMN id SET DEFAULT nextval('public.company_activities_id_seq'::regclass);


--
-- Name: company_communications id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_communications ALTER COLUMN id SET DEFAULT nextval('public.company_communications_id_seq'::regclass);


--
-- Name: company_followups id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_followups ALTER COLUMN id SET DEFAULT nextval('public.company_followups_id_seq'::regclass);


--
-- Name: deal_products id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.deal_products ALTER COLUMN id SET DEFAULT nextval('public.deal_products_id_seq'::regclass);


--
-- Name: deals id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.deals ALTER COLUMN id SET DEFAULT nextval('public.deals_id_seq'::regclass);


--
-- Name: expenses id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.expenses ALTER COLUMN id SET DEFAULT nextval('public.expenses_id_seq'::regclass);


--
-- Name: files id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- Name: industries id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.industries ALTER COLUMN id SET DEFAULT nextval('public.industries_id_seq'::regclass);


--
-- Name: industry_fields id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.industry_fields ALTER COLUMN id SET DEFAULT nextval('public.industry_fields_id_seq'::regclass);


--
-- Name: integration_logs id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.integration_logs ALTER COLUMN id SET DEFAULT nextval('public.integration_logs_id_seq'::regclass);


--
-- Name: invoice_items id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.invoice_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_items_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: lead_assignment_rules id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_assignment_rules ALTER COLUMN id SET DEFAULT nextval('public.lead_assignment_rules_id_seq'::regclass);


--
-- Name: lead_communications id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_communications ALTER COLUMN id SET DEFAULT nextval('public.lead_communications_id_seq'::regclass);


--
-- Name: lead_followups id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_followups ALTER COLUMN id SET DEFAULT nextval('public.lead_followups_id_seq'::regclass);


--
-- Name: lead_import_batches id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_import_batches ALTER COLUMN id SET DEFAULT nextval('public.lead_import_batches_id_seq'::regclass);


--
-- Name: lead_import_records id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_import_records ALTER COLUMN id SET DEFAULT nextval('public.lead_import_records_id_seq'::regclass);


--
-- Name: lead_integration_sync id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_integration_sync ALTER COLUMN id SET DEFAULT nextval('public.lead_integration_sync_id_seq'::regclass);


--
-- Name: lead_sources id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_sources ALTER COLUMN id SET DEFAULT nextval('public.lead_sources_id_seq'::regclass);


--
-- Name: lead_tags id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_tags ALTER COLUMN id SET DEFAULT nextval('public.lead_tags_id_seq'::regclass);


--
-- Name: leads id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.leads ALTER COLUMN id SET DEFAULT nextval('public.leads_id_seq'::regclass);


--
-- Name: login_sessions id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.login_sessions ALTER COLUMN id SET DEFAULT nextval('public.login_sessions_id_seq'::regclass);


--
-- Name: notes id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.notes ALTER COLUMN id SET DEFAULT nextval('public.notes_id_seq'::regclass);


--
-- Name: notification_preferences id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.notification_preferences ALTER COLUMN id SET DEFAULT nextval('public.notification_preferences_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: password_history id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.password_history ALTER COLUMN id SET DEFAULT nextval('public.password_history_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: proposal_templates id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.proposal_templates ALTER COLUMN id SET DEFAULT nextval('public.proposal_templates_id_seq'::regclass);


--
-- Name: quotation_items id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotation_items ALTER COLUMN id SET DEFAULT nextval('public.quotation_items_id_seq'::regclass);


--
-- Name: quotation_templates id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotation_templates ALTER COLUMN id SET DEFAULT nextval('public.quotation_templates_id_seq'::regclass);


--
-- Name: quotations id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotations ALTER COLUMN id SET DEFAULT nextval('public.quotations_id_seq'::regclass);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('public.refresh_tokens_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: super_admin_permissions id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_permissions ALTER COLUMN id SET DEFAULT nextval('public.super_admin_permissions_id_seq'::regclass);


--
-- Name: super_admin_role_assignments id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_role_assignments ALTER COLUMN id SET DEFAULT nextval('public.super_admin_role_assignments_id_seq'::regclass);


--
-- Name: super_admin_role_permissions id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_role_permissions ALTER COLUMN id SET DEFAULT nextval('public.super_admin_role_permissions_id_seq'::regclass);


--
-- Name: super_admin_roles id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_roles ALTER COLUMN id SET DEFAULT nextval('public.super_admin_roles_id_seq'::regclass);


--
-- Name: super_admins id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admins ALTER COLUMN id SET DEFAULT nextval('public.super_admins_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: third_party_integrations id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.third_party_integrations ALTER COLUMN id SET DEFAULT nextval('public.third_party_integrations_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: workflow_executions id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.workflow_executions ALTER COLUMN id SET DEFAULT nextval('public.workflow_executions_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
bbf28800-97f4-4afb-9288-29bb2d571689	06fcf0e7b72946c1e93ac8cead83a6996c63c0e9ce92f9fa67ec9a41ed9eabc7	2025-11-17 15:32:09.468283+05:30	20251028180021_init	\N	\N	2025-11-17 15:32:09.373996+05:30	1
fe52b488-5196-4138-98e6-bbe9f2cdae81	7b8f190cfd78f4c891ceab4723237834df72cbfbb17e8f46682ed61dd9fc6c73	2025-11-17 15:32:09.470181+05:30	20251101054853_add_role_access_scope	\N	\N	2025-11-17 15:32:09.468553+05:30	1
9c15fb42-a7e5-4fd8-8eea-06e20e62f714	9500552e13cc0d51674275709fc28e556c848aba0cc8441f0d5d17ed4002c7ce	2025-11-17 15:32:09.476222+05:30	20251105061358_remove_contact_module	\N	\N	2025-11-17 15:32:09.470767+05:30	1
7681739c-e6d5-4515-8685-7d6b644f8e94	54a0dca3214f5a387e1cc69e7ddd9e65f538fa6172ced3846eb9423e608a53cc	2025-11-17 15:32:09.478227+05:30	20251105071011_add_lead_conversion_tracking	\N	\N	2025-11-17 15:32:09.476478+05:30	1
92dc5c42-898e-4762-9f60-8d8363190e8b	9d1929baef4eaf57ac086968bb955b4689b2086477a390e39a1542787037b866	2025-11-17 15:32:09.479386+05:30	20251105125802_add_lead_relation_to_activity	\N	\N	2025-11-17 15:32:09.47842+05:30	1
e72e3b2d-a10e-4a42-8638-0e0b27370099	f1b71239a0400751401129f58a8072eed322d2429eac13b91373e951f3418d51	2025-11-17 15:32:09.480175+05:30	20251106120000_add_previous_status_manual	\N	\N	2025-11-17 15:32:09.479623+05:30	1
d8c94972-cacf-4691-a08f-9897fc1fbc5c	392db476bd955ed1249884dcfe447eeab446c5fd54337cdacd47f6fa28eb8df8	2025-11-17 15:32:09.48305+05:30	20251106130000_add_notes_table_manual	\N	\N	2025-11-17 15:32:09.480359+05:30	1
3edc93df-040c-4c2f-b859-9963fc00f227	784d7ff9dfce3d73a43a5906ff218bf8a448fefdcc51b1a037edb6b8fc05e866	2025-11-17 15:32:09.488474+05:30	20251107000000_add_expenses_table_manual	\N	\N	2025-11-17 15:32:09.483246+05:30	1
cc911201-e419-47ab-b954-1a6f835589b6	6f2263896281b893cb1a1e8a39d8186feff93d421308d1a45122119466fd96e3	2025-11-17 15:32:09.489339+05:30	20251107180000_add_approved_at_to_expenses	\N	\N	2025-11-17 15:32:09.488694+05:30	1
\.


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.activities (id, title, description, type, icon, "iconColor", tags, metadata, "createdAt", "updatedAt", "userId", "superAdminId", "leadId") FROM stdin;
1	Task created	Task "Test" created and assigned.	TASK_CREATED	CheckCircle	text-orange-600	{}	{"dealId": null, "leadId": null, "taskId": 1, "dueDate": null, "priority": "MEDIUM", "assignedTo": 5}	2025-11-17 11:21:49.817	2025-11-17 11:21:49.817	1	\N	\N
2	Note added	Note "Hi " added	COMMUNICATION_LOGGED	MessageSquare	#6B7280	{}	{"title": "Hi ", "noteId": 1}	2025-11-17 11:31:04.402	2025-11-17 11:31:04.402	1	\N	1
3	Lead assigned	Assigned to: Admin User, Source updated	LEAD_ASSIGNED	User	#3B82F6	{}	{"leadId": 2, "changes": ["Assigned to: Admin User", "Source updated"], "newStatus": "NEW", "oldStatus": "NEW", "newPriority": "MEDIUM", "oldPriority": "MEDIUM", "newAssignedTo": 1, "oldAssignedTo": null}	2025-11-18 05:45:40.688	2025-11-18 05:45:40.688	1	\N	2
4	Lead updated	Lead information updated	LEAD_UPDATED	Edit	#6B7280	{}	{"leadId": 3, "changes": [], "newStatus": "NEW", "oldStatus": "NEW", "newPriority": "MEDIUM", "oldPriority": "MEDIUM", "newAssignedTo": 1, "oldAssignedTo": 1}	2025-11-18 05:55:37.728	2025-11-18 05:55:37.728	1	\N	3
5	Task created	Task "HI" created.	TASK_CREATED	CheckCircle	text-orange-600	{}	{"dealId": null, "leadId": 3, "taskId": 2, "dueDate": "2025-11-18T00:00:00.000Z", "priority": "HIGH", "assignedTo": null}	2025-11-18 05:56:41.442	2025-11-18 05:56:41.442	1	\N	3
6	Meeting scheduled	Meeting "Hi " scheduled for 18/11/2025, 11:28:00 am	COMMUNICATION_LOGGED	Calendar	#3B82F6	{}	{"type": "MEETING", "leadId": 3, "scheduledAt": "2025-11-18T05:58:00.000Z", "communicationId": 1}	2025-11-18 05:57:12.34	2025-11-18 05:57:12.34	1	\N	3
7	Meeting scheduled	Meeting "Hi " scheduled for 18/11/2025, 11:38:00 am	COMMUNICATION_LOGGED	Calendar	#3B82F6	{}	{"type": "MEETING", "leadId": 3, "scheduledAt": "2025-11-18T06:08:00.000Z", "communicationId": 2}	2025-11-18 06:07:51.989	2025-11-18 06:07:51.989	1	\N	3
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.budgets (id, name, description, "budgetType", amount, spent, period, "startDate", "endDate", "expenseType", "projectId", "departmentId", currency, "isActive", "alertThreshold", "createdBy", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: business_settings; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.business_settings (id, "companyName", "companyEmail", "companyPhone", "companyAddress", "companyWebsite", "companyLogo", "timeZone", "dateFormat", currency, "passwordMinLength", "passwordRequireUpper", "passwordRequireLower", "passwordRequireNumber", "passwordRequireSymbol", "sessionTimeout", "maxLoginAttempts", "accountLockDuration", "twoFactorRequired", "emailVerificationRequired", "createdAt", "updatedAt", "leadAutoAssignmentEnabled", "leadFollowUpReminderDays", "metaAdsApiKey", "metaAdsApiSecret", "metaAdsEnabled", "indiamartApiKey", "indiamartApiSecret", "indiamartEnabled", "tradindiaApiKey", "tradindiaApiSecret", "tradindiaEnabled", "gstNumber", "panNumber", "cinNumber", "fiscalYearStart", industry, "employeeCount", description) FROM stdin;
1	Your Company	\N	\N	\N	\N	\N	UTC	MM/DD/YYYY	USD	8	t	t	t	f	24	5	30	f	t	2025-11-17 10:07:09.303	2025-11-17 10:07:09.303	f	3	\N	\N	f	\N	\N	f	\N	\N	f	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: call_logs; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.call_logs (id, "leadId", "userId", "phoneNumber", "callType", "callStatus", duration, "startTime", "endTime", notes, outcome, "recordingUrl", "isAnswered", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: communication_automations; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.communication_automations (id, name, "triggerType", "templateId", "isActive", conditions, delay, "companyId", "createdBy", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: communication_messages; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.communication_messages (id, "leadId", "userId", "templateId", type, recipient, subject, content, status, "sentAt", "deliveredAt", "readAt", "failedAt", "errorMessage", "externalId", metadata, "createdAt", "updatedAt") FROM stdin;
1	1	1	\N	EMAIL	Mohit.bellway@gmail.com	Hi 	Hi 	SENT	2025-11-17 11:02:47.405	\N	\N	\N	\N	\N	\N	2025-11-17 11:02:47.407	2025-11-17 11:02:47.407
2	1	1	\N	EMAIL	Mohit.bellway@gmail.com	Hi Test	Test	SENT	2025-11-17 11:13:01.291	\N	\N	\N	\N	\N	\N	2025-11-17 11:13:01.292	2025-11-17 11:13:01.292
\.


--
-- Data for Name: communication_providers; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.communication_providers (id, name, type, config, "isActive", "isDefault", "companyId", "createdAt", "updatedAt") FROM stdin;
1	SMTP Email	EMAIL	{"fromName": "We_Connect", "provider": "SMTP", "smtpHost": "smtp.gmail.com", "smtpPort": 587, "smtpUser": "shivpalbellway@gmail.com", "fromEmail": "shivpalbellway@gmail.com", "smtpPassword": "kqejfgtwhkxvhket"}	t	t	\N	2025-11-17 10:54:46.58	2025-11-17 13:00:59.206
\.


--
-- Data for Name: communication_templates; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.communication_templates (id, name, type, subject, content, variables, "isActive", "isDefault", "companyId", "createdBy", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.companies (id, name, "createdAt", "updatedAt", domain, "isActive", slug, "industryId", address, "alternatePhone", "annualRevenue", "assignedTo", city, "companySize", country, currency, "deletedAt", description, email, "employeeCount", "facebookPage", "foundedYear", "lastContactedAt", "leadScore", "linkedinProfile", "nextFollowUpAt", notes, "parentCompanyId", phone, state, status, tags, timezone, "twitterHandle", website, "zipCode") FROM stdin;
\.


--
-- Data for Name: company_activities; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.company_activities (id, "companyId", "userId", type, title, description, duration, outcome, "scheduledAt", "completedAt", "isCompleted", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: company_communications; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.company_communications (id, "companyId", "userId", type, subject, content, direction, status, "scheduledAt", "sentAt", "deliveredAt", "readAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: company_followups; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.company_followups (id, "companyId", "userId", type, subject, notes, priority, "scheduledAt", "completedAt", "isCompleted", "reminderSet", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: deal_products; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.deal_products (id, "dealId", name, quantity, price) FROM stdin;
\.


--
-- Data for Name: deals; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.deals (id, title, description, value, currency, status, probability, "expectedCloseDate", "actualCloseDate", "assignedTo", "leadId", "companyId", "isActive", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	Deal with Swati Dixit 	Deal opportunity from lead conversion	10000.000000000000000000000000000000	INR	PROPOSAL	50	\N	\N	1	3	\N	t	2025-11-18 06:06:40.184	2025-11-18 06:06:57.835	\N
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.expenses (id, "expenseDate", amount, type, category, description, remarks, "receiptUrl", status, "submittedBy", "approvedBy", "rejectedBy", "approvalRemarks", "projectId", "dealId", "leadId", currency, "isActive", "createdAt", "updatedAt", "deletedAt", "approvedAt") FROM stdin;
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.files (id, name, "fileName", "filePath", "fileSize", "mimeType", "entityType", "entityId", "uploadedBy", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: industries; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.industries (id, name, slug, "isActive", "createdAt", "updatedAt") FROM stdin;
1	Information Technologies	information-technologies	t	2025-11-17 10:28:18.669	2025-11-17 10:28:18.669
2	Pharma Industry	pharma-industry	t	2025-11-17 10:28:28.968	2025-11-17 10:28:28.968
3	Helthcare	helthcare	t	2025-11-17 10:28:33.732	2025-11-17 10:28:33.732
4	Education	education	t	2025-11-17 10:28:40.865	2025-11-17 10:28:40.865
\.


--
-- Data for Name: industry_fields; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.industry_fields (id, "industryId", name, key, type, "isRequired", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: integration_logs; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.integration_logs (id, "integrationId", operation, status, message, data, "errorDetails", "recordsCount", "createdAt") FROM stdin;
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.invoice_items (id, "invoiceId", "productId", name, description, quantity, unit, "unitPrice", "taxRate", "discountRate", subtotal, "totalAmount", "sortOrder", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.invoices (id, "invoiceNumber", title, description, status, subtotal, "taxAmount", "discountAmount", "totalAmount", "paidAmount", currency, "dueDate", notes, terms, "companyId", "leadId", "dealId", "quotationId", "createdBy", "sentAt", "viewedAt", "paidAt", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: lead_assignment_rules; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.lead_assignment_rules (id, name, description, "isActive", conditions, actions, priority, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lead_communications; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.lead_communications (id, "leadId", "userId", type, subject, content, direction, duration, outcome, "scheduledAt", "completedAt", "createdAt", "updatedAt") FROM stdin;
1	3	1	MEETING	Hi 	Meeting scheduled with Swati Dixit \nLocation: Hi \nMeeting Link: HI \n\nNotes: HI 	outbound	30	\N	2025-11-18 05:58:00	\N	2025-11-18 05:57:12.32	2025-11-18 05:57:12.32
2	3	1	MEETING	Hi 	Meeting scheduled with Swati Dixit 	outbound	30	\N	2025-11-18 06:08:00	\N	2025-11-18 06:07:51.977	2025-11-18 06:07:51.977
\.


--
-- Data for Name: lead_followups; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.lead_followups (id, "leadId", "userId", type, subject, notes, "scheduledAt", "completedAt", "isCompleted", "reminderSet", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lead_import_batches; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.lead_import_batches (id, "fileName", "totalRows", "successRows", "failedRows", status, "errorDetails", "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lead_import_records; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.lead_import_records (id, "batchId", "rowIndex", "leadId", status, errors, "rawData", "createdAt") FROM stdin;
\.


--
-- Data for Name: lead_integration_sync; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.lead_integration_sync (id, "leadId", "integrationId", "externalId", "externalData", "syncStatus", "lastSyncAt", "errorMessage", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: lead_sources; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.lead_sources (id, name, description, "isActive", "createdAt", "updatedAt", "companyId", color, "sortOrder") FROM stdin;
1	Facebook		t	2025-11-17 10:27:15.931	2025-11-17 10:27:15.931	\N	#6B7280	0
2	Instagram		t	2025-11-17 10:27:22.168	2025-11-17 10:27:22.168	\N	#6B7280	0
3	IndiaMart		t	2025-11-17 10:27:28.534	2025-11-17 10:27:28.534	\N	#6B7280	0
4	Justdail		t	2025-11-17 10:27:34.114	2025-11-17 10:27:34.114	\N	#6B7280	0
5	Linkedin		t	2025-11-17 10:27:38.202	2025-11-17 10:27:38.202	\N	#6B7280	0
8	tets		t	2025-11-17 12:50:29.868	2025-11-17 12:50:29.868	\N	#8B5CF6	0
\.


--
-- Data for Name: lead_tags; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.lead_tags (id, "leadId", "tagId") FROM stdin;
1	1	1
2	1	4
3	2	3
6	3	2
7	3	1
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.leads (id, "firstName", "lastName", email, phone, company, "position", status, notes, "isActive", "createdAt", "updatedAt", "sourceId", "assignedTo", "companyId", "deletedAt", budget, currency, "lastContactedAt", "nextFollowUpAt", priority, industry, website, "companySize", "annualRevenue", "leadScore", address, country, state, city, "zipCode", "linkedinProfile", timezone, "preferredContactMethod", "convertedToDealId", "previousStatus") FROM stdin;
1	Mohit 	Shrivastava	Mohit.bellway@gmail.com	+91 9090909009	Bellway Infotech	Test	NEW	He Is looking for CRM	t	2025-11-17 11:00:17.954	2025-11-17 11:00:17.954	1	1	\N	\N	100000.00	INR	\N	2025-11-17 13:00:00	HIGH	Education	bellwayinfotech.com	100	1000000.00	\N	Hi 	India	Madhya Pradesh	Indore	452001			email	\N	\N
2	Ankit 	SHrivastava	mohitshrivastava3011@gmail.com	+91 9098466409	Bellway 	CEO 	NEW	Hi 	t	2025-11-18 05:44:51.795	2025-11-18 05:45:40.681	1	1	\N	\N	\N	INR	\N	2025-11-18 05:46:00	MEDIUM	Information Technologies	http://192.168.29.62:5173/leads/new	100	100000.00	\N	Hi 	India	MP 	Indore 	452001			email	\N	\N
3	Swati	Dixit 	Swatibellway@gmail.com	+91 9090909090	Bellway	EXi	CONVERTED	Looking for CRM	t	2025-11-18 05:55:03.59	2025-11-18 06:06:40.196	\N	1	\N	\N	\N	INR	\N	2025-11-18 05:56:00	MEDIUM	Information Technologies	https://bellway.com	1000	100000.00	\N		India	MP	Indore	45001			email	1	NEW
\.


--
-- Data for Name: login_sessions; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.login_sessions (id, "userId", token, "deviceInfo", "ipAddress", "userAgent", "isActive", "expiresAt", "createdAt", "lastUsedAt") FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.notes (id, title, content, "isPinned", "leadId", "createdBy", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	Hi 	Hi 	f	1	1	2025-11-17 11:31:04.394	2025-11-17 11:31:04.394	\N
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.notification_preferences (id, "userId", "inAppEnabled", "emailEnabled", "soundEnabled", preferences, "doNotDisturbStart", "doNotDisturbEnd", "createdAt", "updatedAt") FROM stdin;
2	5	t	f	t	{"taskDue": true, "clientReply": true, "followUpDue": true, "leadCreated": true, "leadUpdated": true, "leadAssigned": true, "paymentAdded": true, "taskAssigned": true, "paymentUpdated": true, "meetingScheduled": true}	\N	\N	2025-11-17 11:14:18.009	2025-11-17 11:14:18.009
3	7	t	f	t	{"taskDue": true, "clientReply": true, "followUpDue": true, "leadCreated": true, "leadUpdated": true, "leadAssigned": true, "paymentAdded": true, "taskAssigned": true, "paymentUpdated": true, "meetingScheduled": true}	\N	\N	2025-11-17 13:07:22.259	2025-11-17 13:07:22.259
1	1	t	t	t	{"dealWon": true, "taskDue": true, "dealLost": true, "clientReply": true, "dealCreated": true, "followUpDue": true, "invoicePaid": true, "invoiceSent": true, "leadCreated": true, "leadUpdated": true, "leadAssigned": true, "paymentAdded": true, "taskAssigned": true, "quotationSent": true, "paymentUpdated": true, "meetingScheduled": true, "leadStatusChanged": true, "quotationAccepted": true}	\N	\N	2025-11-17 10:07:09.289	2025-11-18 05:46:19.13
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.notifications (id, "userId", type, title, message, link, read, "readAt", metadata, "createdAt", "updatedAt") FROM stdin;
1	1	LEAD_ASSIGNED	Lead Assigned to You	You have been assigned to lead "Mohit  Shrivastava"	/leads/1	t	2025-11-18 05:45:55.456	{"leadId": 1, "leadName": "Mohit  Shrivastava"}	2025-11-17 11:00:17.998	2025-11-18 05:45:55.46
2	1	LEAD_ASSIGNED	Lead Assigned to You	You have been assigned to lead "Ankit  SHrivastava"	/leads/2	t	2025-11-18 05:45:55.456	{"leadId": 2, "leadName": "Ankit  SHrivastava"}	2025-11-18 05:45:40.697	2025-11-18 05:45:55.46
3	1	LEAD_ASSIGNED	Lead Assigned to You	You have been assigned to lead "Swati Dixit "	/leads/3	f	\N	{"leadId": 3, "leadName": "Swati Dixit "}	2025-11-18 05:55:03.72	2025-11-18 05:55:03.72
4	1	MEETING_SCHEDULED	Meeting Scheduled	A meeting has been scheduled with lead "Swati Dixit " on 18/11/2025, 11:38:00 am.	/leads/3	f	\N	{"leadId": 3, "scheduledAt": "2025-11-18T06:08:00.000Z", "communicationId": 2}	2025-11-18 06:07:52.002	2025-11-18 06:07:52.002
\.


--
-- Data for Name: password_history; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.password_history (id, "userId", password, "createdAt") FROM stdin;
1	5	$2a$10$DgvF7rcF0.bkYuCxJFDfieTaw92FozANkvz4MbQzcDihoXL5qg7/W	2025-11-17 11:16:40.464
2	7	$2a$10$jR0TDcH5devAO2AzwfishusyX69fMn2RquYCaQhMreejoiwb/iA.m	2025-11-17 13:15:40.63
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.payments (id, "invoiceId", amount, currency, "paymentMethod", "paymentDate", "referenceNumber", notes, "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.permissions (id, name, key, description, module, "createdAt", "updatedAt") FROM stdin;
1	View Dashboard	dashboard.read	View dashboard	Dashboard	2025-11-17 10:02:11.497	2025-11-17 10:02:11.497
2	View Users	user.read	View users	Users	2025-11-17 10:02:11.499	2025-11-17 10:02:11.499
3	Create Users	user.create	Create users	Users	2025-11-17 10:02:11.501	2025-11-17 10:02:11.501
4	Update Users	user.update	Update users	Users	2025-11-17 10:02:11.502	2025-11-17 10:02:11.502
5	Delete Users	user.delete	Delete users	Users	2025-11-17 10:02:11.503	2025-11-17 10:02:11.503
6	View Roles	role.read	View roles	Roles	2025-11-17 10:02:11.504	2025-11-17 10:02:11.504
7	Create Roles	role.create	Create roles	Roles	2025-11-17 10:02:11.505	2025-11-17 10:02:11.505
8	Update Roles	role.update	Update roles	Roles	2025-11-17 10:02:11.506	2025-11-17 10:02:11.506
9	Delete Roles	role.delete	Delete roles	Roles	2025-11-17 10:02:11.507	2025-11-17 10:02:11.507
10	View Permissions	permission.read	View permissions	Permissions	2025-11-17 10:02:11.508	2025-11-17 10:02:11.508
11	Create Permissions	permission.create	Create permissions	Permissions	2025-11-17 10:02:11.508	2025-11-17 10:02:11.508
12	Update Permissions	permission.update	Update permissions	Permissions	2025-11-17 10:02:11.509	2025-11-17 10:02:11.509
13	Delete Permissions	permission.delete	Delete permissions	Permissions	2025-11-17 10:02:11.51	2025-11-17 10:02:11.51
14	View Leads	lead.read	View leads	Leads	2025-11-17 10:02:11.511	2025-11-17 10:02:11.511
15	Create Leads	lead.create	Create leads	Leads	2025-11-17 10:02:11.511	2025-11-17 10:02:11.511
16	Update Leads	lead.update	Update leads	Leads	2025-11-17 10:02:11.512	2025-11-17 10:02:11.512
17	Delete Leads	lead.delete	Delete leads	Leads	2025-11-17 10:02:11.513	2025-11-17 10:02:11.513
18	View Deals	deal.read	View deals	Deals	2025-11-17 10:02:11.513	2025-11-17 10:02:11.513
19	Create Deals	deal.create	Create deals	Deals	2025-11-17 10:02:11.514	2025-11-17 10:02:11.514
20	Update Deals	deal.update	Update deals	Deals	2025-11-17 10:02:11.514	2025-11-17 10:02:11.514
21	Delete Deals	deal.delete	Delete deals	Deals	2025-11-17 10:02:11.515	2025-11-17 10:02:11.515
22	View Quotations	quotation.read	View quotations	Quotations	2025-11-17 10:02:11.516	2025-11-17 10:02:11.516
23	Create Quotations	quotation.create	Create quotations	Quotations	2025-11-17 10:02:11.516	2025-11-17 10:02:11.516
24	Update Quotations	quotation.update	Update quotations	Quotations	2025-11-17 10:02:11.517	2025-11-17 10:02:11.517
25	Delete Quotations	quotation.delete	Delete quotations	Quotations	2025-11-17 10:02:11.517	2025-11-17 10:02:11.517
26	View Invoices	invoice.read	View invoices	Invoices	2025-11-17 10:02:11.518	2025-11-17 10:02:11.518
27	Create Invoices	invoice.create	Create invoices	Invoices	2025-11-17 10:02:11.519	2025-11-17 10:02:11.519
28	Update Invoices	invoice.update	Update invoices	Invoices	2025-11-17 10:02:11.519	2025-11-17 10:02:11.519
29	Delete Invoices	invoice.delete	Delete invoices	Invoices	2025-11-17 10:02:11.52	2025-11-17 10:02:11.52
30	View Activities	activity.read	View tasks and activities	Activities	2025-11-17 10:02:11.521	2025-11-17 10:02:11.521
31	View Business Settings	business_settings.read	View business settings	BusinessSettings	2025-11-17 10:02:11.521	2025-11-17 10:02:11.521
32	Update Business Settings	business_settings.update	Update business settings	BusinessSettings	2025-11-17 10:02:11.522	2025-11-17 10:02:11.522
33	View Trash	deleted.read	View deleted items	Trash	2025-11-17 10:02:11.522	2025-11-17 10:02:11.522
34	Expense create	expense.create	Create expenses	Expenses	2025-11-17 10:02:11.523	2025-11-17 10:02:11.523
35	Expense read	expense.read	View expenses	Expenses	2025-11-17 10:02:11.524	2025-11-17 10:02:11.524
36	Expense update	expense.update	Edit expenses	Expenses	2025-11-17 10:02:11.524	2025-11-17 10:02:11.524
37	Expense delete	expense.delete	Delete expenses	Expenses	2025-11-17 10:02:11.525	2025-11-17 10:02:11.525
38	Expense approve	expense.approve	Approve/Reject expenses	Expenses	2025-11-17 10:02:11.525	2025-11-17 10:02:11.525
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.products (id, name, description, sku, type, category, price, cost, currency, unit, "taxRate", "isActive", "stockQuantity", "minStockLevel", "maxStockLevel", image, "companyId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: proposal_templates; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.proposal_templates (id, name, description, content, "isActive", "isDefault", "headerHtml", "footerHtml", styles, variables, "previewImage", category, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: quotation_items; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.quotation_items (id, "quotationId", "productId", name, description, quantity, unit, "unitPrice", "taxRate", "discountRate", subtotal, "totalAmount", "sortOrder", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: quotation_templates; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.quotation_templates (id, name, description, "headerContent", "footerContent", "termsAndConditions", "validityDays", "showTax", "showDiscount", "logoPosition", "isDefault", "isActive", styles, "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: quotations; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.quotations (id, "quotationNumber", title, description, status, subtotal, "taxAmount", "discountAmount", "totalAmount", currency, "validUntil", notes, terms, "companyId", "leadId", "dealId", "createdBy", "sentAt", "viewedAt", "acceptedAt", "rejectedAt", "expiresAt", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.refresh_tokens (id, token, "userId", "expiresAt", "isRevoked", "createdAt") FROM stdin;
1	$2a$10$r22gviRVR3j5A/ezpZpRuuUCf5htJRenFSJ.z6lb6e2Gnjpp6UQgK	1	2025-11-24 10:07:09.15	f	2025-11-17 10:07:09.151
2	$2a$10$y99erW5b0QxeBtI8HP8CVeKuVM05Sn5rAdKlIVq0kJW/on57vlT3C	5	2025-11-24 11:14:17.926	f	2025-11-17 11:14:17.928
3	$2a$10$JfqaW8oBwFVvkL9dWqOF0Of0Gwiu/x47GPnr94xCab0RaOep2pdJi	5	2025-11-24 11:45:18.715	f	2025-11-17 11:45:18.717
4	$2a$10$FtYmR6r4tAj9Y.aO2uQ7BeoR9t/AUhZZV3msxYY2752uIFkBMA9S.	7	2025-11-24 13:07:22.144	f	2025-11-17 13:07:22.145
5	$2a$10$s4SwnptWN6PsJ7.HVvFQZeuhUzR4.S73mFMXD8jx5TfurXzMiRBYW	7	2025-11-24 13:14:48.658	f	2025-11-17 13:14:48.66
6	$2a$10$iP9nczUOsNz.WZOySzUmauMqd7.IoN/hKqBVcCPzPsKC3v7/6Pmpi	1	2025-11-25 05:31:37.641	f	2025-11-18 05:31:37.642
7	$2a$10$OQUmIjWUXkfy5lEy5BeuoeQP1SZ0sYVfKjpVJvIcoobZusav2Hqhu	1	2025-11-25 06:19:55.44	f	2025-11-18 06:19:55.442
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.role_permissions (id, "roleId", "permissionId") FROM stdin;
1	1	1
2	1	14
3	1	15
4	1	16
5	1	18
6	1	19
7	1	20
8	1	22
9	1	23
10	1	24
11	1	26
12	1	30
30	3	34
31	3	35
32	3	36
33	3	37
34	3	38
35	4	37
36	4	36
37	4	34
38	4	21
39	4	19
40	4	18
41	4	20
42	4	1
43	4	31
44	4	32
45	4	30
46	5	30
55	2	27
56	2	35
57	2	36
58	2	34
59	2	30
60	2	28
61	2	26
62	2	25
63	2	24
64	2	23
65	2	22
66	2	21
67	2	20
68	2	19
69	2	18
70	2	17
71	2	16
72	2	15
73	2	14
74	2	1
83	6	17
84	6	16
85	6	15
86	6	14
87	6	21
88	6	19
89	6	18
90	6	20
93	7	32
94	7	1
95	8	17
96	8	16
97	8	15
98	8	14
99	8	21
100	8	19
101	8	18
102	8	20
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.roles (id, name, description, "isActive", "createdAt", "updatedAt", "deletedAt", "accessScope") FROM stdin;
1	Sales Executive	Can manage own leads/deals and view activities	t	2025-11-17 10:02:11.526	2025-11-17 10:02:11.526	\N	OWN
3	Admin	Administrator role with full access	t	2025-11-17 10:06:46.438	2025-11-17 10:06:46.438	\N	GLOBAL
4	Test		t	2025-11-17 10:21:56.92	2025-11-17 10:22:01.969	2025-11-17 10:22:01.969	OWN
5	cxcv	c	t	2025-11-17 10:22:31.904	2025-11-17 10:22:35.894	2025-11-17 10:22:35.893	OWN
2	Sales Manager	Manage team leads deals and quotations view activities	t	2025-11-17 10:02:11.528	2025-11-17 11:08:03.587	\N	GLOBAL
6	Sale Exicutive		t	2025-11-17 11:07:04.511	2025-11-17 11:27:42.745	\N	GLOBAL
7	testwww	test	t	2025-11-17 11:29:36.103	2025-11-17 11:29:49.794	2025-11-17 11:29:49.793	OWN
8	test		t	2025-11-17 12:51:25.559	2025-11-17 12:51:25.559	\N	OWN
\.


--
-- Data for Name: super_admin_permissions; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.super_admin_permissions (id, name, key, description, module, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: super_admin_role_assignments; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.super_admin_role_assignments (id, "superAdminId", "roleId") FROM stdin;
\.


--
-- Data for Name: super_admin_role_permissions; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.super_admin_role_permissions (id, "roleId", "permissionId") FROM stdin;
\.


--
-- Data for Name: super_admin_roles; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.super_admin_roles (id, name, description, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: super_admins; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.super_admins (id, email, password, "firstName", "lastName", "isActive", "lastLogin", "createdAt", "updatedAt", "profilePicture") FROM stdin;
1	admin@weconnect.com	$2a$10$uzZjFIMVM6vN32RJBdylKufBtWcYPDuNFsrS053L6WdJcTV5GMZ/6	Super	Admin	t	\N	2025-11-17 10:02:11.476	2025-11-17 10:02:11.476	\N
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.tags (id, name, color, description, "isActive", "createdAt", "updatedAt", "companyId") FROM stdin;
1	Hot	#7C2D12	\N	t	2025-11-17 10:27:48.65	2025-11-17 10:27:48.65	\N
2	Cold	#14B8A6	\N	t	2025-11-17 10:27:51.529	2025-11-17 10:27:51.529	\N
3	Lost	#10B981	\N	t	2025-11-17 10:27:55.299	2025-11-17 10:27:55.299	\N
4	Insterested	#6366F1	\N	t	2025-11-17 10:28:03.051	2025-11-17 10:28:03.051	\N
5	Test	#6366F1	\N	t	2025-11-17 11:18:37.342	2025-11-17 11:18:37.342	\N
6	Test2	#B91C1C	\N	t	2025-11-17 11:18:41.385	2025-11-17 11:18:41.385	\N
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.tasks (id, title, description, status, priority, "dueDate", "completedAt", "assignedTo", "createdBy", "leadId", "dealId", "isActive", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	Test	Tets	PENDING	MEDIUM	\N	\N	5	1	\N	\N	t	2025-11-17 11:21:49.803	2025-11-17 11:21:49.803	\N
2	HI	\N	PENDING	HIGH	2025-11-18 00:00:00	\N	\N	1	3	\N	t	2025-11-18 05:56:41.428	2025-11-18 05:56:41.428	\N
\.


--
-- Data for Name: third_party_integrations; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.third_party_integrations (id, name, "displayName", description, "isActive", "apiEndpoint", "authType", config, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.user_roles (id, "userId", "roleId") FROM stdin;
1	1	3
2	3	1
3	4	2
9	5	1
11	6	8
13	7	2
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.users (id, email, password, "firstName", "lastName", "isActive", "lastLogin", "createdAt", "updatedAt", "profilePicture", "companyId", "deletedAt", "accountLockedUntil", "emailVerificationToken", "emailVerified", "emailVerifiedAt", "failedLoginAttempts", "passwordResetExpires", "passwordResetToken", "twoFactorEnabled", "twoFactorSecret", "dateOfBirth", "managerId", "mustChangePassword") FROM stdin;
3	sales.exec@weconnect.com	$2a$10$YO7YfqYiHdSVxiieRduRyejWlHPBuU6qsnBIhQkbFyHkT1ldCnYVi	Sales	Executive	t	\N	2025-11-17 10:06:46.643	2025-11-17 10:06:46.643	\N	\N	\N	\N	\N	t	\N	0	\N	\N	f	\N	\N	\N	f
4	sales.manager@weconnect.com	$2a$10$zaRmXkRGvUZCUr4ZYqOIfO9VS9Tfwm8PKUPM1qF77jrcs5PBxCDBu	Sales	Manager	t	\N	2025-11-17 10:06:46.721	2025-11-17 10:06:46.721	\N	\N	\N	\N	\N	t	\N	0	\N	\N	f	\N	\N	\N	f
5	swatibellway@gmail.com	$2a$10$DgvF7rcF0.bkYuCxJFDfieTaw92FozANkvz4MbQzcDihoXL5qg7/W	Ankit	Sharma	t	2025-11-17 11:45:18.722	2025-11-17 11:09:33.547	2025-11-17 11:46:53.183	\N	\N	\N	\N	\N	f	\N	0	\N	\N	f	\N	\N	4	f
2	test@weconnect.com	$2a$10$.Ewlixb3U9urzZ32rEm8mOnuXEglQ5QXqAsYDq.lQXs/TUp.gsAx6	Test	User	t	\N	2025-11-17 10:06:46.515	2025-11-17 12:15:38.652	\N	\N	2025-11-17 12:15:38.644	\N	\N	t	\N	0	\N	\N	f	\N	\N	\N	f
6	aurikabyaakriti@gmail.com	$2a$10$S1WLej.vXyfaZMExbfhDzeycijWbT1.bLVX5kQ6HNAQPcAR4Q2p3a	Aakriti	Shrivastava	t	\N	2025-11-17 12:52:22.204	2025-11-17 13:01:16	\N	\N	\N	\N	\N	f	\N	0	\N	\N	f	\N	\N	1	t
7	mohit.shrivastava30@gmail.com	$2a$10$jR0TDcH5devAO2AzwfishusyX69fMn2RquYCaQhMreejoiwb/iA.m	Mohit 	shrivastava	t	2025-11-17 13:14:48.666	2025-11-17 13:04:17.221	2025-11-17 13:17:09.73	\N	\N	\N	\N	\N	f	\N	0	\N	\N	f	\N	2025-11-18 00:00:00	1	f
1	admin@weconnect.com	$2a$10$fatXffeack0ygNJBnuv6FuqiC2V53RBRKR9RtlCaCIj.9LUicIBPC	Admin	User	t	2025-11-18 06:19:55.454	2025-11-17 10:06:46.434	2025-11-18 07:00:43.616	\N	\N	\N	\N	\N	t	\N	0	\N	\N	f	\N	2025-11-30 00:00:00	\N	f
\.


--
-- Data for Name: workflow_executions; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.workflow_executions (id, "workflowId", "triggerData", status, result, error, "startedAt", "completedAt", duration) FROM stdin;
1	1	{"id": 2, "city": "Indore ", "tags": [], "email": "mohitshrivastava3011@gmail.com", "notes": "", "phone": "+91 9098466409", "state": "MP ", "budget": null, "source": null, "status": "new", "address": "Hi ", "company": "Bellway ", "country": "India", "website": "http://192.168.29.62:5173/leads/new", "zipCode": "452001", "currency": "INR", "industry": "Information Technologies", "isActive": true, "lastName": "SHrivastava", "position": "CEO ", "priority": "medium", "sourceId": null, "timezone": "", "companyId": null, "createdAt": "2025-11-18T05:44:51.795Z", "deletedAt": null, "firstName": "Ankit ", "leadScore": null, "updatedAt": "2025-11-18T05:44:51.795Z", "assignedTo": null, "companySize": 100, "annualRevenue": 100000, "nextFollowUpAt": null, "previousStatus": null, "lastContactedAt": null, "linkedinProfile": "", "convertedToDealId": null, "preferredContactMethod": "email"}	SKIPPED	{"reason": "Conditions not met"}	\N	2025-11-18 05:44:51.822	2025-11-18 05:44:51.825	7
2	1	{"id": 3, "city": "Indore", "tags": [{"id": 2, "name": "Cold", "color": "#14B8A6"}, {"id": 1, "name": "Hot", "color": "#7C2D12"}], "email": "Swatibellway@gmail.com", "notes": "", "phone": "+91 9090909090", "state": "MP", "budget": null, "source": null, "status": "new", "address": "", "company": "Bellway", "country": "India", "website": "https://bellway.com", "zipCode": "45001", "currency": "INR", "industry": "Information Technologies", "isActive": true, "lastName": "Dixit ", "position": "EXi", "priority": "medium", "sourceId": null, "timezone": "", "companyId": null, "createdAt": "2025-11-18T05:55:03.590Z", "deletedAt": null, "firstName": "Swati", "leadScore": null, "updatedAt": "2025-11-18T05:55:03.590Z", "assignedTo": 1, "companySize": 1000, "annualRevenue": 100000, "nextFollowUpAt": null, "previousStatus": null, "lastContactedAt": null, "linkedinProfile": "", "convertedToDealId": null, "preferredContactMethod": "email"}	SUCCESS	{"actionResults": [{"action": "ASSIGN_TO_USER", "result": {"userId": 1, "assigned": true}, "success": true}]}	\N	2025-11-18 05:55:03.71	2025-11-18 05:55:03.717	11
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: weconnect_user
--

COPY public.workflows (id, name, description, "isActive", trigger, "triggerData", conditions, actions, "createdBy", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	Lead	Test	t	LEAD_CREATED	{}	{"logic": "AND", "conditions": [{"field": "city", "value": "Indore", "operator": "EQUALS"}]}	[{"type": "ASSIGN_TO_USER", "config": {"userId": 1}}]	1	2025-11-17 11:34:49.709	2025-11-17 11:34:49.709	\N
\.


--
-- Name: activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.activities_id_seq', 7, true);


--
-- Name: budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.budgets_id_seq', 1, false);


--
-- Name: business_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.business_settings_id_seq', 1, true);


--
-- Name: call_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.call_logs_id_seq', 1, false);


--
-- Name: communication_automations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.communication_automations_id_seq', 1, false);


--
-- Name: communication_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.communication_messages_id_seq', 2, true);


--
-- Name: communication_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.communication_providers_id_seq', 1, true);


--
-- Name: communication_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.communication_templates_id_seq', 1, false);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.companies_id_seq', 1, false);


--
-- Name: company_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.company_activities_id_seq', 1, false);


--
-- Name: company_communications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.company_communications_id_seq', 1, false);


--
-- Name: company_followups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.company_followups_id_seq', 1, false);


--
-- Name: deal_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.deal_products_id_seq', 1, false);


--
-- Name: deals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.deals_id_seq', 1, true);


--
-- Name: expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.expenses_id_seq', 1, false);


--
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.files_id_seq', 1, false);


--
-- Name: industries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.industries_id_seq', 4, true);


--
-- Name: industry_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.industry_fields_id_seq', 1, false);


--
-- Name: integration_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.integration_logs_id_seq', 1, false);


--
-- Name: invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.invoice_items_id_seq', 1, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- Name: lead_assignment_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.lead_assignment_rules_id_seq', 1, false);


--
-- Name: lead_communications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.lead_communications_id_seq', 2, true);


--
-- Name: lead_followups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.lead_followups_id_seq', 1, false);


--
-- Name: lead_import_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.lead_import_batches_id_seq', 1, false);


--
-- Name: lead_import_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.lead_import_records_id_seq', 1, false);


--
-- Name: lead_integration_sync_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.lead_integration_sync_id_seq', 1, false);


--
-- Name: lead_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.lead_sources_id_seq', 8, true);


--
-- Name: lead_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.lead_tags_id_seq', 7, true);


--
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.leads_id_seq', 3, true);


--
-- Name: login_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.login_sessions_id_seq', 1, false);


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.notes_id_seq', 1, true);


--
-- Name: notification_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.notification_preferences_id_seq', 3, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.notifications_id_seq', 4, true);


--
-- Name: password_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.password_history_id_seq', 2, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.permissions_id_seq', 178, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: proposal_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.proposal_templates_id_seq', 1, false);


--
-- Name: quotation_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.quotation_items_id_seq', 1, false);


--
-- Name: quotation_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.quotation_templates_id_seq', 1, false);


--
-- Name: quotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.quotations_id_seq', 1, false);


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.refresh_tokens_id_seq', 7, true);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 102, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.roles_id_seq', 8, true);


--
-- Name: super_admin_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.super_admin_permissions_id_seq', 1, false);


--
-- Name: super_admin_role_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.super_admin_role_assignments_id_seq', 1, false);


--
-- Name: super_admin_role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.super_admin_role_permissions_id_seq', 1, false);


--
-- Name: super_admin_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.super_admin_roles_id_seq', 1, false);


--
-- Name: super_admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.super_admins_id_seq', 1, true);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.tags_id_seq', 6, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.tasks_id_seq', 2, true);


--
-- Name: third_party_integrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.third_party_integrations_id_seq', 1, false);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 13, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.users_id_seq', 7, true);


--
-- Name: workflow_executions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.workflow_executions_id_seq', 2, true);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: weconnect_user
--

SELECT pg_catalog.setval('public.workflows_id_seq', 1, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: business_settings business_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.business_settings
    ADD CONSTRAINT business_settings_pkey PRIMARY KEY (id);


--
-- Name: call_logs call_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.call_logs
    ADD CONSTRAINT call_logs_pkey PRIMARY KEY (id);


--
-- Name: communication_automations communication_automations_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_automations
    ADD CONSTRAINT communication_automations_pkey PRIMARY KEY (id);


--
-- Name: communication_messages communication_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT communication_messages_pkey PRIMARY KEY (id);


--
-- Name: communication_providers communication_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_providers
    ADD CONSTRAINT communication_providers_pkey PRIMARY KEY (id);


--
-- Name: communication_templates communication_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT communication_templates_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_activities company_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_activities
    ADD CONSTRAINT company_activities_pkey PRIMARY KEY (id);


--
-- Name: company_communications company_communications_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_communications
    ADD CONSTRAINT company_communications_pkey PRIMARY KEY (id);


--
-- Name: company_followups company_followups_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_followups
    ADD CONSTRAINT company_followups_pkey PRIMARY KEY (id);


--
-- Name: deal_products deal_products_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.deal_products
    ADD CONSTRAINT deal_products_pkey PRIMARY KEY (id);


--
-- Name: deals deals_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT deals_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: industries industries_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.industries
    ADD CONSTRAINT industries_pkey PRIMARY KEY (id);


--
-- Name: industry_fields industry_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.industry_fields
    ADD CONSTRAINT industry_fields_pkey PRIMARY KEY (id);


--
-- Name: integration_logs integration_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT integration_logs_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: lead_assignment_rules lead_assignment_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_assignment_rules
    ADD CONSTRAINT lead_assignment_rules_pkey PRIMARY KEY (id);


--
-- Name: lead_communications lead_communications_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_communications
    ADD CONSTRAINT lead_communications_pkey PRIMARY KEY (id);


--
-- Name: lead_followups lead_followups_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_followups
    ADD CONSTRAINT lead_followups_pkey PRIMARY KEY (id);


--
-- Name: lead_import_batches lead_import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_import_batches
    ADD CONSTRAINT lead_import_batches_pkey PRIMARY KEY (id);


--
-- Name: lead_import_records lead_import_records_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_import_records
    ADD CONSTRAINT lead_import_records_pkey PRIMARY KEY (id);


--
-- Name: lead_integration_sync lead_integration_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_integration_sync
    ADD CONSTRAINT lead_integration_sync_pkey PRIMARY KEY (id);


--
-- Name: lead_sources lead_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_sources
    ADD CONSTRAINT lead_sources_pkey PRIMARY KEY (id);


--
-- Name: lead_tags lead_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_tags
    ADD CONSTRAINT lead_tags_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: login_sessions login_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.login_sessions
    ADD CONSTRAINT login_sessions_pkey PRIMARY KEY (id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_history password_history_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.password_history
    ADD CONSTRAINT password_history_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: proposal_templates proposal_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.proposal_templates
    ADD CONSTRAINT proposal_templates_pkey PRIMARY KEY (id);


--
-- Name: quotation_items quotation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT quotation_items_pkey PRIMARY KEY (id);


--
-- Name: quotation_templates quotation_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotation_templates
    ADD CONSTRAINT quotation_templates_pkey PRIMARY KEY (id);


--
-- Name: quotations quotations_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT quotations_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: super_admin_permissions super_admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_permissions
    ADD CONSTRAINT super_admin_permissions_pkey PRIMARY KEY (id);


--
-- Name: super_admin_role_assignments super_admin_role_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_role_assignments
    ADD CONSTRAINT super_admin_role_assignments_pkey PRIMARY KEY (id);


--
-- Name: super_admin_role_permissions super_admin_role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_role_permissions
    ADD CONSTRAINT super_admin_role_permissions_pkey PRIMARY KEY (id);


--
-- Name: super_admin_roles super_admin_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_roles
    ADD CONSTRAINT super_admin_roles_pkey PRIMARY KEY (id);


--
-- Name: super_admins super_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admins
    ADD CONSTRAINT super_admins_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: third_party_integrations third_party_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.third_party_integrations
    ADD CONSTRAINT third_party_integrations_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workflow_executions workflow_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT workflow_executions_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: companies_domain_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX companies_domain_key ON public.companies USING btree (domain);


--
-- Name: companies_name_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX companies_name_key ON public.companies USING btree (name);


--
-- Name: companies_slug_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX companies_slug_key ON public.companies USING btree (slug);


--
-- Name: industries_name_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX industries_name_key ON public.industries USING btree (name);


--
-- Name: industries_slug_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX industries_slug_key ON public.industries USING btree (slug);


--
-- Name: industry_fields_industryId_key_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "industry_fields_industryId_key_key" ON public.industry_fields USING btree ("industryId", key);


--
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- Name: lead_integration_sync_externalId_integrationId_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "lead_integration_sync_externalId_integrationId_key" ON public.lead_integration_sync USING btree ("externalId", "integrationId");


--
-- Name: lead_integration_sync_leadId_integrationId_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "lead_integration_sync_leadId_integrationId_key" ON public.lead_integration_sync USING btree ("leadId", "integrationId");


--
-- Name: lead_sources_name_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX lead_sources_name_key ON public.lead_sources USING btree (name);


--
-- Name: lead_tags_leadId_tagId_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "lead_tags_leadId_tagId_key" ON public.lead_tags USING btree ("leadId", "tagId");


--
-- Name: login_sessions_token_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX login_sessions_token_key ON public.login_sessions USING btree (token);


--
-- Name: notification_preferences_userId_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "notification_preferences_userId_key" ON public.notification_preferences USING btree ("userId");


--
-- Name: notifications_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE INDEX "notifications_userId_createdAt_idx" ON public.notifications USING btree ("userId", "createdAt");


--
-- Name: notifications_userId_read_idx; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE INDEX "notifications_userId_read_idx" ON public.notifications USING btree ("userId", read);


--
-- Name: permissions_key_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX permissions_key_key ON public.permissions USING btree (key);


--
-- Name: products_sku_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX products_sku_key ON public.products USING btree (sku);


--
-- Name: quotations_quotationNumber_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "quotations_quotationNumber_key" ON public.quotations USING btree ("quotationNumber");


--
-- Name: refresh_tokens_token_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX refresh_tokens_token_key ON public.refresh_tokens USING btree (token);


--
-- Name: role_permissions_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "role_permissions_roleId_permissionId_key" ON public.role_permissions USING btree ("roleId", "permissionId");


--
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- Name: super_admin_permissions_key_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX super_admin_permissions_key_key ON public.super_admin_permissions USING btree (key);


--
-- Name: super_admin_role_assignments_superAdminId_roleId_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "super_admin_role_assignments_superAdminId_roleId_key" ON public.super_admin_role_assignments USING btree ("superAdminId", "roleId");


--
-- Name: super_admin_role_permissions_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "super_admin_role_permissions_roleId_permissionId_key" ON public.super_admin_role_permissions USING btree ("roleId", "permissionId");


--
-- Name: super_admin_roles_name_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX super_admin_roles_name_key ON public.super_admin_roles USING btree (name);


--
-- Name: super_admins_email_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX super_admins_email_key ON public.super_admins USING btree (email);


--
-- Name: tags_name_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX tags_name_key ON public.tags USING btree (name);


--
-- Name: third_party_integrations_name_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX third_party_integrations_name_key ON public.third_party_integrations USING btree (name);


--
-- Name: user_roles_userId_roleId_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "user_roles_userId_roleId_key" ON public.user_roles USING btree ("userId", "roleId");


--
-- Name: users_emailVerificationToken_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "users_emailVerificationToken_key" ON public.users USING btree ("emailVerificationToken");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_passwordResetToken_key; Type: INDEX; Schema: public; Owner: weconnect_user
--

CREATE UNIQUE INDEX "users_passwordResetToken_key" ON public.users USING btree ("passwordResetToken");


--
-- Name: activities activities_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT "activities_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: activities activities_superAdminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT "activities_superAdminId_fkey" FOREIGN KEY ("superAdminId") REFERENCES public.super_admins(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: activities activities_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT "activities_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: budgets budgets_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT "budgets_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: call_logs call_logs_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.call_logs
    ADD CONSTRAINT "call_logs_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: call_logs call_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.call_logs
    ADD CONSTRAINT "call_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: communication_automations communication_automations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_automations
    ADD CONSTRAINT "communication_automations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: communication_automations communication_automations_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_automations
    ADD CONSTRAINT "communication_automations_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: communication_automations communication_automations_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_automations
    ADD CONSTRAINT "communication_automations_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public.communication_templates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: communication_messages communication_messages_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT "communication_messages_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: communication_messages communication_messages_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT "communication_messages_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public.communication_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: communication_messages communication_messages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_messages
    ADD CONSTRAINT "communication_messages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: communication_providers communication_providers_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_providers
    ADD CONSTRAINT "communication_providers_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: communication_templates communication_templates_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT "communication_templates_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: communication_templates communication_templates_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT "communication_templates_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: companies companies_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT "companies_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: companies companies_industryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT "companies_industryId_fkey" FOREIGN KEY ("industryId") REFERENCES public.industries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: companies companies_parentCompanyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT "companies_parentCompanyId_fkey" FOREIGN KEY ("parentCompanyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: company_activities company_activities_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_activities
    ADD CONSTRAINT "company_activities_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_activities company_activities_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_activities
    ADD CONSTRAINT "company_activities_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: company_communications company_communications_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_communications
    ADD CONSTRAINT "company_communications_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_communications company_communications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_communications
    ADD CONSTRAINT "company_communications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: company_followups company_followups_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_followups
    ADD CONSTRAINT "company_followups_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company_followups company_followups_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.company_followups
    ADD CONSTRAINT "company_followups_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: deal_products deal_products_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.deal_products
    ADD CONSTRAINT "deal_products_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: deals deals_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: deals deals_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: deals deals_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.deals
    ADD CONSTRAINT "deals_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_approvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_approvedBy_fkey" FOREIGN KEY ("approvedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_rejectedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_rejectedBy_fkey" FOREIGN KEY ("rejectedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: expenses expenses_submittedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_submittedBy_fkey" FOREIGN KEY ("submittedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: files files_uploadedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT "files_uploadedBy_fkey" FOREIGN KEY ("uploadedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: industry_fields industry_fields_industryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.industry_fields
    ADD CONSTRAINT "industry_fields_industryId_fkey" FOREIGN KEY ("industryId") REFERENCES public.industries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: integration_logs integration_logs_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.integration_logs
    ADD CONSTRAINT "integration_logs_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public.third_party_integrations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoice_items invoice_items_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT "invoice_items_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoice_items invoice_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT "invoice_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: invoices invoices_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoices invoices_quotationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_quotationId_fkey" FOREIGN KEY ("quotationId") REFERENCES public.quotations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lead_communications lead_communications_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_communications
    ADD CONSTRAINT "lead_communications_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_communications lead_communications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_communications
    ADD CONSTRAINT "lead_communications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lead_followups lead_followups_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_followups
    ADD CONSTRAINT "lead_followups_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_followups lead_followups_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_followups
    ADD CONSTRAINT "lead_followups_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lead_import_batches lead_import_batches_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_import_batches
    ADD CONSTRAINT "lead_import_batches_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lead_import_records lead_import_records_batchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_import_records
    ADD CONSTRAINT "lead_import_records_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES public.lead_import_batches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_import_records lead_import_records_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_import_records
    ADD CONSTRAINT "lead_import_records_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lead_integration_sync lead_integration_sync_integrationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_integration_sync
    ADD CONSTRAINT "lead_integration_sync_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES public.third_party_integrations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: lead_integration_sync lead_integration_sync_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_integration_sync
    ADD CONSTRAINT "lead_integration_sync_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_sources lead_sources_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_sources
    ADD CONSTRAINT "lead_sources_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lead_tags lead_tags_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_tags
    ADD CONSTRAINT "lead_tags_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lead_tags lead_tags_tagId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.lead_tags
    ADD CONSTRAINT "lead_tags_tagId_fkey" FOREIGN KEY ("tagId") REFERENCES public.tags(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leads leads_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT "leads_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: leads leads_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT "leads_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: leads leads_sourceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT "leads_sourceId_fkey" FOREIGN KEY ("sourceId") REFERENCES public.lead_sources(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: login_sessions login_sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.login_sessions
    ADD CONSTRAINT "login_sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notes notes_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT "notes_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: notes notes_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT "notes_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT "notification_preferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: password_history password_history_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.password_history
    ADD CONSTRAINT "password_history_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quotation_items quotation_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT "quotation_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: quotation_items quotation_items_quotationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotation_items
    ADD CONSTRAINT "quotation_items_quotationId_fkey" FOREIGN KEY ("quotationId") REFERENCES public.quotations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: quotations quotations_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: quotations quotations_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: quotations quotations_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: quotations quotations_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.quotations
    ADD CONSTRAINT "quotations_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: refresh_tokens refresh_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "refresh_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: super_admin_role_assignments super_admin_role_assignments_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_role_assignments
    ADD CONSTRAINT "super_admin_role_assignments_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.super_admin_roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: super_admin_role_assignments super_admin_role_assignments_superAdminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_role_assignments
    ADD CONSTRAINT "super_admin_role_assignments_superAdminId_fkey" FOREIGN KEY ("superAdminId") REFERENCES public.super_admins(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: super_admin_role_permissions super_admin_role_permissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_role_permissions
    ADD CONSTRAINT "super_admin_role_permissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public.super_admin_permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: super_admin_role_permissions super_admin_role_permissions_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.super_admin_role_permissions
    ADD CONSTRAINT "super_admin_role_permissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.super_admin_roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tags tags_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT "tags_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tasks tasks_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tasks tasks_dealId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_dealId_fkey" FOREIGN KEY ("dealId") REFERENCES public.deals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tasks tasks_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "tasks_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public.leads(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_roles user_roles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "user_roles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_companyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_companyId_fkey" FOREIGN KEY ("companyId") REFERENCES public.companies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_managerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_managerId_fkey" FOREIGN KEY ("managerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: workflow_executions workflow_executions_workflowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: weconnect_user
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT "workflow_executions_workflowId_fkey" FOREIGN KEY ("workflowId") REFERENCES public.workflows(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 6boYnMTAD9quYwDovDkmUZMhI6Wk8COUQiLE0adpwPZo9TVUJJOTvW4UlBi6pvB

